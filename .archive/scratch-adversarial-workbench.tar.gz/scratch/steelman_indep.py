import json, math, numpy as np

BASE="results/splicebert_partner_selection/behavior"
sets = {
 "VAL  additive-frozen":      f"{BASE}/seed0_additive-frozen/val/per_example_clean.jsonl",
 "CONF additive-frozen":      f"{BASE}/seed0_additive-frozen/val/val_local_conflicts/per_example_clean.jsonl",
 "VAL  random-frozen":        f"{BASE}/seed0_additive-random-frozen/val/per_example_clean.jsonl",
 "CONF random-frozen":        f"{BASE}/seed0_additive-random-frozen/val/val_local_conflicts/per_example_clean.jsonl",
}
recs = {k: [json.loads(l) for l in open(p)] for k,p in sets.items()}
need = set()
for v in recs.values():
    for r in v: need.add(r["example_id"])
print("unique example_ids needed:", len(need))

# stream val.jsonl, keep only pair lists for needed ids
pairs_by_id = {}
with open("data/processed/splicebert_partner_selection/v1/val.jsonl") as f:
    for line in f:
        i = line.find('"example_id"')
        j = line.find('"', i+14); k = line.find('"', j+1)
        eid = line[j+1:k]
        if eid in need:
            d = json.loads(line)
            pairs_by_id[eid] = [(p["acceptor_pos"], p["donor_pos"]) for p in d["pairs"]]
print("resolved:", len(pairs_by_id))
np.save("scratch/_dummy.npy", np.zeros(1))
json.dump({k:v for k,v in pairs_by_id.items()}, open("scratch/_pairs.json","w"))

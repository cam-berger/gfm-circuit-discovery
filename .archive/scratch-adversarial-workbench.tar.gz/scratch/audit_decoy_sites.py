"""Independent check: are candidate decoy AG/GT motifs real annotated splice sites?

Maps every candidate site in the conflict set back to genomic coordinates and
tests membership in the set of annotated splice-site anchors from the study's
own GENCODE v50 GTF (chr17/chr18, ALL transcript biotypes).
"""
from __future__ import annotations

import gzip
import json
import sys
from collections import defaultdict

GTF = "data/external/gencode/v50/gencode.v50.basic.annotation.gtf.gz"
CONFLICTS = "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl"
CHROMS = {"chr17", "chr18"}

# ---- 1. build annotated splice-site anchor sets ----
# exon records per transcript
tx_exons: dict[str, list[tuple[int, int]]] = defaultdict(list)
tx_meta: dict[str, tuple[str, str]] = {}
n_exon_lines = 0
with gzip.open(GTF, "rt") as f:
    for line in f:
        if line.startswith("#"):
            continue
        c = line.rstrip("\n").split("\t")
        if c[2] != "exon" or c[0] not in CHROMS:
            continue
        n_exon_lines += 1
        chrom, start, end, strand, attrs = c[0], int(c[3]) - 1, int(c[4]), c[6], c[8]
        tid = attrs.split('transcript_id "', 1)[1].split('"', 1)[0]
        tx_exons[tid].append((start, end))
        tx_meta[tid] = (chrom, strand)

# acceptor anchor = first exonic nt (transcript orientation)
# donor anchor    = first intronic nt after the exon (transcript orientation)
acc_anchor: dict[str, set[int]] = {"+": set(), "-": set()}
don_anchor: dict[str, set[int]] = {"+": set(), "-": set()}
for tid, exons in tx_exons.items():
    chrom, strand = tx_meta[tid]
    ex = sorted(exons)
    if strand == "-":
        ex = ex[::-1]
    n = len(ex)
    if n < 2:
        continue
    for i, (s, e) in enumerate(ex):
        if strand == "+":
            a, d = s, e            # 0-based: first exonic nt ; first intronic nt
        else:
            a, d = e - 1, s - 1
        if i > 0:                   # has an upstream intron -> acceptor is a splice site
            acc_anchor[strand].add(a)
        if i < n - 1:               # has a downstream intron -> donor is a splice site
            don_anchor[strand].add(d)

# strand-agnostic union (a decoy AG on the + strand can only be a + acceptor,
# but report the permissive variant too so the check is conservative)
acc_any = acc_anchor["+"] | acc_anchor["-"]
don_any = don_anchor["+"] | don_anchor["-"]

print(f"GTF exon lines chr17/18: {n_exon_lines}; transcripts: {len(tx_exons)}")
print(f"annotated acceptor anchors: + {len(acc_anchor['+'])}  - {len(acc_anchor['-'])}")
print(f"annotated donor anchors:    + {len(don_anchor['+'])}  - {len(don_anchor['-'])}")

# ---- 2. map candidates ----
stats = defaultdict(int)
n_ex = 0
true_acc_hit = true_don_hit = 0
pair_both_real = 0
pair_total = 0
per_ex_both_real_decoys = []

for line in open(CONFLICTS):
    d = json.loads(line)
    n_ex += 1
    strand = d["strand"]
    W = d["metadata"]["genomic_window_start"]
    E = d["metadata"]["genomic_window_end"]
    L = len(d["sequence"])
    assert E - W == L, (E - W, L)

    def g(p: int) -> int:
        return W + p if strand == "+" else E - 1 - p

    tp = d["pairs"][d["true_pair_index"]]
    ta, td = tp["acceptor_pos"], tp["donor_pos"]

    A = acc_anchor[strand]
    D = don_anchor[strand]

    acc_real = {}
    for s in d["acceptors"]:
        p = s["position"]
        acc_real[p] = g(p) in A
        if p == ta:
            true_acc_hit += acc_real[p]
        else:
            stats["decoy_acc_total"] += 1
            stats["decoy_acc_real"] += acc_real[p]
            stats["decoy_acc_real_anystrand"] += g(p) in acc_any

    don_real = {}
    for s in d["donors"]:
        p = s["position"]
        don_real[p] = g(p) in D
        if p == td:
            true_don_hit += don_real[p]
        else:
            stats["decoy_don_total"] += 1
            stats["decoy_don_real"] += don_real[p]
            stats["decoy_don_real_anystrand"] += g(p) in don_any

    nboth = 0
    for pr in d["pairs"]:
        pair_total += 1
        a, dd = pr["acceptor_pos"], pr["donor_pos"]
        if acc_real[a] and don_real[dd]:
            pair_both_real += 1
            if not (a == ta and dd == td):
                nboth += 1
    per_ex_both_real_decoys.append(nboth)

print()
print(f"examples: {n_ex}")
print(f"TRUE acceptor is an annotated acceptor anchor: {true_acc_hit}/{n_ex} = {true_acc_hit/n_ex:.4f}")
print(f"TRUE donor    is an annotated donor anchor:    {true_don_hit}/{n_ex} = {true_don_hit/n_ex:.4f}")
print()
da, dat = stats["decoy_acc_real"], stats["decoy_acc_total"]
dd, ddt = stats["decoy_don_real"], stats["decoy_don_total"]
print(f"decoy acceptor motifs: {dat}, real annotated acceptors: {da} = {da/dat:.4%}"
      f"  (strand-agnostic: {stats['decoy_acc_real_anystrand']} = {stats['decoy_acc_real_anystrand']/dat:.4%})")
print(f"decoy donor motifs:    {ddt}, real annotated donors:    {dd} = {dd/ddt:.4%}"
      f"  (strand-agnostic: {stats['decoy_don_real_anystrand']} = {stats['decoy_don_real_anystrand']/ddt:.4%})")
print()
print(f"candidate PAIRS: {pair_total}; both endpoints real annotated sites: {pair_both_real}"
      f" = {pair_both_real/pair_total:.4%}")
decoys_both = pair_both_real - n_ex
print(f"  of which the true pair: {n_ex}; DECOY pairs with both endpoints real: {decoys_both}"
      f" = {decoys_both/pair_total:.4%}")
import statistics
print(f"  per-example count of both-real DECOY pairs: mean {statistics.mean(per_ex_both_real_decoys):.3f},"
      f" median {statistics.median(per_ex_both_real_decoys)},"
      f" frac examples with >=1: {sum(1 for x in per_ex_both_real_decoys if x)/n_ex:.4f}")

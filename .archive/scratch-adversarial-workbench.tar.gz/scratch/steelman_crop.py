#!/usr/bin/env python
"""CONVERSE TEST: break the positional invariants, keep the sequence content.

CROP-LEFT k : drop the first k nt.  True acceptor moves 200 -> 200-k  (ACCEPTOR
              invariant BROKEN).  Donor's distance-from-end is unchanged (=200).
CROP-RIGHT k: drop the last k nt.   Donor's distance-from-end 200 -> 200-k
              (DONOR/length-leak invariant BROKEN).  Acceptor stays at 200.
CROP-BOTH k : both invariants broken.

The removed nucleotides are 180+ nt away from the splice sites (flanks are 200nt),
so essentially no biological signal is removed.  Candidate positions are re-indexed;
candidates falling outside the cropped window are dropped (true pair always survives).

If the readout is a POSITION detector:  PMR craters under the crop that breaks
   the invariant it relies on.
If the readout is a CONTENT detector:   PMR is ~unchanged.

Also: how much of the acceptor/donor score variance is explained by POSITION ALONE?
"""
from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np
import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))

from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.schema import SplicePairExample, PairCandidate  # noqa: E402
from gfmcd.splicing.readout import collate_pair_indices  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint  # noqa: E402

N = 300
BATCH = 6


def crop(example: SplicePairExample, kl: int, kr: int) -> SplicePairExample | None:
    seq = example.sequence
    n = len(seq)
    new_seq = seq[kl: n - kr] if kr else seq[kl:]
    lo, hi = kl, n - kr
    pairs = []
    true_key = (example.true_pair.acceptor_pos, example.true_pair.donor_pos)
    true_idx = None
    for p in example.pairs:
        a, d = p.acceptor_pos, p.donor_pos
        # need acceptor motif [a-2,a) and donor motif [d,d+2) inside the crop
        if a - 2 < lo or a >= hi or d < lo or d + 2 > hi:
            continue
        np_ = PairCandidate(acceptor_pos=a - kl, donor_pos=d - kl,
                            acceptor_index=p.acceptor_index, donor_index=p.donor_index)
        if (a, d) == true_key:
            true_idx = len(pairs)
        pairs.append(np_)
    if true_idx is None or len(pairs) < 2:
        return None
    return SplicePairExample(
        example_id=example.example_id, sequence=new_seq,
        acceptors=example.acceptors, donors=example.donors,
        pairs=tuple(pairs), true_pair_index=true_idx,
        gene_id=example.gene_id, transcript_id=example.transcript_id,
        chrom=example.chrom, strand=example.strand, exon_number=example.exon_number,
        genomic_exon_start=example.genomic_exon_start, genomic_exon_end=example.genomic_exon_end,
        split=example.split, metadata=example.metadata,
    )


def score(adapter, readout, rep, examples):
    wins = tot = 0
    rows = []
    for i in range(0, len(examples), BATCH):
        ex = examples[i:i + BATCH]
        tok = adapter.tokenize([x.sequence for x in ex])
        pb = collate_pair_indices(ex, token_offset=tok.prefix_tokens, device=adapter.device)
        with torch.no_grad():
            out = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
            hidden = out.hidden_states[rep]
            b = torch.arange(hidden.shape[0], device=hidden.device)[:, None]
            A = readout.acceptor(hidden[b, pb.positions[..., 0]]).squeeze(-1).float().cpu()
            D = readout.donor(hidden[b, pb.positions[..., 1]]).squeeze(-1).float().cpu()
            lg = readout(hidden, pb).float().cpu()
        mask = pb.mask.cpu()
        for k, x in enumerate(ex):
            m = mask[k]
            l = lg[k][m]
            t = x.true_pair_index
            dec = torch.cat([l[:t], l[t + 1:]])
            wins += int(l[t].item() > dec.max().item())
            tot += 1
            rows.append(dict(
                seq_len=len(x.sequence),
                a_pos=np.array([p.acceptor_pos for p in x.pairs]),
                d_pos=np.array([p.donor_pos for p in x.pairs]),
                A=A[k][m].numpy(), D=D[k][m].numpy(),
                true=t,
            ))
    return wins / tot, tot, rows


def main():
    device = "mps" if torch.backends.mps.is_available() else "cpu"
    cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
    rep = int(cfg["readout"]["representation_layer"])
    mc = cfg["model"]
    adapter = SpliceBertAdapter.from_pretrained(
        REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
        trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
    readout, _ = load_pair_checkpoint(
        REPO / "colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt", adapter=adapter)

    conf = REPO / "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl"
    examples = []
    with conf.open() as f:
        for line in f:
            if line.strip():
                examples.append(SplicePairExample.from_json(line))
                if len(examples) >= N:
                    break

    out = {}
    conds = [("REAL", 0, 0), ("CROP-LEFT 20", 20, 0), ("CROP-RIGHT 20", 0, 20),
             ("CROP-BOTH 20", 20, 20), ("CROP-BOTH 50", 50, 50)]
    base_rows = None
    for name, kl, kr in conds:
        exs = [crop(x, kl, kr) if (kl or kr) else x for x in examples]
        exs = [x for x in exs if x is not None]
        pmr, tot, rows = score(adapter, readout, rep, exs)
        if name == "REAL":
            base_rows = rows
        out[name] = {"pmr": pmr, "n": tot}
        print(f"{name:14s}  PMR={pmr:.4f}  n={tot}", flush=True)

    # ---- how much of A / D is explained by POSITION ALONE? ----
    # pool all candidates; regress A on a position basis (one value per distinct
    # acceptor position) -- this is the BEST POSSIBLE position-only predictor.
    a_pos = np.concatenate([r["a_pos"] for r in base_rows])
    d_end = np.concatenate([r["seq_len"] - r["d_pos"] for r in base_rows])  # distance from end
    Av = np.concatenate([r["A"] for r in base_rows])
    Dv = np.concatenate([r["D"] for r in base_rows])

    def pos_r2(pos, val):
        # best position-only predictor = mean value within each position bin
        pred = np.zeros_like(val, dtype=np.float64)
        for p in np.unique(pos):
            m = pos == p
            pred[m] = val[m].mean()
        ss_res = ((val - pred) ** 2).sum()
        ss_tot = ((val - val.mean()) ** 2).sum()
        return 1 - ss_res / ss_tot

    r2a = pos_r2(a_pos, Av)
    r2d = pos_r2(d_end, Dv)
    print(f"\nBEST position-only predictor (saturated, one param per position):")
    print(f"  R^2 of acceptor score A on acceptor ABSOLUTE POSITION : {r2a:.4f}  (n={len(Av)}, {len(np.unique(a_pos))} distinct pos)")
    print(f"  R^2 of donor score D on donor DISTANCE-FROM-END       : {r2d:.4f}  (n={len(Dv)}, {len(np.unique(d_end))} distinct)")
    print("  (this is an UPPER BOUND on the positional content of each score:")
    print("   a saturated one-param-per-position fit, so it also soaks up any")
    print("   real biological position effects and overfits rare positions.)")

    # Same, EXCLUDING the true sites (so pos 200 / end-200 can't dominate)
    def excl(rows, key, valkey, endrel=False):
        ps, vs = [], []
        for r in rows:
            m = np.ones(len(r["A"]), bool)
            m[r["true"]] = False
            p = (r["seq_len"] - r["d_pos"]) if endrel else r[key]
            ps.append(p[m]); vs.append(r[valkey][m])
        return np.concatenate(ps), np.concatenate(vs)

    pa, va = excl(base_rows, "a_pos", "A")
    pd_, vd = excl(base_rows, "d_pos", "D", endrel=True)
    print(f"\n  DECOYS ONLY: R^2(A | acceptor pos) = {pos_r2(pa, va):.4f}")
    print(f"  DECOYS ONLY: R^2(D | donor dist-from-end) = {pos_r2(pd_, vd):.4f}")

    out["r2"] = {"A_on_abs_pos": float(r2a), "D_on_dist_from_end": float(r2d),
                 "A_decoys": float(pos_r2(pa, va)), "D_decoys": float(pos_r2(pd_, vd))}
    (REPO / "scratch/steelman_crop_results.json").write_text(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()

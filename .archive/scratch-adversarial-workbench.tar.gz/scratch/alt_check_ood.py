"""Robustness check: is the +10.9 inflation of f(h_a*) under acceptor-masking real,
or an outlier artifact? Report full distribution, and check the DONOR-mask control."""
import sys, statistics as st, json
from pathlib import Path
import torch
REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "src"))
from gfmcd.adapters.splicebert import SpliceBertAdapter
from gfmcd.splicing.config import load_config
from gfmcd.splicing.context_controls import mask_true_partner_neighborhood
from gfmcd.splicing.io import load_jsonl
from gfmcd.splicing.readout import collate_pair_indices
from gfmcd.splicing.training import load_pair_checkpoint

cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"]); mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode="spaced", device="mps",
    trust_remote_code=False, local_files_only=True, model_class="masked_lm")
readout, _ = load_pair_checkpoint(
    REPO / "colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt", adapter=adapter)
ex = load_jsonl(REPO / "results/splicebert_partner_selection/circuits/discovery/confirmation.jsonl")[:150]

def site_scores(chunk, seqs):
    tok = adapter.tokenize(seqs)
    pb = collate_pair_indices(chunk, token_offset=tok.prefix_tokens, device=adapter.device)
    with torch.no_grad():
        h = adapter.forward(tok, output_hidden_states=True).hidden_states[rep]
        b = torch.arange(h.shape[0], device=h.device)[:, None]
        A = readout.acceptor(h[b, pb.positions[..., 0]]).squeeze(-1)
        D = readout.donor(h[b, pb.positions[..., 1]]).squeeze(-1)
    bb = torch.arange(len(chunk), device=A.device)
    return A[bb, pb.labels].tolist(), D[bb, pb.labels].tolist()

Ac, Dc, Aa, Da, Ad, Dd = [], [], [], [], [], []
for i in range(0, len(ex), 4):
    c = ex[i:i+4]
    a, d = site_scores(c, [x.sequence for x in c]); Ac += a; Dc += d
    a, d = site_scores(c, [mask_true_partner_neighborhood(x, kind="acceptor", flank=12) for x in c]); Aa += a; Da += d
    a, d = site_scores(c, [mask_true_partner_neighborhood(x, kind="donor",    flank=12) for x in c]); Ad += a; Dd += d

def q(v, p): 
    s = sorted(v); return s[int(p*(len(s)-1))]
def summ(name, v):
    return {name: {"mean": st.mean(v), "median": st.median(v), "p10": q(v,.1), "p90": q(v,.9)}}
out = {}
out.update(summ("f(h_a*) CLEAN", Ac)); out.update(summ("f(h_a*) ACCEPTOR-MASKED", Aa))
out.update(summ("g(h_d*) CLEAN", Dc)); out.update(summ("g(h_d*) ACCEPTOR-MASKED", Da))
out.update(summ("g(h_d*) DONOR-MASKED", Dd)); out.update(summ("f(h_a*) DONOR-MASKED", Ad))
out["frac_examples_where_masking_acceptor_RAISES_its_own_score"] = st.mean([float(x>y) for x,y in zip(Aa,Ac)])
out["frac_examples_where_masking_donor_LOWERS_its_own_score"]    = st.mean([float(x<y) for x,y in zip(Dd,Dc)])
print(json.dumps(out, indent=2))

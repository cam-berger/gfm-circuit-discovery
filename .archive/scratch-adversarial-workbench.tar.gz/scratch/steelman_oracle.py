"""Steelman test.

Finding claims: oracle score(a,d)=M*1[a is a true site]+M*1[d is a true site] gets PMR=1.0,
so the task needs zero partner information.

Steelman: that oracle is really 1[a == the annotated site of THIS exon] -- the LABEL, not a
site property. A genuine biological splice-site detector fires on EVERY real splice site in the
window (alternative 3'/5' sites, neighbouring exons, other isoforms). If any decoy pair is built
from two GENUINE annotated splice sites, the site-detector oracle FAILS on it and partner
information is required to break the tie.

Test: map every candidate back to genomic coords, mark it real iff it is an annotated splice
site in the FULL GENCODE v50 annotation (union over ALL transcripts / isoforms / biotypes),
then recompute the oracle.
"""
import gzip
import json
from collections import defaultdict

GTF = "data/external/gencode/v50/gencode.v50.basic.annotation.gtf.gz"
CONF = "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl"

# ---------------------------------------------------------------- annotation
# Collect, per (chrom, strand), the set of genomic anchors of REAL splice sites,
# in exactly the repo's anchor convention (see schema.py / dataset.py):
#   + strand: acceptor anchor = exon.start(0-based first exonic base); donor anchor = exon.end (half-open)
#   - strand: acceptor anchor = exon.end - 1;                          donor anchor = exon.start - 1
# A transcript's FIRST exon start is a TSS, not an acceptor; its LAST exon end is a TES, not a donor.
exons_by_tx = defaultdict(list)
with gzip.open(GTF, "rt") as fh:
    for line in fh:
        if line[0] == "#":
            continue
        f = line.split("\t")
        if f[2] != "exon":
            continue
        chrom, start, end, strand, attrs = f[0], int(f[3]) - 1, int(f[4]), f[6], f[8]
        tx = attrs.split('transcript_id "', 1)[1].split('"', 1)[0]
        exons_by_tx[(chrom, strand, tx)].append((start, end))

real_acc = defaultdict(set)  # (chrom,strand) -> genomic anchors
real_don = defaultdict(set)
for (chrom, strand, _tx), ex in exons_by_tx.items():
    ex.sort()
    if len(ex) < 2:
        continue
    if strand == "+":
        order = ex
        for e in order[1:]:
            real_acc[(chrom, strand)].add(e[0])       # first exonic base
        for e in order[:-1]:
            real_don[(chrom, strand)].add(e[1])       # first intronic base after exon
    else:
        order = ex[::-1]                              # transcript order
        for e in order[1:]:
            real_acc[(chrom, strand)].add(e[1] - 1)   # last genomic base = first exonic base in tx orientation
        for e in order[:-1]:
            real_don[(chrom, strand)].add(e[0] - 1)   # first intronic base downstream in tx orientation
print(f"annotated transcripts parsed: {len(exons_by_tx)}")

# ---------------------------------------------------------------- conflict set
n = 0
label_oracle_hits = 0          # the finding's oracle: 1[a == a*] + 1[d == d*]
bio_oracle_hits = 0            # biological site detector: 1[a is ANY real acceptor] + 1[d is ANY real donor]
n_decoy_both_real = 0          # decoys built from two genuine sites
ex_with_such_decoy = 0
extra_real_acc_in_window = []
extra_real_don_in_window = []
true_acc_recovered = 0
true_don_recovered = 0

with open(CONF) as fh:
    for line in fh:
        d = json.loads(line)
        n += 1
        chrom, strand = d["chrom"], d["strand"]
        ws = d["metadata"]["genomic_window_start"]
        we = d["metadata"]["genomic_window_end"]
        seq_len = len(d["sequence"])

        def to_gen(i):
            return ws + i if strand == "+" else we - 1 - i

        RA = real_acc[(chrom, strand)]
        RD = real_don[(chrom, strand)]

        pairs = d["pairs"]
        tp = pairs[d["true_pair_index"]]
        ta, td = tp["acceptor_pos"], tp["donor_pos"]

        # sanity: the annotated true site must itself be in the real-site sets
        if to_gen(ta) in RA:
            true_acc_recovered += 1
        if to_gen(td) in RD:
            true_don_recovered += 1

        acc_real = {a["position"] for a in d["acceptors"] if to_gen(a["position"]) in RA}
        don_real = {x["position"] for x in d["donors"] if to_gen(x["position"]) in RD}
        extra_real_acc_in_window.append(len(acc_real - {ta}))
        extra_real_don_in_window.append(len(don_real - {td}))

        # ---- finding's LABEL oracle
        best_decoy_label = 0
        # ---- BIOLOGICAL site-detector oracle
        best_decoy_bio = 0
        both_real_here = 0
        for p in pairs:
            a, dd = p["acceptor_pos"], p["donor_pos"]
            if a == ta and dd == td:
                continue
            best_decoy_label = max(best_decoy_label, (a == ta) + (dd == td))
            s = (a in acc_real) + (dd in don_real)
            if s == 2:
                both_real_here += 1
            best_decoy_bio = max(best_decoy_bio, s)
        if 2 > best_decoy_label:
            label_oracle_hits += 1
        true_bio = (ta in acc_real) + (td in don_real)
        if true_bio > best_decoy_bio:
            bio_oracle_hits += 1
        n_decoy_both_real += both_real_here
        if both_real_here:
            ex_with_such_decoy += 1

print(f"\nn conflict examples = {n}")
print(f"true acceptor confirmed as annotated real site: {true_acc_recovered}/{n}")
print(f"true donor    confirmed as annotated real site: {true_don_recovered}/{n}")
print(f"\nLABEL oracle  1[a==a*]+1[d==d*]           PMR = {label_oracle_hits/n:.4f}")
print(f"BIO   oracle  1[a real]+1[d real] (all isoforms) PMR = {bio_oracle_hits/n:.4f}")
print(f"\nexamples containing >=1 decoy made of TWO genuine annotated sites: {ex_with_such_decoy}/{n} = {ex_with_such_decoy/n:.4f}")
print(f"total such decoys: {n_decoy_both_real}")
import statistics as st
print(f"extra real ACCEPTORS in window (besides true): mean {st.mean(extra_real_acc_in_window):.3f} median {st.median(extra_real_acc_in_window)} max {max(extra_real_acc_in_window)}")
print(f"extra real DONORS    in window (besides true): mean {st.mean(extra_real_don_in_window):.3f} median {st.median(extra_real_don_in_window)} max {max(extra_real_don_in_window)}")
frac_a = sum(1 for x in extra_real_acc_in_window if x > 0) / n
frac_d = sum(1 for x in extra_real_don_in_window if x > 0) / n
print(f"examples with >=1 OTHER real acceptor in window: {frac_a:.4f}")
print(f"examples with >=1 OTHER real donor    in window: {frac_d:.4f}")

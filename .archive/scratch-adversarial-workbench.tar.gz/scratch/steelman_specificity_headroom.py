#!/usr/bin/env python
"""Steelman test of the finding: "specificity=false is quantitatively explained by
margin headroom; the ablation effect is BOUNDED BY and SCALES WITH the clean margin,
so the specificity test cannot pass even in principle."

Three checks, all read-only, on the real frozen splits + seed0 additive-frozen ckpt:

  (1) BOUNDEDNESS.  Is `base - ablated` capped by the clean margin?  Measure the
      margin under (a) mean-ablation of the AtP-selected 5-head set C, (b) mean-
      ablation of ALL 96 heads, (c) the donor-mask corruption.  If the margin can go
      NEGATIVE, the effect has no ceiling and "cannot pass in principle" is false.

  (2) PROPORTIONALITY, per example.  Regress per-example effect on per-example clean
      margin WITHIN each set.  The finding's mechanism requires a strong positive
      slope (effect ~= (1-alpha)*margin).  Report r, slope, intercept.

  (3) HEADROOM-MATCHED SPECIFICITY.  Fit effect ~ margin on ORDINARY, predict the
      effect at Vc's mean margin, and compare to the observed Vc effect.  Also
      compare Vc against the margin-matched subset of O.  If headroom fully explains
      it, observed_Vc ~= predicted_Vc.
"""
from __future__ import annotations

import json
from pathlib import Path
import sys

import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))

from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.circuits.attribution import head_attribution_scan  # noqa: E402
from gfmcd.circuits.hf_bert import capture_head_outputs, edit_heads  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.context_controls import mask_true_partner_neighborhood  # noqa: E402
from gfmcd.splicing.io import load_jsonl  # noqa: E402
from gfmcd.splicing.readout import collate_pair_indices, true_pair_margin  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint  # noqa: E402

N_D = 64
N_EVAL = 192
SET_SIZE = 5
BATCH = 8

device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"])
mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
ckpt = REPO / "colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt"
readout, checkpoint = load_pair_checkpoint(ckpt, adapter=adapter)
assert checkpoint.get("backbone_state") is None
print("regime:", checkpoint.get("extra_metadata", {}).get("regime"),
      "| readout:", type(readout).__name__, "| rep:", rep, "| device:", device)

sd = REPO / "results/splicebert_partner_selection/circuits/discovery"
D = load_jsonl(sd / "discovery.jsonl")[:N_D]
Vc = load_jsonl(sd / "confirmation.jsonl")[:N_EVAL]
O = load_jsonl(sd / "ordinary.jsonl")[:N_EVAL]
print(f"D={len(D)}  Vc={len(Vc)}  O={len(O)}")


def batches(examples, corrupt=None):
    out = []
    for i in range(0, len(examples), BATCH):
        ex = examples[i:i + BATCH]
        seqs = [corrupt(x) for x in ex] if corrupt else [x.sequence for x in ex]
        tok = adapter.tokenize(seqs)
        pb = collate_pair_indices(ex, token_offset=tok.prefix_tokens, device=adapter.device)
        out.append((ex, tok, pb))
    return out


def margin_sum(tok, pb, grad=False):
    out = adapter.forward(tok, output_hidden_states=True, output_attentions=False, grad=grad)
    return true_pair_margin(readout(out.hidden_states[rep], pb), pb).sum()


def margins(bs, ablate=None):
    """per-example true-pair margins"""
    vals = []
    with torch.no_grad():
        for ex, tok, pb in bs:
            if ablate is not None:
                with edit_heads(adapter, ablate[0], mode=ablate[1]):
                    out = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
            else:
                out = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
            m = true_pair_margin(readout(out.hidden_states[rep], pb), pb)
            vals.extend(m.float().cpu().tolist())
    return torch.tensor(vals)


# ---------- head selection: same AtP necessity recipe as run_tracing.py ----------
Db = batches(D)
agg: dict[tuple[int, int], float] = {}
for ex, tok, pb in Db:
    with torch.no_grad():
        cache = capture_head_outputs(adapter, lambda tok=tok, pb=pb: float(margin_sum(tok, pb)))
    zeros = {l: torch.zeros_like(v) for l, v in cache.items()}
    res = head_attribution_scan(adapter, zeros, lambda tok=tok, pb=pb: margin_sum(tok, pb, grad=True))
    for e in res:
        agg[(e.layer, e.head)] = agg.get((e.layer, e.head), 0.0) - e.attribution
C = [k for k, _ in sorted(agg.items(), key=lambda kv: kv[1], reverse=True)[:SET_SIZE]]
ALL = [(l, h) for l in range(adapter.num_layers) for h in range(adapter.num_heads)]
print("AtP top-5 C =", C)

Vb, Ob = batches(Vc), batches(O)
res = {}
res["C"] = [list(c) for c in C]
res["n"] = N_EVAL

m_vc = margins(Vb)
m_o = margins(Ob)
a_vc = margins(Vb, ablate=(C, "mean"))
a_o = margins(Ob, ablate=(C, "mean"))
e_vc, e_o = m_vc - a_vc, m_o - a_o

print("\n=== [0] reproduce the specificity numbers ===")
print(f"  clean margin  Vc {m_vc.mean():+.4f}   O {m_o.mean():+.4f}   ratio {m_o.mean()/m_vc.mean():.3f}")
print(f"  effect  of C  Vc {e_vc.mean():+.4f}   O {e_o.mean():+.4f}   ratio {e_o.mean()/e_vc.mean():.3f}")
print(f"  normalized effect (effect/clean margin):  Vc {e_vc.mean()/m_vc.mean():.4f}   O {e_o.mean()/m_o.mean():.4f}")

print("\n=== [1] BOUNDEDNESS: can the effect exceed the clean margin? ===")
all_vc = margins(Vb, ablate=(ALL, "mean"))
dm_vc = margins(batches(Vc, corrupt=lambda x: mask_true_partner_neighborhood(x, kind="donor", flank=12)))
am_vc = margins(batches(Vc, corrupt=lambda x: mask_true_partner_neighborhood(x, kind="acceptor", flank=12)))
print(f"  mean margin, ablate ALL 96 heads (Vc):  {all_vc.mean():+.4f}"
      f"   -> effect {float(m_vc.mean()-all_vc.mean()):+.4f}  ({float((m_vc.mean()-all_vc.mean())/m_vc.mean()):.2f}x the clean margin)")
print(f"  mean margin, donor-mask corruption (Vc): {dm_vc.mean():+.4f}"
      f"   -> gap {float(m_vc.mean()-dm_vc.mean()):+.4f}  ({float((m_vc.mean()-dm_vc.mean())/m_vc.mean()):.2f}x the clean margin)")
print(f"  mean margin, acceptor-mask corruption (Vc): {am_vc.mean():+.4f}  -> gap {float(m_vc.mean()-am_vc.mean()):+.4f}")
print(f"  per-example: frac of Vc where the 5-head effect EXCEEDS that example's clean margin: "
      f"{float((e_vc > m_vc).float().mean()):.3f}")
print(f"  per-example: frac of Vc where ALL-head ablation drives the margin NEGATIVE: "
      f"{float((all_vc < 0).float().mean()):.3f}")
res["boundedness"] = dict(
    clean_vc=float(m_vc.mean()), all_head_ablate_vc=float(all_vc.mean()),
    donor_mask_vc=float(dm_vc.mean()), acceptor_mask_vc=float(am_vc.mean()),
    frac_effect_exceeds_own_margin=float((e_vc > m_vc).float().mean()),
    frac_allhead_negative=float((all_vc < 0).float().mean()))


def ols(x, y):
    x, y = x.double(), y.double()
    xm, ym = x.mean(), y.mean()
    sxx = ((x - xm) ** 2).sum()
    sxy = ((x - xm) * (y - ym)).sum()
    b = sxy / sxx
    a = ym - b * xm
    r = sxy / (sxx.sqrt() * ((y - ym) ** 2).sum().sqrt())
    return float(a), float(b), float(r)


print("\n=== [2] PROPORTIONALITY per example (effect ~ clean margin) ===")
for name, m, e in (("Vc", m_vc, e_vc), ("O", m_o, e_o)):
    a, b, r = ols(m, e)
    print(f"  {name:2s}: r = {r:+.3f}   slope = {b:+.4f}   intercept = {a:+.4f}"
          f"   (proportionality needs r~1, slope>0, intercept~0)")
    res[f"ols_{name}"] = dict(r=r, slope=b, intercept=a)

print("\n=== [3] HEADROOM-MATCHED SPECIFICITY ===")
a_o_, b_o_, r_o_ = ols(m_o, e_o)
pred_vc = a_o_ + b_o_ * float(m_vc.mean())
print(f"  O-fitted line predicts effect at Vc's mean margin ({float(m_vc.mean()):.3f}): {pred_vc:+.4f}")
print(f"  OBSERVED Vc effect: {float(e_vc.mean()):+.4f}   -> observed/predicted = {float(e_vc.mean())/pred_vc:.3f}")
lo, hi = float(m_vc.quantile(0.1)), float(m_vc.quantile(0.9))
sel = (m_o >= lo) & (m_o <= hi)
print(f"  margin-matched O subset (clean margin in Vc's 10-90 pct range [{lo:.2f},{hi:.2f}]): n={int(sel.sum())}")
if int(sel.sum()) > 10:
    print(f"    clean margin {float(m_o[sel].mean()):+.4f} (vs Vc {float(m_vc.mean()):+.4f})")
    print(f"    effect       {float(e_o[sel].mean()):+.4f} (vs Vc {float(e_vc.mean()):+.4f})"
          f"   -> conflict_gt_ordinary at matched headroom: {float(e_vc.mean()) > float(e_o[sel].mean())}")
    res["matched"] = dict(n=int(sel.sum()), o_margin=float(m_o[sel].mean()), o_effect=float(e_o[sel].mean()),
                          vc_margin=float(m_vc.mean()), vc_effect=float(e_vc.mean()),
                          conflict_gt_ordinary=bool(float(e_vc.mean()) > float(e_o[sel].mean())))
res["pred_vc_from_O_line"] = pred_vc
res["specificity"] = dict(clean_vc=float(m_vc.mean()), clean_o=float(m_o.mean()),
                          eff_vc=float(e_vc.mean()), eff_o=float(e_o.mean()),
                          norm_vc=float(e_vc.mean() / m_vc.mean()), norm_o=float(e_o.mean() / m_o.mean()))
json.dump(res, open(REPO / "scratch/steelman_specificity_headroom_results.json", "w"), indent=2)
print("\nwrote scratch/steelman_specificity_headroom_results.json")

"""AUDIT: gene-bootstrap CIs for the 'restore L3H1 head output @all-pos' rescue, for the
circuit head (L2H15) and for a NON-circuit head (L1H12), at the same n the paper uses."""
import sys
from contextlib import ExitStack
from pathlib import Path

import numpy as np
import torch

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "src"))

from gfmcd.splicing.circuit import (  # noqa: E402
    ADDRESSER, DEFAULT_FASTA, DEFAULT_GTF, DEFAULT_MODEL, READER, CouplingTask, ablate,
    capture_head_outputs, gboot_ratio, load_adapter, load_examples, patch_heads,
    pick_device, ratio_of_means,
)

N, BATCH = 60, 6
dev = pick_device(None)
ad = load_adapter(DEFAULT_MODEL, dev)
task = CouplingTask(ad, batch=BATCH)
X, _ = load_examples(DEFAULT_GTF, DEFAULT_FASTA, "val", N, task=task, tag="l2acct-val",
                     min_effect=0.3)
genes = [x.gene_id for x in X]

SETS = [("L2H15  (IN the circuit)", ADDRESSER), ("L1H12  (NOT in the circuit)", (1, 12)),
        ("L2H8   (NOT in the circuit)", (2, 8))]
num = {k: [] for k, _ in SETS}
dnm = {k: [] for k, _ in SETS}

with torch.no_grad():
    for i in range(0, len(X), BATCH):
        cl, co, dn = task.pair(X[i:i + BATCH])
        h_cl = capture_head_outputs(ad, lambda: ad.model(**cl))
        h_co = capture_head_outputs(ad, lambda: ad.model(**co))
        cbase = (task.margin(ad.model(**cl).logits.float(), dn)
                 - task.margin(ad.model(**co).logits.float(), dn))
        for name, z in SETS:
            ABL = ablate(ad, [z])
            with ABL():
                cabl = (task.margin(ad.model(**cl).logits.float(), dn)
                        - task.margin(ad.model(**co).logits.float(), dn))
            with ExitStack() as st:
                st.enter_context(ABL()); st.enter_context(patch_heads(ad, h_cl, [READER]))
                r_cl = task.margin(ad.model(**cl).logits.float(), dn)
            with ExitStack() as st:
                st.enter_context(ABL()); st.enter_context(patch_heads(ad, h_co, [READER]))
                r_co = task.margin(ad.model(**co).logits.float(), dn)
            dnm[name] += (cbase - cabl).tolist()
            num[name] += ((r_cl - r_co) - cabl).tolist()
        print(f"  {min(i+BATCH, len(X))}/{len(X)}", end="\r", flush=True)
print()
print("=" * 78)
print("rescue of Z's effect by restoring L3H1's HEAD OUTPUT @all-pos  (n=60 val exons)")
print(f"{'ablated Z':30s} {'Z supplies':>11s} {'rescue':>8s} {'95% CI (gene-boot)':>22s}")
for name, z in SETS:
    r = ratio_of_means(num[name], dnm[name])
    lo, hi = gboot_ratio(num[name], dnm[name], genes)
    print(f"{name:30s} {np.mean(dnm[name]):11.3f} {r:8.3f}   [{lo:+.3f},{hi:+.3f}]")
print("=" * 78)

#!/usr/bin/env python
"""Referee test for the finding: 'the matched-random head null is matched only on cardinality'.

Reproduces run_tracing.py's four-filter search on the frozen discovery split D
(AtP top-16 -> >=2/3-null necessity -> both-mask mediation -> top-5 rank cut),
then evaluates C's joint mean-ablation effect on the GENE-DISJOINT confirmation
split V_c against THREE nulls:

  N1 uniform      : the repo's null (k heads uniform from the 96-|C| universe)
  N2 layer-matched: k heads drawn ONLY from layers 2-4 (the finding's predicted
                    signature (a))
  N3 magnitude-matched: k heads whose MARGINAL single-head mean-ablation effect on
                    D is nearest-matched to C's (the finding's predicted signature (b))

Also dumps the full 96-head marginal effect landscape on both D and V_c.
Read-only w.r.t. the repo: writes only into scratch/.
"""
from __future__ import annotations

import json
from pathlib import Path
import random
import statistics as st
import sys
import time

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))
sys.path.insert(0, str(REPO / "scripts" / "splicebert"))

import torch  # noqa: E402

from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.circuits.hf_bert import matched_random_head_sets  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.context_controls import mask_true_partner_neighborhood  # noqa: E402
from gfmcd.splicing.io import load_jsonl  # noqa: E402
from gfmcd.splicing.metrics import matched_random_pvalue  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint, set_seed  # noqa: E402

from run_tracing import Chunk, Scorer, add_clean_cache, build_chunks, single_head_recovery  # noqa: E402

N_D = 128
N_VC = 96
BATCH = 16
SHORTLIST = 16
N_NULL = 150
SEED = 0

t_start = time.time()


def log(msg):
    print(f"[{time.time() - t_start:7.1f}s] {msg}", flush=True)


set_seed(SEED)
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"])
set_size = int(cfg["circuit"].get("default_component_set_size", 5))
mc = cfg["model"]

adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device="mps",
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
ckpt = REPO / "colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt"
readout, checkpoint = load_pair_checkpoint(ckpt, adapter=adapter)
assert checkpoint["extra_metadata"]["regime"] == "additive-frozen"
assert checkpoint.get("backbone_state") is None, "backbone must be the frozen pretrained one"
S = Scorer(adapter, readout, rep)

sd = REPO / "results/splicebert_partner_selection/circuits/discovery"
D = load_jsonl(sd / "discovery.jsonl")[:N_D]
Vc = load_jsonl(sd / "confirmation.jsonl")[:N_VC]
assert not ({x.gene_id for x in D} & {x.gene_id for x in Vc}), "D/Vc gene overlap!"
log(f"D={len(D)} ({len({x.gene_id for x in D})} genes)  Vc={len(Vc)} ({len({x.gene_id for x in Vc})} genes)  gene-disjoint OK")

flank = 12
masks = {
    "acceptor-mask": lambda exs: [mask_true_partner_neighborhood(x, kind="acceptor", flank=flank) for x in exs],
    "donor-mask": lambda exs: [mask_true_partner_neighborhood(x, kind="donor", flank=flank) for x in exs],
}


def chunks_of(examples, corrupt=None, cache=False):
    cs = [c for _e, c in build_chunks(adapter, examples, BATCH, corrupt=corrupt)]
    if cache:
        add_clean_cache(S, cs)
    return cs


D_clean = chunks_of(D, cache=True)
Vc_clean = chunks_of(Vc)
all_heads = [(l, h) for l in range(adapter.num_layers) for h in range(adapter.num_heads)]
log(f"chunks built; {len(all_heads)} heads")

# ---------------- SELECTION on D (exactly run_tracing.py steps 0-2c) ----------------
zeros = [Chunk(tok=c.tok, pair_batch=c.pair_batch, n=c.n,
               clean_cache={l: torch.zeros_like(c.clean_cache[l]) for l in c.clean_cache})
         for c in D_clean]
neg = S.attribution(zeros, D_clean)
nec_attr = {k: -v for k, v in neg.items()}
nec_short = [k for k, _ in sorted(nec_attr.items(), key=lambda kv: kv[1], reverse=True)[:SHORTLIST]]
med_short = {}
for mask in ("acceptor-mask", "donor-mask"):
    D_cor = chunks_of(D, corrupt=masks[mask])
    attr = S.attribution(D_clean, D_cor)
    med_short[mask] = [kk for kk, _ in sorted(attr.items(), key=lambda kv: kv[1], reverse=True)[:SHORTLIST]]
shortlist = sorted(set(nec_short) | set(med_short["acceptor-mask"]) | set(med_short["donor-mask"]))
log(f"AtP shortlist ({len(shortlist)}): {shortlist}")

base_D = S.mean(D_clean)
nec_effects = {}
for head in shortlist:
    nec_effects[head] = [base_D - S.mean(D_clean, ablate=([head], m)) for m in ("zero", "mean", "resample")]
N = {h: e for h, e in nec_effects.items() if sum(x > 0 for x in e) >= 2 and st.median(e) > 0}
log(f"necessity set N ({len(N)}): {sorted(N)}")

recovery_D = {m: {} for m in ("acceptor-mask", "donor-mask")}
for mask in ("acceptor-mask", "donor-mask"):
    D_cor = chunks_of(D, corrupt=masks[mask])
    clean_s, corr_s = base_D, S.mean(D_cor)
    gap = clean_s - corr_s
    for head in shortlist:
        recovery_D[mask][head] = single_head_recovery(S, D_clean, D_cor, head, clean_s, corr_s, gap)
M = [h for h in shortlist
     if recovery_D["acceptor-mask"].get(h, -1) > 0 and recovery_D["donor-mask"].get(h, -1) > 0]
conv = [h for h in M if h in N]
conv.sort(key=lambda h: (st.median(N[h]) + 0.5 * (recovery_D["acceptor-mask"][h] + recovery_D["donor-mask"][h])),
          reverse=True)
C = conv[:set_size]
k = len(C)
log(f"mediation M ({len(M)}): {M}")
log(f"CANDIDATE CIRCUIT C (k={k}): {C}")
assert k > 0, "no convergent set on this subsample"

# ---------------- full 96-head MARGINAL landscape (mean-ablation) on D and Vc ----------------
marg_D = {h: base_D - S.mean(D_clean, ablate=([h], "mean")) for h in all_heads}
log("marginal 96-head effects on D done")
base_Vc = S.mean(Vc_clean)
marg_Vc = {h: base_Vc - S.mean(Vc_clean, ablate=([h], "mean")) for h in all_heads}
log("marginal 96-head effects on Vc done")

# ---------------- OBSERVED joint effect of C on held-out Vc ----------------
obs = base_Vc - S.mean(Vc_clean, ablate=(C, "mean"))
log(f"base_Vc={base_Vc:.4f}  observed joint effect of C on Vc = {obs:.4f}")

# ---------------- NULLS ----------------
def eval_sets(sets):
    return [base_Vc - S.mean(Vc_clean, ablate=(list(s), "mean")) for s in sets]


rng = random.Random(1234)
n1_sets = matched_random_head_sets(adapter, C, n=N_NULL, seed=0, exclude_selected=True)
layer_universe = [h for h in all_heads if h[0] in (2, 3, 4) and h not in C]
n2_sets = [tuple(sorted(rng.sample(layer_universe, k))) for _ in range(N_NULL)]
pool = [h for h in all_heads if h not in C]
n3_sets = []
for _ in range(N_NULL):
    chosen: set = set()
    for c in C:
        nbrs = sorted(pool, key=lambda h: abs(marg_D[h] - marg_D[c]))
        nbrs = [h for h in nbrs if h not in chosen][:8]
        chosen.add(rng.choice(nbrs))
    n3_sets.append(tuple(sorted(chosen)))

results = {}
for name, sets in (("N1_uniform_repo", n1_sets), ("N2_layer_matched_L2_L4", n2_sets),
                   ("N3_magnitude_matched_on_D", n3_sets)):
    eff = eval_sets(sets)
    eff_s = sorted(eff)
    results[name] = {
        "n": len(eff), "mean": st.mean(eff), "sd": st.pstdev(eff),
        "p95": eff_s[int(0.95 * len(eff_s))], "max": max(eff),
        "p_add_one": matched_random_pvalue(obs, eff),
        "frac_null_ge_obs": sum(e >= obs for e in eff) / len(eff),
    }
    log(f"{name}: mean={results[name]['mean']:.4f} p95={results[name]['p95']:.4f} "
        f"max={results[name]['max']:.4f} p={results[name]['p_add_one']:.4f}")

by_layer_D = {l: [marg_D[(l, h)] for h in range(adapter.num_heads)] for l in range(adapter.num_layers)}
by_layer_Vc = {l: [marg_Vc[(l, h)] for h in range(adapter.num_heads)] for l in range(adapter.num_layers)}

out = {
    "n_D": len(D), "n_Vc": len(Vc), "k": k, "C": [list(h) for h in C],
    "shortlist": [list(h) for h in shortlist],
    "base_D": base_D, "base_Vc": base_Vc,
    "observed_joint_effect_C_on_Vc": obs,
    "sum_of_marginals_C_on_Vc": sum(marg_Vc[h] for h in C),
    "nulls": results,
    "C_marginal_effects": {"on_D": {f"{l}-{h}": marg_D[(l, h)] for (l, h) in C},
                           "on_Vc": {f"{l}-{h}": marg_Vc[(l, h)] for (l, h) in C}},
    "marginal_by_layer_D": {str(l): {"mean": st.mean(v), "max": max(v), "min": min(v)} for l, v in by_layer_D.items()},
    "marginal_by_layer_Vc": {str(l): {"mean": st.mean(v), "max": max(v), "min": min(v)} for l, v in by_layer_Vc.items()},
    "marginal_all_D": {f"{l}-{h}": marg_D[(l, h)] for (l, h) in all_heads},
    "marginal_all_Vc": {f"{l}-{h}": marg_Vc[(l, h)] for (l, h) in all_heads},
    "rank_of_C_marginals_on_Vc": {
        f"{l}-{h}": sorted(all_heads, key=lambda x: -marg_Vc[x]).index((l, h)) + 1 for (l, h) in C},
}
(REPO / "scratch/ref_null_reference_class_results.json").write_text(json.dumps(out, indent=2) + "\n")
log("WROTE scratch/ref_null_reference_class_results.json")

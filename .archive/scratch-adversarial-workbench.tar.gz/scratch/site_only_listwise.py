#!/usr/bin/env python
"""SITE-ONLY probe, listwise variant: train the acceptor head and donor head as
per-window site classifiers (softmax cross-entropy over ALL same-kind candidate
positions in the window -- the natural site-detection analogue of the pair softmax).
NO pair is ever formed during training. Then score conflict pairs as
f(h_a) + g(h_d) + w*length_prior(L) and compare to the pair-supervised 0.807.
"""
from __future__ import annotations

import json
from pathlib import Path
import pickle
import sys

import torch
import torch.nn as nn
import torch.nn.functional as F

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))

from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.schema import SplicePairExample  # noqa: E402

N_TRAIN = 2500
N_EVAL = 1000
BATCH = 8
EPOCHS = 25
SEED = 0
torch.manual_seed(SEED)

device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"])
mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
with (REPO / "colab_results/splicebert_run/baselines/local_pair_baseline.pkl").open("rb") as fh:
    lp = pickle.load(fh).length_prior


def load(path: Path, n: int):
    out = []
    with path.open() as f:
        for line in f:
            if line.strip():
                out.append(SplicePairExample.from_json(line))
            if len(out) >= n:
                break
    return out


train_ex = load(REPO / "data/processed/splicebert_partner_selection/v1/train.jsonl", N_TRAIN)
eval_ex = load(REPO / "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl", N_EVAL)
print(f"train {len(train_ex)} eval {len(eval_ex)} device {device}")


@torch.no_grad()
def embed(chunk):
    tok = adapter.tokenize([x.sequence for x in chunk])
    out = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
    return out.hidden_states[rep], tok.prefix_tokens


# cache per-example site features (CPU float32) -- NO pairs
store = {"acceptor": [], "donor": []}  # list of (feats[n_sites,512], true_idx)
for i in range(0, len(train_ex), BATCH):
    chunk = train_ex[i:i + BATCH]
    hidden, off = embed(chunk)
    for k, x in enumerate(chunk):
        tp = x.pairs[x.true_pair_index]
        for kind, sites, truepos in (("acceptor", x.acceptors, tp.acceptor_pos),
                                     ("donor", x.donors, tp.donor_pos)):
            pos = [s.position for s in sites]
            idx = torch.tensor([p + off for p in pos], device=hidden.device)
            store[kind].append((hidden[k].index_select(0, idx).float().cpu(), pos.index(truepos)))
    if i % 400 == 0:
        print("  embed", i, flush=True)


def make_head():
    return nn.Sequential(nn.LayerNorm(512), nn.Linear(512, 128), nn.GELU(), nn.Linear(128, 1))


heads = {}
for kind in ("acceptor", "donor"):
    head = make_head().to(device)
    opt = torch.optim.AdamW(head.parameters(), lr=1e-3, weight_decay=0.01)
    items = store[kind]
    order = torch.randperm(len(items))
    for epoch in range(EPOCHS):
        order = torch.randperm(len(items))
        tot = 0.0
        correct = 0
        for j in order.tolist():
            X, t = items[j]
            opt.zero_grad()
            logit = head(X.to(device)).squeeze(-1)
            loss = F.cross_entropy(logit[None, :], torch.tensor([t], device=device))
            loss.backward()
            opt.step()
            tot += loss.item()
            correct += int(int(logit.argmax()) == t)
        if epoch % 5 == 4:
            print(f"  {kind} epoch {epoch} loss {tot/len(items):.4f} train top1 {correct/len(items):.4f}", flush=True)
    heads[kind] = head.eval()

weights = [0.0, 0.5, 1.0, 2.0]
hits = {w: 0 for w in weights}
acc1 = don1 = n = 0
for i in range(0, len(eval_ex), BATCH):
    chunk = eval_ex[i:i + BATCH]
    hidden, off = embed(chunk)
    for k, x in enumerate(chunk):
        h = hidden[k]
        a_pos = [s.position for s in x.acceptors]
        d_pos = [s.position for s in x.donors]
        with torch.no_grad():
            fa = heads["acceptor"](h.index_select(0, torch.tensor([p + off for p in a_pos], device=h.device)).float()).squeeze(-1).cpu()
            gd = heads["donor"](h.index_select(0, torch.tensor([p + off for p in d_pos], device=h.device)).float()).squeeze(-1).cpu()
        tp = x.pairs[x.true_pair_index]
        ai = a_pos.index(tp.acceptor_pos)
        di = d_pos.index(tp.donor_pos)
        acc1 += int(int(fa.argmax()) == ai)
        don1 += int(int(gd.argmax()) == di)
        base = fa[torch.tensor([p.acceptor_index for p in x.pairs])] + gd[torch.tensor([p.donor_index for p in x.pairs])]
        lpr = torch.tensor([lp.score(p.exon_length) for p in x.pairs])
        t = x.true_pair_index
        for w in weights:
            s = base + w * lpr
            s2 = s.clone()
            s2[t] = float("-inf")
            hits[w] += int(s[t].item() > s2.max().item())
        n += 1

print("\n==== SITE-ONLY LISTWISE (no pair supervision) ====")
print(f"n={n}; true-acceptor top1 {acc1/n:.4f}; true-donor top1 {don1/n:.4f}")
for w in weights:
    print(f"conflict PMR (length weight {w}): {hits[w]/n:.4f}")
print("pair-supervised additive-frozen reference: 0.807")
json.dump({"n": n, "acc_top1": acc1 / n, "don_top1": don1 / n,
           "pmr": {str(w): hits[w] / n for w in weights}, "n_train": len(train_ex)},
          open(REPO / "scratch/site_only_listwise_results.json", "w"), indent=2)

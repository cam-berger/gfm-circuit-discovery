#!/usr/bin/env python
"""REFEREE data-check of the finding: 'the donor-mask margin gap is a 1:1 pass-through
of destruction of the true donor's own additive site score g(h_d*)'.

For seeds 0 and 1 (additive-frozen, local checkpoints), on the FULL confirmation.jsonl
(n=512, the exact Vc used by run_tracing), flank=12:

  clean vs corrupt (acceptor-mask / donor-mask / site-windows-only):
    - mean true-pair margin  -> gap = clean - corrupt   (this is run_tracing's `gap`)
    - mean f(h_a*), g(h_d*), L(len*) at the TRUE pair
    - per-example Delta(margin) vs Delta(site term): slope, r, residual
    - decomposition of the margin gap into: d_true_A + d_true_D - d_bestdecoy
Read-only.
"""
from __future__ import annotations

import json
from pathlib import Path
import sys

import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))

from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.context_controls import (  # noqa: E402
    mask_true_partner_neighborhood, retain_site_windows,
)
from gfmcd.splicing.io import load_jsonl  # noqa: E402
from gfmcd.splicing.readout import collate_pair_indices  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint  # noqa: E402

BATCH = 8
FLANK = 12
NEG = float("-inf")

device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"])
mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))

readouts = {}
for seed in (0, 1):
    ck = REPO / f"colab_results/splicebert_run/runs/additive-frozen_seed{seed}/checkpoint.pt"
    r, meta = load_pair_checkpoint(ck, adapter=adapter)
    assert meta.get("backbone_state") is None
    assert meta.get("extra_metadata", {}).get("regime") == "additive-frozen"
    readouts[seed] = r
    print(f"seed{seed}: {type(r).__name__}  regime ok  backbone_state=None")

V = load_jsonl(REPO / "results/splicebert_partner_selection/circuits/discovery/confirmation.jsonl")
print(f"Vc n={len(V)}  rep_layer={rep}  device={device}  flank={FLANK}")

CORRUPT = {
    "clean": None,
    "acceptor-mask": lambda exs: [mask_true_partner_neighborhood(x, kind="acceptor", flank=FLANK) for x in exs],
    "donor-mask": lambda exs: [mask_true_partner_neighborhood(x, kind="donor", flank=FLANK) for x in exs],
    "site-windows-only": lambda exs: [retain_site_windows(x, flank=FLANK, include_all_candidates=True) for x in exs],
}


def run(cond):
    """Return per-seed per-example dicts of margin / true-pair terms / best-decoy info."""
    fn = CORRUPT[cond]
    out = {s: {k: [] for k in ("margin", "A", "D", "L", "best", "decoy_idx", "shares_acc", "shares_don")}
           for s in readouts}
    for i in range(0, len(V), BATCH):
        ex = V[i:i + BATCH]
        seqs = fn(ex) if fn else [x.sequence for x in ex]
        tok = adapter.tokenize(seqs)
        pb = collate_pair_indices(ex, token_offset=tok.prefix_tokens, device=adapter.device)
        with torch.no_grad():
            o = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
            hid = o.hidden_states[rep]
            b = torch.arange(hid.shape[0], device=hid.device)[:, None]
            acc_h = hid[b, pb.positions[..., 0]]
            don_h = hid[b, pb.positions[..., 1]]
            for s, r in readouts.items():
                A = r.acceptor(acc_h).squeeze(-1).float().cpu()
                Dn = r.donor(don_h).squeeze(-1).float().cpu()
                L = r.length(r._length_features(pb.lengths)).squeeze(-1).float().cpu()
                m_all = pb.mask.cpu()
                accp, donp = pb.positions[..., 0].cpu(), pb.positions[..., 1].cpu()
                for k, x in enumerate(ex):
                    m = m_all[k]
                    sc = (A[k] + Dn[k] + L[k]).masked_fill(~m, NEG)
                    t = x.true_pair_index
                    d = sc.clone(); d[t] = NEG
                    j = int(d.argmax())
                    o_ = out[s]
                    o_["margin"].append(float(sc[t] - sc[j]))
                    o_["A"].append(float(A[k][t])); o_["D"].append(float(Dn[k][t])); o_["L"].append(float(L[k][t]))
                    o_["best"].append(float(sc[j]))
                    o_["decoy_idx"].append(j)
                    o_["shares_acc"].append(int(accp[k][j]) == int(accp[k][t]))
                    o_["shares_don"].append(int(donp[k][j]) == int(donp[k][t]))
    return out


res = {c: run(c) for c in CORRUPT}
mean = lambda v: sum(v) / len(v)

report = {}
for s in readouts:
    cl = res["clean"][s]
    print(f"\n================ seed {s} ================")
    print(f"clean: mean margin {mean(cl['margin']):+.4f} | mean f(h_a*) {mean(cl['A']):+.4f} "
          f"| mean g(h_d*) {mean(cl['D']):+.4f} | mean L {mean(cl['L']):+.4f}")
    print(f"clean: top decoy shares true acceptor {mean(cl['shares_acc']):.3f} | shares true donor {mean(cl['shares_don']):.3f}")
    report[f"seed{s}"] = {"clean": {k: mean(cl[k]) for k in ("margin", "A", "D", "L", "shares_acc", "shares_don")}}
    for cond in ("acceptor-mask", "donor-mask", "site-windows-only"):
        co = res[cond][s]
        gap = mean(cl["margin"]) - mean(co["margin"])
        dA = mean(cl["A"]) - mean(co["A"])      # destruction of the TRUE acceptor's own term
        dD = mean(cl["D"]) - mean(co["D"])      # destruction of the TRUE donor's own term
        dbest = mean(cl["best"]) - mean(co["best"])
        own = dA if cond == "acceptor-mask" else dD
        # per-example regression of d_margin on d_own_site_term
        dm = [a - b for a, b in zip(cl["margin"], co["margin"])]
        if cond == "acceptor-mask":
            ds = [a - b for a, b in zip(cl["A"], co["A"])]
        elif cond == "donor-mask":
            ds = [a - b for a, b in zip(cl["D"], co["D"])]
        else:
            ds = [(a1 - b1) + (a2 - b2) for a1, b1, a2, b2 in
                  zip(cl["A"], co["A"], cl["D"], co["D"])]
        n = len(dm)
        mx, my = mean(ds), mean(dm)
        sxx = sum((x - mx) ** 2 for x in ds); syy = sum((y - my) ** 2 for y in dm)
        sxy = sum((x - mx) * (y - my) for x, y in zip(ds, dm))
        slope = sxy / sxx if sxx else float("nan")
        r = sxy / (sxx * syy) ** 0.5 if sxx and syy else float("nan")
        pt = gap / own if abs(own) > 1e-9 else float("nan")
        print(f"\n  [{cond}]")
        print(f"    margin gap (clean-corrupt)           {gap:+.4f}")
        print(f"    d f(h_a*)  (clean-corrupt)           {dA:+.4f}")
        print(f"    d g(h_d*)  (clean-corrupt)           {dD:+.4f}")
        print(f"    d best-decoy score                   {dbest:+.4f}")
        print(f"    check: (dA+dD) - d_best = {dA + dD - dbest:+.4f}  (should equal gap {gap:+.4f})")
        print(f"    PASS-THROUGH gap / d(own site term)  {pt:+.4f}")
        print(f"    per-example: slope(d_margin ~ d_site) {slope:+.4f}  r {r:+.4f}  "
              f"sd(d_margin) {(syy / n) ** 0.5:.3f}")
        print(f"    corrupt: top decoy shares acc {mean(co['shares_acc']):.3f} | shares don {mean(co['shares_don']):.3f}")
        report[f"seed{s}"][cond] = dict(gap=gap, d_fA=dA, d_gD=dD, d_bestdecoy=dbest,
                                        passthrough=pt, slope=slope, r=r,
                                        shares_acc=mean(co["shares_acc"]),
                                        shares_don=mean(co["shares_don"]))

json.dump(report, open(REPO / "scratch/refcheck_passthrough_results.json", "w"), indent=2)
print("\nwrote scratch/refcheck_passthrough_results.json")

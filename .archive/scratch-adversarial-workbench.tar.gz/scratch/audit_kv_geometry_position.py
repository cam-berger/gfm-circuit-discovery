"""AUDIT: run_qkv.py PART 3 measures L3H1's key/value cosine at token `a`, not at the AG.

run_qkv.py:207-210 indexes  kv[...][j, p, lo:hi]  with p = next_acceptor_pos + OFF.
The AG motif -- and the corruption, and the K/V patch window -- live at [a-2, a-1].
Position `a` is the first EXON base: it is neither part of the motif nor corrupted.

Published: cos_key 0.9503, cos_value 0.9293 -> quoted as "L2H15 only MILDLY perturbs
L3H1's key/value at the acceptor" (run_l2_rescue.py docstring, line 6).

Recompute the same cosines at the tokens the head actually reads.
Also: how often does the 'distance-matched control' window get silently clipped by max(4, .)?
"""
import sys
from pathlib import Path

import numpy as np
import torch

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "src"))

from gfmcd.splicing.circuit import (  # noqa: E402
    ADDRESSER, DEFAULT_FASTA, DEFAULT_GTF, DEFAULT_MODEL, READER, CouplingTask, ablate,
    capture_proj, load_adapter, load_examples, pick_device,
)

L3, H3 = READER
N, BATCH = 60, 6
dev = pick_device(None)
ad = load_adapter(DEFAULT_MODEL, dev)
task = CouplingTask(ad, batch=BATCH)
OFF = task.off
Dh = ad.hidden_size // ad.num_heads
lo, hi = H3 * Dh, (H3 + 1) * Dh

X, _ = load_examples(DEFAULT_GTF, DEFAULT_FASTA, "val", N, task=task, tag="qkv", min_effect=0.3)

# how often is the 'distance-matched' control window clipped to the window edge?
clipped = sum(1 for x in X if x.donor_pos + OFF - (x.next_acceptor_pos - x.donor_pos) < 4)
print(f"control-window clipping by max(4, .): {clipped}/{len(X)} examples")

OFFSETS = {"a-3": -3, "a-2 (AG)": -2, "a-1 (AG)": -1, "a (PUBLISHED)": 0}
ck = {k: [] for k in OFFSETS}
cv = {k: [] for k in OFFSETS}

with torch.no_grad():
    for i in range(0, len(X), BATCH):
        ch = X[i:i + BATCH]
        cl, _, dn = task.pair(ch)
        kv0 = capture_proj(ad, L3, ["key", "value"], lambda: ad.model(**cl))
        with ablate(ad, [ADDRESSER])():
            kv1 = capture_proj(ad, L3, ["key", "value"], lambda: ad.model(**cl))
        for j, x in enumerate(ch):
            p = x.next_acceptor_pos + OFF
            for name, k in OFFSETS.items():
                for w, acc in (("key", ck), ("value", cv)):
                    u = kv0[w][j, p + k, lo:hi]
                    v = kv1[w][j, p + k, lo:hi]
                    acc[name].append(torch.nn.functional.cosine_similarity(
                        u[None], v[None]).item())
        print(f"  {min(i+BATCH, len(X))}/{len(X)}", end="\r", flush=True)
print()
print("=" * 74)
print("cosine( L3H1 <proj> with L2H15 , same with L2H15 mean-ablated )   n=%d" % len(X))
print(f"{'token':16s} {'cos(key)':>10s} {'cos(value)':>12s}")
for name in OFFSETS:
    print(f"{name:16s} {np.mean(ck[name]):10.4f} {np.mean(cv[name]):12.4f}")
print("=" * 74)
print("published qkv.json: cos_key 0.9503  cos_value 0.9293   <- measured at `a` only")

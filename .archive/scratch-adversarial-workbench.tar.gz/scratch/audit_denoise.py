"""AUDIT: what does denoise() in run_faithfulness.py actually measure?

Claim under test: "SUFFICIENCY.  Patch C's clean head outputs into the corrupt run."
faithfulness.json records  circuit C = 0.837,  complement(94) = 0.803,  all-96 = 1.0 (CI [1,1]).

(a) Is all-96 recovery an IDENTITY (mp == mc exactly)?  If so the 'ceiling' is not a
    measurement and denoise saturates by reconstructing the clean readout.
(b) Does a matched-RANDOM 2-head set also clear the sealed-test threshold
    E1_circuit_denoise_recovery_min = 0.50?
"""
import sys
from pathlib import Path

import numpy as np
import torch

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "src"))

from gfmcd.circuits.hf_bert import matched_random_head_sets  # noqa: E402
from gfmcd.splicing.circuit import (  # noqa: E402
    ADDRESSER, CIRCUIT, DEFAULT_FASTA, DEFAULT_GTF, DEFAULT_MODEL, READER, CouplingTask,
    capture_head_outputs, complement, load_adapter, load_examples, patch_heads, pick_device,
    ratio_of_means,
)

N = int(sys.argv[1]) if len(sys.argv) > 1 else 24
BATCH = 6
dev = pick_device(None)
ad = load_adapter(DEFAULT_MODEL, dev)
task = CouplingTask(ad, batch=BATCH)
X, _ = load_examples(DEFAULT_GTF, DEFAULT_FASTA, "val", N, task=task, tag="faith-val",
                     min_effect=0.3)
print(f"{len(X)} val exons  device={dev}")

CIRC = list(CIRCUIT)
COMP = complement(ad, CIRC)
ALL96 = COMP + CIRC
UPSTREAM = [(l, h) for l in range(3) for h in range(ad.num_heads)]      # 48, layers 0-2
rand2 = matched_random_head_sets(ad, CIRC, n=6, seed=7, exclude_selected=True)

SETS = [("circuit C {L3H1,L2H15}", CIRC),
        ("complement (94)", COMP),
        ("ALL 96 (the 'ceiling')", ALL96),
        ("layers 0-2 only (48)", UPSTREAM)]
SETS += [(f"random 2-head {s}", list(s)) for s in rand2]

num = {k: [] for k, _ in SETS}
dnm: list[float] = []
maxdiff96 = 0.0

with torch.no_grad():
    for i in range(0, len(X), BATCH):
        cl, co, dn = task.pair(X[i:i + BATCH])
        cc = capture_head_outputs(ad, lambda: ad.model(**cl))
        mc = task.margin(ad.model(**cl).logits.float(), dn)
        mk = task.margin(ad.model(**co).logits.float(), dn)
        dnm += (mc - mk).tolist()
        for name, hs in SETS:
            with patch_heads(ad, cc, hs):
                mp = task.margin(ad.model(**co).logits.float(), dn)
            num[name] += (mp - mk).tolist()
            if name.startswith("ALL 96"):
                maxdiff96 = max(maxdiff96, float((mp - mc).abs().max()))
        print(f"  {min(i+BATCH, len(X))}/{len(X)}", end="\r", flush=True)
print()

print("\n" + "=" * 78)
print("denoise() recovery = (margin_patched - margin_corrupt)/(margin_clean - margin_corrupt)")
print(f"{'patched head set':30s} {'n_heads':>7s} {'recovery':>9s}")
for name, hs in SETS:
    print(f"{name:30s} {len(hs):7d} {ratio_of_means(num[name], dnm):9.3f}")
print(f"\n(a) all-96 patch: max |margin_patched - margin_clean| over every example "
      f"= {maxdiff96:.3e}")
print("    -> if ~0, denoising every head output RECONSTRUCTS the clean readout exactly;")
print("       the 'ceiling' row is an identity, not a measurement.")
print(f"(b) sealed-test threshold E1_circuit_denoise_recovery_min = 0.50")
print("=" * 78)

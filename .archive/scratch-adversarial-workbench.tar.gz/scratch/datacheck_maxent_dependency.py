#!/usr/bin/env python
"""DATA-CHECK of the finding: 'the PWM rival is weaker than MaxEntScan because it
lacks maximum-entropy modelling of INTRA-MOTIF DEPENDENCIES (Yeo & Burge 2004)'.

The audit already showed that *other* axes (window width, decoy background,
discriminative weighting) shrink the conflict set. Nobody has isolated MaxEntScan's
ACTUAL contribution: dependency modelling within the SAME window geometry.

Design: hold geometry FIXED at the registered (== MaxEntScan) windows
  acceptor 20up/3down = 23nt ; donor 3up/6down = 9nt
and vary ONLY the emission model order:
  order 0 = WMM  (what the repo registered)
  order 1 = WAM  (adjacent-position dependencies)
  order 2 = 2nd-order Markov (richer dependencies)
each under two backgrounds:
  bg=pos  (0/1/2-order background from the positive windows' own composition; repo convention)
  bg=cand (background fit on the CANDIDATE/decoy window distribution; MaxEntScan's decoy model)

MaxEntScan-lite == order>=1 with bg=cand (dependency model of true sites vs dependency
model of decoys, exactly the likelihood-ratio MaxEntScan computes).

Report: val top1, conflict-set size, and how much of the registered 10,034 conflict set
each rival resolves.
"""
from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))
from gfmcd.splicing.schema import SplicePairExample  # noqa: E402

B2I = {"A": 0, "C": 1, "G": 2, "T": 3}
PSEUDO = 0.5
N_TRAIN = 20000
LMIN, LMAX = 20, 500

AU, AD = 20, 3   # registered acceptor window (23nt) == MaxEntScan 3'ss
DU, DD = 3, 6    # registered donor window (9nt)   == MaxEntScan 5'ss


def seq_idx(seq: str) -> np.ndarray:
    a = np.full(len(seq), -1, dtype=np.int8)
    for i, b in enumerate(seq):
        a[i] = B2I.get(b, -1)
    return a


def load_lines(path: Path, n: int) -> list[SplicePairExample]:
    out = []
    with path.open() as f:
        for line in f:
            if not line.strip():
                continue
            out.append(SplicePairExample.from_json(line))
            if len(out) >= n:
                break
    return out


print("loading train...", flush=True)
train = load_lines(REPO / "data/processed/splicebert_partner_selection/v1/train.jsonl", N_TRAIN)
print("loading val...", flush=True)
val = load_lines(REPO / "data/processed/splicebert_partner_selection/v1/val.jsonl", 20000)
print(f"train={len(train)} val={len(val)}", flush=True)

cache = {x.example_id: seq_idx(x.sequence) for x in train + val}


# ---------- length prior (identical across all rivals) ----------
lc = np.full(LMAX - LMIN + 1, 1.0)
for x in train:
    L = x.true_pair.exon_length
    if LMIN <= L <= LMAX:
        lc[L - LMIN] += 1
LOGP = np.log(lc / lc.sum())
LPRI = np.concatenate([np.full(LMIN, -np.inf), LOGP])  # index by exon_length


# ---------- Markov emission model of a fixed-length window ----------
def fit_markov(windows: list[np.ndarray], W: int, order: int) -> list[np.ndarray]:
    """Return per-position conditional log-prob tables.
    tab[p] has shape (4**min(p,order), 4): log P(x_p | previous `order` bases)."""
    tabs = []
    for p in range(W):
        k = min(p, order)
        ctx = 4 ** k
        cnt = np.full((ctx, 4), PSEUDO)
        for w in windows:
            if np.any(w[max(0, p - k):p + 1] < 0):
                continue
            c = 0
            for j in range(p - k, p):
                c = c * 4 + int(w[j])
            cnt[c, int(w[p])] += 1
        tabs.append(np.log(cnt / cnt.sum(1, keepdims=True)))
    return tabs


def score_windows(sidx: np.ndarray, positions: np.ndarray, up: int, down: int,
                  pos_tabs: list[np.ndarray], bg_tabs: list[np.ndarray], order: int) -> np.ndarray:
    W = up + down
    out = np.full(len(positions), -np.inf)
    for k, p in enumerate(positions):
        s, e = p - up, p + down
        if s < 0 or e > len(sidx):
            continue
        w = sidx[s:e]
        if np.any(w < 0):
            continue
        tot = 0.0
        for q in range(W):
            kk = min(q, order)
            c = 0
            for j in range(q - kk, q):
                c = c * 4 + int(w[j])
            b = int(w[q])
            tot += pos_tabs[q][c, b] - bg_tabs[q][c, b]
        out[k] = tot
    return out


def collect(examples, up, down, kind, n_cand_ex=4000):
    """positive windows (true sites) and candidate windows (decoy-dominated)."""
    pos, cand = [], []
    for i, x in enumerate(examples):
        s = cache[x.example_id]
        p = x.true_pair.acceptor_pos if kind == "acceptor" else x.true_pair.donor_pos
        a, b = p - up, p + down
        if a >= 0 and b <= len(s) and not np.any(s[a:b] < 0):
            pos.append(s[a:b])
        if i < n_cand_ex:
            sites = x.acceptors if kind == "acceptor" else x.donors
            for c in sites:
                a, b = c.position - up, c.position + down
                if a >= 0 and b <= len(s) and not np.any(s[a:b] < 0):
                    cand.append(s[a:b])
    return pos, cand


print("collecting windows...", flush=True)
acc_pos, acc_cand = collect(train, AU, AD, "acceptor")
don_pos, don_cand = collect(train, DU, DD, "donor")
print(f"  acceptor: {len(acc_pos)} pos / {len(acc_cand)} cand", flush=True)
print(f"  donor:    {len(don_pos)} pos / {len(don_cand)} cand", flush=True)

WA, WD = AU + AD, DU + DD

results = {}
conflict_masks = {}

for order in [0, 1, 2]:
    for bgname in ["pos", "cand"]:
        a_pos_t = fit_markov(acc_pos, WA, order)
        d_pos_t = fit_markov(don_pos, WD, order)
        if bgname == "pos":
            # repo convention: background is the 0th-order base composition of the positives,
            # broadcast across contexts (i.e. context-free background)
            allb = np.concatenate([w for w in acc_pos])
            bgv = np.full(4, PSEUDO)
            for b in allb:
                bgv[int(b)] += 1
            bgv = np.log(bgv / bgv.sum())
            a_bg_t = [np.tile(bgv, (t.shape[0], 1)) for t in a_pos_t]
            allb = np.concatenate([w for w in don_pos])
            bgv = np.full(4, PSEUDO)
            for b in allb:
                bgv[int(b)] += 1
            bgv = np.log(bgv / bgv.sum())
            d_bg_t = [np.tile(bgv, (t.shape[0], 1)) for t in d_pos_t]
        else:
            a_bg_t = fit_markov(acc_cand, WA, order)
            d_bg_t = fit_markov(don_cand, WD, order)

        wrong = np.zeros(len(val), dtype=bool)
        for i, x in enumerate(val):
            s = cache[x.example_id]
            ap = np.array([c.position for c in x.acceptors])
            dp = np.array([c.position for c in x.donors])
            A = score_windows(s, ap, AU, AD, a_pos_t, a_bg_t, order)
            D = score_windows(s, dp, DU, DD, d_pos_t, d_bg_t, order)
            ai = {p: j for j, p in enumerate(ap)}
            di = {p: j for j, p in enumerate(dp)}
            sc = np.array([A[ai[pr.acceptor_pos]] + D[di[pr.donor_pos]] + LPRI[pr.exon_length]
                           for pr in x.pairs])
            wrong[i] = int(np.nanargmax(sc)) != x.true_pair_index
        key = f"order{order}|bg={bgname}"
        conflict_masks[key] = wrong.copy()
        results[key] = {"val_top1": float(1 - wrong.mean()), "n_conflict": int(wrong.sum())}
        print(f"{key:16s} val_top1={results[key]['val_top1']:.4f}  n_conflict={int(wrong.sum())}", flush=True)

# ---- resolution of the REGISTERED conflict set (order0|bg=pos == shipped baseline) ----
reg = conflict_masks["order0|bg=pos"]
for key, m in conflict_masks.items():
    inter = int((reg & m).sum())
    union = int((reg | m).sum())
    results[key]["resolves_frac_of_registered"] = float(((reg & ~m).sum()) / max(reg.sum(), 1))
    results[key]["jaccard_with_registered"] = float(inter / max(union, 1))

print()
print(json.dumps(results, indent=2))
(REPO / "scratch/datacheck_maxent_dependency.json").write_text(json.dumps(results, indent=2))
np.savez(REPO / "scratch/datacheck_maxent_masks.npz",
         **{k.replace("|", "_").replace("=", ""): v for k, v in conflict_masks.items()},
         example_ids=np.array([x.example_id for x in val]))
print("saved.")

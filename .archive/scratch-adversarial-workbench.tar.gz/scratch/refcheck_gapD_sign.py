"""Data-check: sign of the D-split gap for each partner mask in run_tracing.py,
and whether the 'recovery>0' criterion used to build M is sign-inverted."""
from __future__ import annotations
import json, sys
from pathlib import Path
import torch

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "src"))
from gfmcd.adapters.splicebert import SpliceBertAdapter
from gfmcd.circuits.hf_bert import capture_head_outputs, patch_heads
from gfmcd.splicing.config import load_config
from gfmcd.splicing.context_controls import mask_true_partner_neighborhood, retain_site_windows
from gfmcd.splicing.io import load_jsonl
from gfmcd.splicing.readout import collate_pair_indices, true_pair_margin
from gfmcd.splicing.training import load_pair_checkpoint, set_seed

N = int(sys.argv[1]) if len(sys.argv) > 1 else 24
BATCH = 8
set_seed(0)
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"])
mc = cfg["model"]
ckpt = REPO / "colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt"
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=None,
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
readout, checkpoint = load_pair_checkpoint(ckpt, adapter=adapter)
print("regime:", checkpoint.get("extra_metadata", {}).get("regime"),
      "backbone_state is None:", checkpoint.get("backbone_state") is None)

D = load_jsonl(REPO / "results/splicebert_partner_selection/circuits/discovery/discovery.jsonl")[:N]
flank = 12
masks = {
    "acceptor-mask": lambda exs: [mask_true_partner_neighborhood(x, kind="acceptor", flank=flank) for x in exs],
    "donor-mask": lambda exs: [mask_true_partner_neighborhood(x, kind="donor", flank=flank) for x in exs],
    "site-windows-only": lambda exs: [retain_site_windows(x, flank=flank, include_all_candidates=True) for x in exs],
}

def margin_sum(tok, pb):
    out = adapter.forward(tok, output_hidden_states=True, output_attentions=False, grad=False)
    return true_pair_margin(readout(out.hidden_states[rep], pb), pb).sum()

def chunks(examples, corrupt=None):
    cs = []
    i = 0
    while i < len(examples):
        j = min(i + BATCH, len(examples))
        if len(examples) - j == 1:
            j = len(examples)
        ex = examples[i:j]
        seqs = corrupt(ex) if corrupt else [x.sequence for x in ex]
        tok = adapter.tokenize(seqs)
        pb = collate_pair_indices(ex, token_offset=tok.prefix_tokens, device=adapter.device)
        cs.append({"tok": tok, "pb": pb, "n": len(ex)})
        i = j
    return cs

def mean(cs, patch=None, clean_cs=None):
    tot, n = 0.0, 0
    with torch.no_grad():
        for k, c in enumerate(cs):
            if patch is not None:
                with patch_heads(adapter, clean_cs[k]["cache"], patch):
                    tot += float(margin_sum(c["tok"], c["pb"]))
            else:
                tot += float(margin_sum(c["tok"], c["pb"]))
            n += c["n"]
    return tot / n

D_clean = chunks(D)
for c in D_clean:
    with torch.no_grad():
        c["cache"] = capture_head_outputs(adapter, lambda c=c: float(margin_sum(c["tok"], c["pb"])))
base_D = mean(D_clean)
print(f"n_D={len(D)}  base_D (clean mean true-pair margin) = {base_D:.4f}")

heads_M = [(1, 1), (1, 2), (1, 7), (4, 2)]  # smoke mediation_set_M
heads_extra = [(0, 2), (2, 5), (3, 4)]      # strongly-negative acceptor recovery in smoke
res = {"n_D": len(D), "base_D": base_D, "masks": {}}
for name in ("acceptor-mask", "donor-mask", "site-windows-only"):
    D_cor = chunks(D, corrupt=masks[name])
    corr = mean(D_cor)
    gap = base_D - corr
    entry = {"clean": base_D, "corrupt": corr, "gap": gap, "heads": {}}
    if name != "site-windows-only":
        for h in heads_M + heads_extra:
            patched = mean(D_cor, patch=[h], clean_cs=D_clean)
            entry["heads"][f"{h[0]}-{h[1]}"] = {
                "patched": patched,
                "patched_minus_corrupt": patched - corr,
                "recovery_ratio": (patched - corr) / gap,
                "moves_toward_clean": abs(patched - base_D) < abs(corr - base_D),
            }
    res["masks"][name] = entry
    print(f"\n[{name}] clean={base_D:.4f} corrupt={corr:.4f} gap={gap:+.4f}")
    for k, v in entry["heads"].items():
        print(f"   head {k:5s} patched={v['patched']:+.4f} "
              f"(patched-corrupt)={v['patched_minus_corrupt']:+.4f} "
              f"recovery={v['recovery_ratio']:+.4f} toward_clean={v['moves_toward_clean']}")

(REPO / "scratch/refcheck_gapD_sign.json").write_text(json.dumps(res, indent=2) + "\n")

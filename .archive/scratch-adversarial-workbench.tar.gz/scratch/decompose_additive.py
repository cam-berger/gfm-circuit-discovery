#!/usr/bin/env python
"""Decompose the additive readout's logits into A (acceptor), D (donor), Lterm (length)
on the real conflict set, using the LOCAL additive-frozen seed0 checkpoint."""
from __future__ import annotations

import json
from pathlib import Path
import sys

import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))

from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.schema import SplicePairExample  # noqa: E402
from gfmcd.splicing.readout import collate_pair_indices  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint  # noqa: E402

N = 400
BATCH = 8
NEG = float("-inf")

device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"])
mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
ckpt_path = REPO / "colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt"
readout, checkpoint = load_pair_checkpoint(ckpt_path, adapter=adapter)
meta = checkpoint.get("extra_metadata", {})
print("checkpoint regime:", meta.get("regime"), "| backbone_state is None:",
      checkpoint.get("backbone_state") is None, "| rep layer:", rep, "| device:", device)
print("readout class:", type(readout).__name__)

# read only the first N examples of the conflict jsonl (file is 500MB)
conf_path = REPO / "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl"
examples: list[SplicePairExample] = []
with conf_path.open() as f:
    for line in f:
        if not line.strip():
            continue
        examples.append(SplicePairExample.from_json(line))
        if len(examples) >= N:
            break
print(f"loaded {len(examples)} conflict examples; pairs/example mean="
      f"{sum(len(x.pairs) for x in examples)/len(examples):.1f}")

rows = []  # per-example dicts
max_abs_err = 0.0

for i in range(0, len(examples), BATCH):
    ex = examples[i:i + BATCH]
    tok = adapter.tokenize([x.sequence for x in ex])
    pb = collate_pair_indices(ex, token_offset=tok.prefix_tokens, device=adapter.device)
    with torch.no_grad():
        out = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
        hidden = out.hidden_states[rep]
        b = torch.arange(hidden.shape[0], device=hidden.device)[:, None]
        h_a = hidden[b, pb.positions[..., 0]]
        h_d = hidden[b, pb.positions[..., 1]]
        A = readout.acceptor(h_a).squeeze(-1)
        D = readout.donor(h_d).squeeze(-1)
        Lt = readout.length(readout._length_features(pb.lengths)).squeeze(-1)
        full_ref = readout(hidden, pb)  # forward, with masking
    A, D, Lt = A.float().cpu(), D.float().cpu(), Lt.float().cpu()
    mask = pb.mask.cpu()
    full = A + D + Lt
    # verify against forward() on valid entries
    ref = full_ref.float().cpu()
    err = (full - ref)[mask].abs().max().item()
    max_abs_err = max(max_abs_err, err)

    for k, x in enumerate(ex):
        m = mask[k]
        t = x.true_pair_index
        p_acc = pb.positions[k, :, 0].cpu()
        p_don = pb.positions[k, :, 1].cpu()
        rows.append(dict(
            A=A[k][m].clone(), D=D[k][m].clone(), L=Lt[k][m].clone(),
            t=int((torch.arange(len(m))[m] == t).nonzero()[0]) if m[t] else None,
            acc=p_acc[m].clone(), don=p_don[m].clone(),
        ))
print(f"max |A+D+L - forward()| over valid pairs = {max_abs_err:.3e}  (should be ~0)")


def pmr(score_fn):
    hits = 0
    for r in rows:
        s = score_fn(r)
        t = r["t"]
        d = s.clone()
        d[t] = NEG
        hits += int(s[t].item() > d.max().item())
    return hits / len(rows)


variants = {
    "full (A+D+L)": lambda r: r["A"] + r["D"] + r["L"],
    "D+L (acceptor dropped)": lambda r: r["D"] + r["L"],
    "A+L (donor dropped)": lambda r: r["A"] + r["L"],
    "A+D (length dropped)": lambda r: r["A"] + r["D"],
    "L only": lambda r: r["L"],
    "A only": lambda r: r["A"],
    "D only": lambda r: r["D"],
}
results = {name: pmr(fn) for name, fn in variants.items()}
print("\n=== PMR (true pair strictly beats best decoy) ===")
for name, v in results.items():
    print(f"  {name:26s} {v:.3f}")

# top-decoy sharing + margin decomposition
share_acc = share_don = share_both = 0
dA = dD = dL = tot = 0.0
margins = []
for r in rows:
    s = r["A"] + r["D"] + r["L"]
    t = r["t"]
    d = s.clone(); d[t] = NEG
    j = int(d.argmax())
    if int(r["acc"][j]) == int(r["acc"][t]):
        share_acc += 1
    if int(r["don"][j]) == int(r["don"][t]):
        share_don += 1
    if int(r["acc"][j]) == int(r["acc"][t]) and int(r["don"][j]) == int(r["don"][t]):
        share_both += 1
    dA += float(r["A"][t] - r["A"][j])
    dD += float(r["D"][t] - r["D"][j])
    dL += float(r["L"][t] - r["L"][j])
    tot += float(s[t] - s[j])
    margins.append(float(s[t] - s[j]))
n = len(rows)
print("\n=== Top-decoy structure (n=%d) ===" % n)
print(f"  top decoy shares TRUE ACCEPTOR position: {share_acc/n:.3f}  ({share_acc}/{n})")
print(f"  top decoy shares TRUE DONOR position:    {share_don/n:.3f}  ({share_don}/{n})")
print(f"  shares both (impossible unless dup):      {share_both/n:.3f}")
print("\n=== Mean margin decomposition (true - best decoy) ===")
print(f"  mean total margin : {tot/n:+.4f}")
print(f"  mean dA (acceptor): {dA/n:+.4f}  ({100*(dA/n)/(tot/n):+.1f}% of total)")
print(f"  mean dD (donor)   : {dD/n:+.4f}  ({100*(dD/n)/(tot/n):+.1f}% of total)")
print(f"  mean dL (length)  : {dL/n:+.4f}  ({100*(dL/n)/(tot/n):+.1f}% of total)")

# extra: term std across candidates (how much each term can discriminate)
sa = torch.tensor([float(r["A"].std()) for r in rows]).mean()
sd = torch.tensor([float(r["D"].std()) for r in rows]).mean()
sl = torch.tensor([float(r["L"].std()) for r in rows]).mean()
print("\n=== Mean within-example SD of each term across candidate pairs ===")
print(f"  A: {sa:.3f}   D: {sd:.3f}   L: {sl:.3f}")

# how often is the true acceptor the argmax of A over distinct acceptor positions, etc.
acc_top = don_top = 0
for r in rows:
    t = r["t"]
    # unique acceptor positions -> A value (A depends only on acceptor position)
    ua = {}
    for k in range(len(r["A"])):
        ua[int(r["acc"][k])] = float(r["A"][k])
    ud = {}
    for k in range(len(r["D"])):
        ud[int(r["don"][k])] = float(r["D"][k])
    acc_top += int(max(ua, key=ua.get) == int(r["acc"][t]))
    don_top += int(max(ud, key=ud.get) == int(r["don"][t]))
print("\n=== Site-detection accuracy of each term alone (argmax over distinct sites) ===")
print(f"  A picks true acceptor site: {acc_top/n:.3f}")
print(f"  D picks true donor site:    {don_top/n:.3f}")

# Does the full model = independent site detection? Compare full-logit argmax to
# the pair formed by (argmax_A acceptor, argmax_D donor) chosen INDEPENDENTLY.
both_top = agree = 0
for r in rows:
    t = r["t"]
    ua, ud = {}, {}
    for k in range(len(r["A"])):
        ua[int(r["acc"][k])] = float(r["A"][k])
        ud[int(r["don"][k])] = float(r["D"][k])
    a_star, d_star = max(ua, key=ua.get), max(ud, key=ud.get)
    both_top += int(a_star == int(r["acc"][t]) and d_star == int(r["don"][t]))
    s = r["A"] + r["D"] + r["L"]
    j = int(s.argmax())
    agree += int(int(r["acc"][j]) == a_star and int(r["don"][j]) == d_star)
print("\n=== Independent-site-detection decomposition ===")
print(f"  P(A picks true acc) * P(D picks true don) = {(acc_top/n)*(don_top/n):.3f}")
print(f"  joint: BOTH terms independently pick the true sites: {both_top/n:.3f}")
print(f"  full-logit argmax == independent (argmaxA, argmaxD) pair: {agree/n:.3f}")

out = REPO / "scratch/decompose_additive_results.json"
out.write_text(json.dumps(dict(
    n=n, pmr=results, max_abs_err=max_abs_err,
    top_decoy_shares_true_acceptor=share_acc / n,
    top_decoy_shares_true_donor=share_don / n,
    mean_margin=tot / n, mean_dA=dA / n, mean_dD=dD / n, mean_dL=dL / n,
    mean_sd_A=float(sa), mean_sd_D=float(sd), mean_sd_L=float(sl),
    A_picks_true_acceptor=acc_top / n, D_picks_true_donor=don_top / n,
), indent=2))
print("\nwrote", out)

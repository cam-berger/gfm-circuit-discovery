"""Alt-explanation check of the '2.73% cross-pairing yield' finding.

The finding measured pairs formed from a DISTAL real acceptor x a DISTAL real donor.
The cross-pairing decoy actually described ("true acceptor of exon i with true donor
of exon j") only requires ONE endpoint to be swapped. Recompute both.
"""
from __future__ import annotations

import gzip
import json
import statistics
from collections import defaultdict

GTF = "data/external/gencode/v50/gencode.v50.basic.annotation.gtf.gz"
CONFLICTS = "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl"
CHROMS = {"chr17", "chr18"}
DISTAL = 30

tx_exons: dict[str, list[tuple[int, int]]] = defaultdict(list)
tx_meta: dict[str, tuple[str, str]] = {}
with gzip.open(GTF, "rt") as f:
    for line in f:
        if line.startswith("#"):
            continue
        c = line.rstrip("\n").split("\t")
        if c[2] != "exon" or c[0] not in CHROMS:
            continue
        start, end, strand, attrs = int(c[3]) - 1, int(c[4]), c[6], c[8]
        tid = attrs.split('transcript_id "', 1)[1].split('"', 1)[0]
        tx_exons[tid].append((start, end))
        tx_meta[tid] = (c[0], strand)

acc_anchor: dict[str, set[int]] = {"+": set(), "-": set()}
don_anchor: dict[str, set[int]] = {"+": set(), "-": set()}
for tid, exons in tx_exons.items():
    _, strand = tx_meta[tid]
    ex = sorted(exons)
    if strand == "-":
        ex = ex[::-1]
    n = len(ex)
    if n < 2:
        continue
    for i, (s, e) in enumerate(ex):
        a, d = (s, e) if strand == "+" else (e - 1, s - 1)
        if i > 0:
            acc_anchor[strand].add(a)
        if i < n - 1:
            don_anchor[strand].add(d)

n_ex = 0
cnt = defaultdict(int)
per_ex = defaultdict(list)

for line in open(CONFLICTS):
    d = json.loads(line)
    n_ex += 1
    strand = d["strand"]
    W = d["metadata"]["genomic_window_start"]
    E = d["metadata"]["genomic_window_end"]

    def g(p: int) -> int:
        return W + p if strand == "+" else E - 1 - p

    tp = d["pairs"][d["true_pair_index"]]
    ta, td = tp["acceptor_pos"], tp["donor_pos"]
    A, D = acc_anchor[strand], don_anchor[strand]

    acc_real = {s["position"]: (g(s["position"]) in A) for s in d["acceptors"]}
    don_real = {s["position"]: (g(s["position"]) in D) for s in d["donors"]}

    n_bothreal = 0          # any decoy pair, both endpoints real sites
    n_cross_strict = 0      # both real AND every swapped endpoint is DISTAL (>30nt) from true
    n_distal_x_distal = 0   # finding's condition: distal real acc x distal real don
    n_true_acc_x_other_don = 0   # (true acceptor, distal real donor)
    n_other_acc_x_true_don = 0   # (distal real acceptor, true donor)
    for pr in d["pairs"]:
        a, dd = pr["acceptor_pos"], pr["donor_pos"]
        if a == ta and dd == td:
            continue
        if not (acc_real.get(a) and don_real.get(dd)):
            continue
        n_bothreal += 1
        a_dist = abs(a - ta) > DISTAL
        d_dist = abs(dd - td) > DISTAL
        a_true = a == ta
        d_true = dd == td
        if (a_true or a_dist) and (d_true or d_dist):
            n_cross_strict += 1
        if a_dist and d_dist:
            n_distal_x_distal += 1
        if a_true and d_dist:
            n_true_acc_x_other_don += 1
        if d_true and a_dist:
            n_other_acc_x_true_don += 1

    for k, v in [
        ("bothreal", n_bothreal),
        ("cross_strict", n_cross_strict),
        ("distal_x_distal", n_distal_x_distal),
        ("trueacc_x_otherdon", n_true_acc_x_other_don),
        ("otheracc_x_truedon", n_other_acc_x_true_don),
    ]:
        per_ex[k].append(v)
        cnt[k] += v

print(f"examples: {n_ex}\n")
for k in ["bothreal", "cross_strict", "distal_x_distal", "trueacc_x_otherdon", "otheracc_x_truedon"]:
    v = per_ex[k]
    frac = sum(1 for x in v if x) / n_ex
    print(
        f"{k:22s} total={cnt[k]:7d}  frac examples with >=1: {frac:.4f}  "
        f"mean/ex {statistics.mean(v):.3f}  median {statistics.median(v)}"
    )

# union of the two one-sided cross decoys
u = sum(1 for i in range(n_ex) if per_ex["trueacc_x_otherdon"][i] or per_ex["otheracc_x_truedon"][i])
print(f"\none-sided cross decoy (either side): frac examples with >=1: {u/n_ex:.4f}")

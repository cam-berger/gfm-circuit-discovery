#!/usr/bin/env python
"""Alt-explanation test for the 'label-dependent 512-cap truncation' finding.

Q1: Does the nearest-512 cap make PMR EASIER or HARDER than a label-independent
    subsample / than the full uncapped candidate set?
Q2: Is the 'candidate cloud centred on the true pair' a truncation artifact, or
    is it already true of the FULL (uncapped) candidate set (geometry of the
    window + length filter)?
Q3: Can a 'centroid of the candidate cloud' rule (no sequence) beat chance?
    (Note: neither readout can even see the candidate set -- score(a,d) depends
     only on h_a, h_d, L. This is a data-property check, not a model channel.)
"""
from __future__ import annotations

import dataclasses
import json
from pathlib import Path
import random
import statistics
import sys

import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))

from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.splicing.candidates import CandidateConfig, enumerate_candidate_pairs  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.schema import SplicePairExample  # noqa: E402
from gfmcd.splicing.readout import collate_pair_indices  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint  # noqa: E402

N = 300
NEG = float("-inf")
rng = random.Random(0)

cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
ccfg_d = dict(cfg["data"]["candidate"])
capped_cfg = CandidateConfig(
    donor_motifs=tuple(ccfg_d["donor_motifs"]),
    acceptor_motifs=tuple(ccfg_d["acceptor_motifs"]),
    min_exon_length=ccfg_d["min_exon_length"],
    max_exon_length=ccfg_d["max_exon_length"],
    edge_buffer=ccfg_d["edge_buffer"],
    max_pairs=ccfg_d["max_pairs"],
)
uncapped_cfg = dataclasses.replace(capped_cfg, max_pairs=None)

rep = int(cfg["readout"]["representation_layer"])
mc = cfg["model"]
device = "mps" if torch.backends.mps.is_available() else "cpu"
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
readout, checkpoint = load_pair_checkpoint(
    REPO / "colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt", adapter=adapter)
print("readout:", type(readout).__name__, "| backbone_state None:", checkpoint.get("backbone_state") is None)

conf_path = REPO / "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl"
examples: list[SplicePairExample] = []
with conf_path.open() as f:
    for line in f:
        if line.strip():
            examples.append(SplicePairExample.from_json(line))
        if len(examples) >= N:
            break

out = {}
stored_sizes, full_sizes = [], []
capped_hits = full_hits = rand_hits = 0
capped_reproduced = 0
cloud_hits_stored = cloud_hits_full = 0
med_off_stored_a, med_off_stored_d = [], []
med_off_full_a, med_off_full_d = [], []
rand_pmrs_per_ex = []

for ex in examples:
    ta = ex.pairs[ex.true_pair_index].acceptor_pos
    td = ex.pairs[ex.true_pair_index].donor_pos
    accs, dons, full_pairs, full_true = enumerate_candidate_pairs(
        ex.sequence, uncapped_cfg, true_acceptor=ta, true_donor=td)
    _, _, cap_pairs, cap_true = enumerate_candidate_pairs(
        ex.sequence, capped_cfg, true_acceptor=ta, true_donor=td)
    # sanity: regenerated capped set == stored set
    stored = [(p.acceptor_pos, p.donor_pos) for p in ex.pairs]
    regen = [(p.acceptor_pos, p.donor_pos) for p in cap_pairs]
    capped_reproduced += int(stored == regen)
    stored_sizes.append(len(stored))
    full_sizes.append(len(full_pairs))

    # score the FULL uncapped set once with the trained additive readout
    ex_full = dataclasses.replace(ex, acceptors=accs, donors=dons, pairs=full_pairs,
                                  true_pair_index=full_true)
    tok = adapter.tokenize([ex_full.sequence])
    pb = collate_pair_indices([ex_full], token_offset=tok.prefix_tokens, device=adapter.device)
    with torch.no_grad():
        hidden = adapter.forward(tok, output_hidden_states=True).hidden_states[rep]
        logits = readout(hidden, pb)[0].float().cpu()

    key = {(p.acceptor_pos, p.donor_pos): i for i, p in enumerate(full_pairs)}
    t_full = full_true

    def pmr_over(idx_list, t_idx):
        s = logits[torch.tensor(idx_list)]
        j = idx_list.index(t_idx)
        d = s.clone(); d[j] = NEG
        return int(s[j].item() > d.max().item())

    all_idx = list(range(len(full_pairs)))
    full_hits += pmr_over(all_idx, t_full)

    cap_idx = [key[(p.acceptor_pos, p.donor_pos)] for p in ex.pairs]
    capped_hits += pmr_over(cap_idx, t_full)

    # label-independent random subsample of the SAME size as the stored set
    k = len(ex.pairs)
    if len(full_pairs) <= k:
        rand_idx = all_idx
    else:
        pool = [i for i in all_idx if i != t_full]
        rand_idx = sorted(rng.sample(pool, k - 1) + [t_full])
    rand_hits += pmr_over(rand_idx, t_full)

    # cloud-centroid rule (no sequence, no model): score = -(|a-med_a| + |d-med_d|)
    for pairs, tidx, hit_acc, offa, offd in (
        (list(ex.pairs), ex.true_pair_index, "stored", med_off_stored_a, med_off_stored_d),
        (list(full_pairs), full_true, "full", med_off_full_a, med_off_full_d),
    ):
        A = [p.acceptor_pos for p in pairs]
        D = [p.donor_pos for p in pairs]
        ma, md = statistics.median(A), statistics.median(D)
        offa.append(ma - ta)
        offd.append(md - td)
        sc = [-(abs(a - ma) + abs(d - md)) for a, d in zip(A, D)]
        best = max(s for i, s in enumerate(sc) if i != tidx)
        if sc[tidx] > best:
            if hit_acc == "stored":
                cloud_hits_stored += 1
            else:
                cloud_hits_full += 1

n = len(examples)
res = dict(
    n=n,
    stored_pairs_mean=sum(stored_sizes) / n,
    full_pairs_mean=sum(full_sizes) / n,
    full_pairs_median=statistics.median(full_sizes),
    frac_at_cap=sum(s >= 512 for s in stored_sizes) / n,
    capped_set_reproduced_from_code=capped_reproduced / n,
    PMR_stored_nearest512=capped_hits / n,
    PMR_full_uncapped=full_hits / n,
    PMR_random512_label_independent=rand_hits / n,
    median_offset_stored_acceptor=statistics.median(med_off_stored_a),
    median_offset_stored_donor=statistics.median(med_off_stored_d),
    median_offset_FULL_acceptor=statistics.median(med_off_full_a),
    median_offset_FULL_donor=statistics.median(med_off_full_d),
    PMR_cloud_centroid_rule_stored=cloud_hits_stored / n,
    PMR_cloud_centroid_rule_full=cloud_hits_full / n,
)
print(json.dumps(res, indent=2))
(REPO / "scratch/altexp_cap_truncation_results.json").write_text(json.dumps(res, indent=2))

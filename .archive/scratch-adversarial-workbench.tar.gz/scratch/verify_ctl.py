"""Adversarial check of the 'control window is not a non-site' claim.

1. Reproduce the claim's counts on the eligible sets.
2. Reproduce D8 EXACTLY on the 150 val examples run_readout_path.py actually uses,
   and stratify the transplant loss by whether the control position is an AG /
   the exon's own acceptor / a real annotated acceptor.
"""
from __future__ import annotations
import sys
from pathlib import Path
REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "src"))

import numpy as np
import torch

from gfmcd.splicing.circuit import (
    DEFAULT_FASTA, DEFAULT_GTF, DEFAULT_MODEL, READER, CouplingTask, build_windows,
    capture_proj, eligible, gboot_ratio, load_adapter, load_examples, patch_proj,
    pick_device, ratio_of_means, _dataset, ACC_WINDOW_OFFSETS,
)

L3, H3 = READER
dev = pick_device(None)
ad = load_adapter(DEFAULT_MODEL, dev, eager=True)
task = CouplingTask(ad, batch=6)
OFF = task.off
print("prefix_tokens (off) =", OFF)

DS = _dataset(DEFAULT_GTF, DEFAULT_FASTA)


def ctl_seqpos(x):
    """The single token D8 transplants FROM: W.control[:, -1] -> sequence coord."""
    gap = x.next_acceptor_pos - x.donor_pos
    tok = max(4, x.donor_pos + OFF - gap) + ACC_WINDOW_OFFSETS[-1]   # +0
    return tok - OFF


def ctl_window_seqpos(x):
    gap = x.next_acceptor_pos - x.donor_pos
    base = max(4, x.donor_pos + OFF - gap)
    return [base + k - OFF for k in ACC_WINDOW_OFFSETS]


def classify(x, positions):
    s = x.sequence
    own = {x.acceptor_pos - 2, x.acceptor_pos - 1}
    real = set()
    for a in (x.real_acc or ()):
        real |= {a - 2, a - 1}
    hit_own = any(p in own for p in positions)
    hit_real = any(p in real for p in positions)
    hit_ag = any(s[p - 1:p + 1] == "AG" or s[p:p + 2] == "AG" for p in positions if p >= 1)
    return hit_own, hit_real, hit_ag


print("\n--- claim's counts over eligible sets (4-base window vs the 1 token D8 uses) ---")
for split in ("train", "val", "test"):
    X = eligible(DS, split)
    if not X:
        continue
    cw = [(x, ctl_window_seqpos(x), ctl_seqpos(x)) for x in X]
    clamped = sum(1 for x in X if x.donor_pos + OFF - (x.next_acceptor_pos - x.donor_pos) < 4)
    w = [classify(x, win) for x, win, _ in cw]
    t = [classify(x, [p]) for x, _, p in cw]
    n = len(X)
    print(f"{split:5s} n={n:5d} clamped={clamped:2d} | WINDOW own={sum(a for a,_,_ in w)} "
          f"real={sum(b for _,b,_ in w)} anyAG={sum(c for _,_,c in w)} "
          f"({100*sum(c for _,_,c in w)/n:.1f}%) | D8 SINGLE TOKEN own={sum(a for a,_,_ in t)} "
          f"({100*sum(a for a,_,_ in t)/n:.1f}%) real={sum(b for _,b,_ in t)} "
          f"anyAG={sum(c for _,_,c in t)} ({100*sum(c for _,_,c in t)/n:.1f}%)")

# ---- exact D8 replay on the 150 val examples ------------------------------------------
X, _ = load_examples(DEFAULT_GTF, DEFAULT_FASTA, "val", 150, task=task,
                     tag="readout-val", min_effect=0.3)
genes = [x.gene_id for x in X]
print(f"\n--- D8 replay on the actual {len(X)} val examples ---")

flags = [classify(x, [ctl_seqpos(x)]) for x in X]
print("of the 150 D8 examples: control token hits own-acceptor-AG "
      f"{sum(a for a,_,_ in flags)}, other real acceptor AG {sum(b for _,b,_ in flags)}, "
      f"any AG dinucleotide {sum(c for _,_,c in flags)}")
print("clamped:", sum(1 for x in X
                      if x.donor_pos + OFF - (x.next_acceptor_pos - x.donor_pos) < 4))

base_c, tq_c, mq_c, att_base, att_tq = [], [], [], [], []
with torch.no_grad():
    for i in range(0, len(X), 6):
        ch = X[i:i + 6]
        cl, co, dn = task.pair(ch)
        W = build_windows(ch, OFF, ad.device)
        don, ctl = W.donor, W.control[:, -1:]
        q_cl = capture_proj(ad, L3, ["query"], lambda: ad.model(**cl))["query"]
        q_co = capture_proj(ad, L3, ["query"], lambda: ad.model(**co))["query"]

        def transplanted(src):
            s = src.clone()
            b = torch.arange(s.shape[0], device=s.device)[:, None]
            s[b, don] = src[b, ctl]
            return s

        Dh = ad.hidden_size // ad.num_heads
        mean_q = q_cl[:, :, H3 * Dh:(H3 + 1) * Dh].mean(dim=(0, 1), keepdim=True)

        def meaned(src):
            s = src.clone()
            s[:, :, H3 * Dh:(H3 + 1) * Dh] = mean_q.expand_as(s[:, :, H3 * Dh:(H3 + 1) * Dh])
            return s

        o_cl = ad.model(**cl, output_attentions=True)
        m_cl = task.margin(o_cl.logits.float(), dn)
        m_co = task.margin(ad.model(**co).logits.float(), dn)
        base_c += (m_cl - m_co).tolist()

        with patch_proj(ad, L3, H3, "query", transplanted(q_cl), don):
            o = ad.model(**cl, output_attentions=True)
            a_cl = task.margin(o.logits.float(), dn)
        with patch_proj(ad, L3, H3, "query", transplanted(q_co), don):
            a_co = task.margin(ad.model(**co).logits.float(), dn)
        tq_c += (a_cl - a_co).tolist()

        with patch_proj(ad, L3, H3, "query", meaned(q_cl), don):
            b_cl = task.margin(ad.model(**cl).logits.float(), dn)
        with patch_proj(ad, L3, H3, "query", meaned(q_co), don):
            b_co = task.margin(ad.model(**co).logits.float(), dn)
        mq_c += (b_cl - b_co).tolist()

        A0, A1 = o_cl.attentions[L3][:, H3], o.attentions[L3][:, H3]
        for j, x in enumerate(ch):
            d, p = x.donor_pos + OFF, x.next_acceptor_pos + OFF
            att_base.append(A0[j, d, p - 2:p + 1].sum().item())
            att_tq.append(A1[j, d, p - 2:p + 1].sum().item())
        print(f"  {min(i+6, len(X))}/{len(X)}", end="\r", flush=True)
print()

base_c, tq_c, mq_c = map(np.asarray, (base_c, tq_c, mq_c))
att_base, att_tq = np.asarray(att_base), np.asarray(att_tq)
own = np.array([a for a, _, _ in flags])
real = np.array([b for _, b, _ in flags])
ag = np.array([c for _, _, c in flags])


def rep(name, m):
    if m.sum() == 0:
        print(f"  {name:34s} n=0")
        return
    lo, hi = gboot_ratio(base_c[m] - tq_c[m], base_c[m], [g for g, k in zip(genes, m) if k])
    print(f"  {name:34s} n={int(m.sum()):3d}  transplant_frac_lost="
          f"{ratio_of_means(base_c[m]-tq_c[m], base_c[m]):.3f} [{lo:.3f},{hi:.3f}]"
          f"  mean_abl={ratio_of_means(base_c[m]-mq_c[m], base_c[m]):.3f}"
          f"  att_tq={att_tq[m].mean():.4f}  att_base={att_base[m].mean():.4f}")


allm = np.ones(len(X), bool)
print(f"\nreported in readout_path.json: transplant_frac_lost=0.291, mean_ablate=0.300")
rep("ALL (should match 0.291)", allm)
rep("control NOT any AG", ~ag)
rep("control IS an AG", ag)
rep("control NOT own/real acceptor", ~(own | real))
rep("control IS own/real acceptor", own | real)

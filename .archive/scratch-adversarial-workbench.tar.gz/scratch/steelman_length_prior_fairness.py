"""Does the baseline's 481-bin length histogram 'manufacture' conflicts?

Refits the baseline's length prior three ways on the SAME train counts and
re-runs the exact baseline scoring rule on the full val split:

  A) original per-integer histogram (what the repo used)
  B) Gaussian-smoothed histogram (bw = 3 and 10 nt) -- removes the 'spikiness'
  C) the READOUT's own length model: MLP(2->16->1) on (log L, sqrt L), fit by
     multinomial MLE on the identical train length counts.  This is literally
     "give the baseline the same length model the neural readout has".

Reports val top-1, conflict count, and the symmetric flip accounting the
finding omits (how often the length prior RESCUES the true pair vs breaks it).
"""
from __future__ import annotations
import json, pickle, sys
import numpy as np
import torch
from torch import nn

ROOT = "/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation"
sys.path.insert(0, f"{ROOT}/src")

b = pickle.load(open(f"{ROOT}/results/splicebert_partner_selection/baselines/local_pair_baseline.pkl", "rb"))
lp = b.length_prior
N_TRAIN = 177418
counts = np.round(np.exp(lp.log_prob) * (N_TRAIN + 481)) - 1.0  # exact raw train counts
assert counts.sum() == N_TRAIN
Lgrid = np.arange(lp.min_length, lp.max_length + 1).astype(np.float64)

def norm_logp(c, pseudo=1.0):
    c = c + pseudo
    return np.log(c / c.sum())

priorA = lp.log_prob.copy()

def smooth(bw):
    x = Lgrid[:, None] - Lgrid[None, :]
    K = np.exp(-0.5 * (x / bw) ** 2)
    K /= K.sum(axis=1, keepdims=True)
    return norm_logp(K @ counts, pseudo=1e-6)

priorB3 = smooth(3.0)
priorB10 = smooth(10.0)

# C) readout's own functional form, multinomial MLE on the same counts
torch.manual_seed(0)
mlp = nn.Sequential(nn.Linear(2, 16), nn.GELU(), nn.Linear(16, 1))
feats = torch.stack((torch.log(torch.tensor(Lgrid)), torch.sqrt(torch.tensor(Lgrid))), -1).float()
tc = torch.tensor(counts, dtype=torch.float32)
opt = torch.optim.Adam(mlp.parameters(), lr=0.05)
for it in range(4000):
    opt.zero_grad()
    logits = mlp(feats).squeeze(-1)
    logp = torch.log_softmax(logits, 0)
    loss = -(tc * logp).sum() / tc.sum()
    loss.backward()
    opt.step()
priorC = torch.log_softmax(mlp(feats).squeeze(-1), 0).detach().numpy().astype(np.float64)
print(f"[fit] readout-form length model: train NLL {loss.item():.4f} nats; "
      f"histogram NLL {-(counts * priorA).sum() / counts.sum():.4f} nats")

PRIORS = {"A_histogram": priorA, "B_smooth_bw3": priorB3, "B_smooth_bw10": priorB10, "C_readout_form": priorC}

# ---- vectorised PWM scoring -------------------------------------------------
IDX = np.full(256, 4, dtype=np.int64)
for i, ch in enumerate("ACGT"):
    IDX[ord(ch)] = i

def pwm_table(pwm):
    lo = pwm.log_odds  # [W,4]
    bg = (pwm.background[None, :] * lo).sum(1)  # expectation for unknown base
    return np.concatenate([lo, bg[:, None]], axis=1)  # [W,5]

ACC = pwm_table(b.acceptor_pwm)   # W=23, offsets -20..+2 relative to pos
DON = pwm_table(b.donor_pwm)      # W=9,  offsets -3..+5
AU, AD = 20, 3
DU, DD = 3, 6

def site_scores(seq_i, positions, table, up, down):
    W = table.shape[0]
    starts = positions - up
    ok = (starts >= 0) & (starts + W <= len(seq_i))
    out = np.full(len(positions), -np.inf)
    if ok.any():
        idx = starts[ok][:, None] + np.arange(W)[None, :]
        bases = seq_i[idx]
        out[ok] = table[np.arange(W)[None, :], bases].sum(1)
    return out

VAL = f"{ROOT}/data/processed/splicebert_partner_selection/v1/val.jsonl"
LIMIT = int(sys.argv[1]) if len(sys.argv) > 1 else 10**9

stats = {k: {"top1": 0, "conflict": 0} for k in PRIORS}
conflict_ids = {k: set() for k in PRIORS}
flip_break = 0   # PWM-only picks TRUE, +length picks decoy  (length breaks it)
flip_rescue = 0  # PWM-only picks decoy, +length picks TRUE  (length rescues it)
pwm_only_top1 = 0
pairwise = {"conflict":0,"length_flips_onto_decoy":0,"nonconflict":0,"length_rescues_true":0}
n = 0
for line in open(VAL):
    d = json.loads(line)
    seq_i = IDX[np.frombuffer(d["sequence"].encode(), dtype=np.uint8)]
    accs = np.array([s["position"] for s in d["acceptors"]])
    dons = np.array([s["position"] for s in d["donors"]])
    sa = site_scores(seq_i, accs, ACC, AU, AD)
    sd = site_scores(seq_i, dons, DON, DU, DD)
    ai = np.array([p["acceptor_index"] for p in d["pairs"]])
    di = np.array([p["donor_index"] for p in d["pairs"]])
    ap = np.array([p["acceptor_pos"] for p in d["pairs"]])
    dp = np.array([p["donor_pos"] for p in d["pairs"]])
    L = dp - ap
    ti = int(d["true_pair_index"])
    base = sa[ai] + sd[di]
    for k, pr in PRIORS.items():
        s = base + b.length_weight * pr[L - lp.min_length]
        pred = int(np.nanargmax(s))
        stats[k]["top1"] += pred == ti
        if pred != ti:
            stats[k]["conflict"] += 1
            conflict_ids[k].add(d["example_id"])
    p_pwm = int(np.nanargmax(base))
    sA = base + b.length_weight * priorA[L - lp.min_length]
    p_full = int(np.nanargmax(sA))
    pwm_only_top1 += p_pwm == ti
    if p_pwm == ti and p_full != ti:
        flip_break += 1
    if p_pwm != ti and p_full == ti:
        flip_rescue += 1
    # pairwise decomposition against the ARGMAX decoy (the finding's definition)
    if p_full != ti:  # conflict
        dpwm = base[ti] - base[p_full]
        pairwise["conflict"] += 1
        if dpwm > 0:
            pairwise["length_flips_onto_decoy"] += 1
    else:
        s2 = sA.copy(); s2[ti] = -np.inf
        bd = int(np.argmax(s2))
        dpwm = base[ti] - base[bd]
        pairwise["nonconflict"] += 1
        if dpwm < 0:
            pairwise["length_rescues_true"] += 1
    n += 1
    if n >= LIMIT:
        break

print(f"\nval examples scored: {n}")
print(f"reference (repo metrics.json): val top1 = 0.41215, conflicts = 10034 / 17069\n")
for k in PRIORS:
    t = stats[k]["top1"] / n
    print(f"  {k:16s} val top1 = {t:.5f}   conflicts = {stats[k]['conflict']:6d} ({stats[k]['conflict']/n:.4f})")
print(f"  {'PWM_only (no L)':16s} val top1 = {pwm_only_top1/n:.5f}   conflicts = {n - pwm_only_top1:6d}")

A = conflict_ids["A_histogram"]
for k in ["B_smooth_bw3", "B_smooth_bw10", "C_readout_form"]:
    K = conflict_ids[k]
    print(f"\n  {k}: resolves {len(A - K)} of the {len(A)} original conflicts ({len(A-K)/len(A):.3%}); "
          f"creates {len(K - A)} NEW conflicts; net change {len(K)-len(A):+d}")

print(f"\nSYMMETRIC FLIP ACCOUNTING for the histogram length prior (all val, n={n}):")
print(f"  length prior BREAKS a correct PWM-only prediction: {flip_break} ({flip_break/n:.3%})")
print(f"  length prior RESCUES an incorrect PWM-only prediction: {flip_rescue} ({flip_rescue/n:.3%})")
print(f"  net effect of adding the length prior on baseline top1: {flip_rescue - flip_break:+d} examples")
print(f"\nPAIRWISE decomposition vs the ARGMAX decoy (the finding's own definition):")
print(f"  conflicts where the two PWM terms prefer the TRUE pair but length flips onto the decoy:")
print(f"    {pairwise['length_flips_onto_decoy']} / {pairwise['conflict']} = {pairwise['length_flips_onto_decoy']/max(1,pairwise['conflict']):.3%}   <- the finding's 13.4%")
print(f"  MIRROR (never reported): non-conflicts where the PWM terms prefer the best DECOY but length rescues the true pair:")
print(f"    {pairwise['length_rescues_true']} / {pairwise['nonconflict']} = {pairwise['length_rescues_true']/max(1,pairwise['nonconflict']):.3%}")

json.dump({"n": n,
           "top1": {k: stats[k]["top1"] / n for k in PRIORS},
           "conflicts": {k: stats[k]["conflict"] for k in PRIORS},
           "pwm_only_top1": pwm_only_top1 / n,
           "flip_break": flip_break, "flip_rescue": flip_rescue,
           "resolved": {k: len(A - conflict_ids[k]) for k in PRIORS},
           "created": {k: len(conflict_ids[k] - A) for k in PRIORS}},
          open(f"{ROOT}/scratch/steelman_length_prior_fairness_results.json", "w"), indent=2)

#!/usr/bin/env python
"""Does the additive-frozen model's conflict PMR survive when the PWM baseline is STRENGTHENED
on all four axes the finding names?  Runs the real seed0 checkpoint on the first NVAL val
examples and re-derives conflict PMR under each baseline variant's conflict set."""
from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np
import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))

from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.schema import SplicePairExample  # noqa: E402
from gfmcd.splicing.readout import collate_pair_indices  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint  # noqa: E402

NVAL = 2000
BATCH = 8
DATA = REPO / "data/processed/splicebert_partner_selection/v1"

device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"])
mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
readout, ck = load_pair_checkpoint(REPO / "colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt",
                                   adapter=adapter)
print("regime:", ck.get("extra_metadata", {}).get("regime"),
      "| backbone_state None:", ck.get("backbone_state") is None, "| device:", device, flush=True)

examples, ids = [], []
with (DATA / "val.jsonl").open() as f:
    for line in f:
        if not line.strip():
            continue
        ex = SplicePairExample.from_json(line)
        examples.append(ex)
        ids.append(ex.example_id)
        if len(examples) >= NVAL:
            break
print(f"{len(examples)} val examples", flush=True)

model_correct = np.zeros(len(examples), dtype=bool)
for i in range(0, len(examples), BATCH):
    ex = examples[i:i + BATCH]
    tok = adapter.tokenize([x.sequence for x in ex])
    pb = collate_pair_indices(ex, token_offset=tok.prefix_tokens, device=adapter.device)
    with torch.no_grad():
        out = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
        logits = readout(out.hidden_states[rep], pb).float().cpu()
    mask = pb.mask.cpu()
    for k, x in enumerate(ex):
        s = torch.where(mask[k], logits[k], torch.tensor(-1e18))
        t = x.true_pair_index
        # PMR == strict win over best decoy
        best_decoy = torch.cat([s[:t], s[t + 1:]]).max()
        model_correct[i + k] = bool(s[t] > best_decoy)
    if (i // BATCH) % 40 == 0:
        print(f"  {i}", flush=True)

z = np.load(REPO / "scratch/ref_baseline_corr.npz", allow_pickle=True)
bids = list(z["ids"][:len(examples)])
assert bids == ids, "val ordering mismatch"

print(f"\nmodel (additive-frozen seed0) val PMR on n={len(examples)}: {model_correct.mean():.4f}   "
      f"(published full-val 0.8682)")
print("\n=== model conflict PMR under each baseline variant's conflict set ===")
rows = {}
for lab in z.files:
    if lab == "ids":
        continue
    bc = z[lab][:len(examples)]
    conf = ~bc
    if conf.sum() == 0:
        continue
    pmr = model_correct[conf].mean()
    nonconf = model_correct[bc].mean() if bc.sum() else float("nan")
    rows[lab] = (int(conf.sum()), float(pmr), float(nonconf), float(bc.mean()))
    print(f"  {lab:34s} baseline_top1={bc.mean():.4f}  n_conflict={int(conf.sum()):5d}  "
          f"MODEL conflict PMR={pmr:.4f}   model non-conflict PMR={nonconf:.4f}")
(REPO / "scratch/ref_model_on_stronger_conflicts.json").write_text(json.dumps(
    {"n": len(examples), "model_val_pmr": float(model_correct.mean()), "rows": rows}, indent=2))
print("\nsaved.")

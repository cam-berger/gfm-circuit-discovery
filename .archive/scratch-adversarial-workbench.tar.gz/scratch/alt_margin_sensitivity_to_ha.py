#!/usr/bin/env python
"""ALT-EXPLANATION test for the finding 'true_pair_margin is algebraically BLIND to h_a on ~87%'.

Claim under test: d(margin)/d(h_a*) = 0 identically on ~87% of examples => the statistic
cannot be evidence that h_a is used.

Counter-hypothesis: the margin is  min(M_same, M_other + delta)  where delta is a shift of
f(h_a*). It is a CONCAVE, MONOTONE, PIECEWISE-LINEAR function of f(h_a*) -- flat only in the
region where the acceptor is solved with slack. Flatness = large acceptor margin, not blindness.
We measure the slack and we actually perturb h_a*.
"""
from __future__ import annotations
import json, random, sys
from pathlib import Path
import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))
from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa
from gfmcd.splicing.config import load_config  # noqa
from gfmcd.splicing.schema import SplicePairExample  # noqa
from gfmcd.splicing.readout import collate_pair_indices  # noqa
from gfmcd.splicing.training import load_pair_checkpoint  # noqa

N = int(sys.argv[1]) if len(sys.argv) > 1 else 400
BATCH = 8
NEG = float("-inf")
device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"]); mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
readout, ck = load_pair_checkpoint(REPO / "colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt", adapter=adapter)
assert ck.get("backbone_state") is None

conf = REPO / "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl"
examples = []
with conf.open() as f:
    for line in f:
        if line.strip():
            examples.append(SplicePairExample.from_json(line))
        if len(examples) >= N:
            break

rows = []
for i in range(0, len(examples), BATCH):
    ex = examples[i:i + BATCH]
    tok = adapter.tokenize([x.sequence for x in ex])
    pb = collate_pair_indices(ex, token_offset=tok.prefix_tokens, device=adapter.device)
    with torch.no_grad():
        out = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
        h = out.hidden_states[rep]
        b = torch.arange(h.shape[0], device=h.device)[:, None]
        h_a = h[b, pb.positions[..., 0]]
        h_d = h[b, pb.positions[..., 1]]
        A = readout.acceptor(h_a).squeeze(-1).float().cpu()
        D = readout.donor(h_d).squeeze(-1).float().cpu()
        L = readout.length(readout._length_features(pb.lengths)).squeeze(-1).float().cpu()
    m = pb.mask.cpu()
    acc = (pb.positions[..., 0] - tok.prefix_tokens).cpu()
    don = (pb.positions[..., 1] - tok.prefix_tokens).cpu()
    for k, x in enumerate(ex):
        mk = m[k]
        rows.append(dict(t=x.true_pair_index, A=A[k][mk].clone(), D=D[k][mk].clone(), L=L[k][mk].clone(),
                         acc=acc[k][mk].clone(), don=don[k][mk].clone()))
n = len(rows)
print(f"n={n}")


def pmr_from(scores):
    hit = 0
    for r, s in zip(rows, scores):
        t = r["t"]; d = s.clone(); d[t] = NEG
        hit += int(s[t].item() > d.max().item())
    return hit / n


def margins(scores):
    out = []
    for r, s in zip(rows, scores):
        t = r["t"]; d = s.clone(); d[t] = NEG
        out.append(float(s[t] - d.max()))
    return out


full = [r["A"] + r["D"] + r["L"] for r in rows]
print(f"\nfull PMR = {pmr_from(full):.4f}")

# ---- (1) closed-form decomposition of the margin as a function of f(h_a*) ----
# margin(delta) = min(M_same, M_other + delta), delta = additive shift applied to f(h_a*)
M_same, M_other, slack = [], [], []
for r in rows:
    t = r["t"]; s = r["A"] + r["D"] + r["L"]
    same = (r["acc"] == r["acc"][t])
    ms = s.clone(); ms[~same] = NEG; ms[t] = NEG          # decoys sharing the TRUE acceptor
    mo = s.clone(); mo[same] = NEG                         # decoys with a DIFFERENT acceptor
    M_same.append(float(s[t] - ms.max()))
    M_other.append(float(s[t] - mo.max()))
M_same_t = torch.tensor(M_same); M_other_t = torch.tensor(M_other)
flat = (M_other_t > M_same_t)  # top decoy shares the true acceptor -> local gradient wrt h_a* is 0
print(f"top decoy shares TRUE acceptor (local zero-gradient region): {flat.float().mean():.4f}")
print("ACCEPTOR-SIDE SLACK = how far f(h_a*) can fall before a WRONG-ACCEPTOR decoy takes over")
q = torch.quantile(M_other_t, torch.tensor([0.05, 0.25, 0.5, 0.75, 0.95]))
print(f"  M_other quantiles (5/25/50/75/95): {[round(float(v),2) for v in q]}")
print(f"  within-example SD of the A term: {torch.stack([r['A'].std() for r in rows]).mean():.3f}")

# ---- (2) ACTUALLY MOVE h_a*: sweep a shift delta on f(h_a*) ----
print("\nSWEEP: subtract delta from f(h_a*) only (i.e. degrade the TRUE acceptor's representation score)")
for delta in [0.0, 0.5, 1.0, 2.0, 4.0, 8.0, 16.0]:
    sc = []
    for r in rows:
        a = r["A"].clone()
        a[r["acc"] == r["acc"][r["t"]]] -= delta
        sc.append(a + r["D"] + r["L"])
    mm = margins(sc)
    print(f"  delta={delta:5.1f}  PMR={pmr_from(sc):.4f}  mean margin={sum(mm)/n:+.3f}")

# ---- (3) SUBSTITUTE h_a* with the representation of another candidate acceptor ----
print("\nSUBSTITUTION: replace f(h_a*) by f(h of another candidate acceptor) -- a real change to h_a*")
random.seed(0)
for label, pick in [("random other acceptor", "rand"), ("median other acceptor", "med"), ("worst other acceptor", "min")]:
    sc = []
    for r in rows:
        t = r["t"]; ta = int(r["acc"][t])
        # per-distinct-acceptor score
        uniq = {}
        for j in range(len(r["acc"])):
            uniq[int(r["acc"][j])] = float(r["A"][j])
        others = [v for k, v in uniq.items() if k != ta]
        if not others:
            sc.append(r["A"] + r["D"] + r["L"]); continue
        if pick == "rand":
            v = random.choice(others)
        elif pick == "med":
            v = sorted(others)[len(others) // 2]
        else:
            v = min(others)
        a = r["A"].clone(); a[r["acc"] == ta] = v
        sc.append(a + r["D"] + r["L"])
    mm = margins(sc)
    print(f"  f(h_a*) := {label:24s}  PMR={pmr_from(sc):.4f}  mean margin={sum(mm)/n:+.3f}")

# ---- (4) the finding's own 'f cancels' logic taken to its limit ----
sc = [r["D"] + r["L"] for r in rows]
ties = sum(1 for r, s in zip(rows, sc) if float(s[r["t"]]) == float(torch.cat([s[:r["t"]], s[r["t"]+1:]]).max()))
print(f"\nf := 0 (drop the acceptor representation entirely): PMR={pmr_from(sc):.4f}  exact ties at the top: {ties}/{n}")
print("  (if the margin were truly 'blind' to h_a, deleting f could not hurt it)")

# ---- (5) how many candidate pairs does f suppress? ----
supp = []
for r in rows:
    t = r["t"]; s = r["A"] + r["D"] + r["L"]
    no_f = r["D"] + r["L"]
    # rank of true pair with and without f
    supp.append((int((s > s[t]).sum()), int((no_f > no_f[t]).sum()), len(s)))
print(f"\nmean rank of the true pair (0=best): with f = {sum(x[0] for x in supp)/n:.1f}, "
      f"without f = {sum(x[1] for x in supp)/n:.1f}, mean candidates = {sum(x[2] for x in supp)/n:.1f}")

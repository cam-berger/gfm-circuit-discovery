#!/usr/bin/env python
"""Is the CROP-LEFT collapse a SHARP positional lookup (finding's claim) or
GENERIC offset-brittleness of a frozen probe?

Sweep the left shift k = 0,1,2,3,5,10,20,50 and, for each, report
  PMR
  acc_hit : does the ACCEPTOR MLP alone rank the true acceptor #1 among acceptors?
  don_hit : does the DONOR MLP alone rank the true donor #1 among donors?

A delta-at-index-200 detector must break at k=1 (position 199 != 200).
Generic representational brittleness degrades smoothly.

Also compares CROP-LEFT (shifts absolute positions, keeps distance-from-end)
against CROP-RIGHT (keeps absolute positions, shifts distance-from-end).
"""
from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np
import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))

from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.schema import SplicePairExample, PairCandidate  # noqa: E402
from gfmcd.splicing.readout import collate_pair_indices  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint  # noqa: E402

N = 300
BATCH = 6


def crop(example, kl, kr):
    seq = example.sequence
    n = len(seq)
    new_seq = seq[kl: n - kr] if kr else seq[kl:]
    lo, hi = kl, n - kr
    pairs, true_idx = [], None
    tk = (example.true_pair.acceptor_pos, example.true_pair.donor_pos)
    for p in example.pairs:
        a, d = p.acceptor_pos, p.donor_pos
        if a - 2 < lo or a >= hi or d < lo or d + 2 > hi:
            continue
        if (a, d) == tk:
            true_idx = len(pairs)
        pairs.append(PairCandidate(acceptor_pos=a - kl, donor_pos=d - kl,
                                   acceptor_index=p.acceptor_index, donor_index=p.donor_index))
    if true_idx is None or len(pairs) < 2:
        return None
    return SplicePairExample(
        example_id=example.example_id, sequence=new_seq,
        acceptors=example.acceptors, donors=example.donors,
        pairs=tuple(pairs), true_pair_index=true_idx,
        gene_id=example.gene_id, transcript_id=example.transcript_id,
        chrom=example.chrom, strand=example.strand, exon_number=example.exon_number,
        genomic_exon_start=example.genomic_exon_start, genomic_exon_end=example.genomic_exon_end,
        split=example.split, metadata=example.metadata)


def evaluate(adapter, readout, rep, examples):
    wins = acc_hits = don_hits = tot = 0
    for i in range(0, len(examples), BATCH):
        ex = examples[i:i + BATCH]
        tok = adapter.tokenize([x.sequence for x in ex])
        pb = collate_pair_indices(ex, token_offset=tok.prefix_tokens, device=adapter.device)
        with torch.no_grad():
            out = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
            hidden = out.hidden_states[rep]
            b = torch.arange(hidden.shape[0], device=hidden.device)[:, None]
            A = readout.acceptor(hidden[b, pb.positions[..., 0]]).squeeze(-1).float().cpu()
            D = readout.donor(hidden[b, pb.positions[..., 1]]).squeeze(-1).float().cpu()
            lg = readout(hidden, pb).float().cpu()
        mask = pb.mask.cpu()
        for k, x in enumerate(ex):
            m = mask[k].numpy()
            t = x.true_pair_index
            l = lg[k][mask[k]]
            dec = torch.cat([l[:t], l[t + 1:]])
            wins += int(l[t].item() > dec.max().item())
            ta = x.pairs[t].acceptor_pos
            td = x.pairs[t].donor_pos
            ap = np.array([p.acceptor_pos for p in x.pairs])
            dp = np.array([p.donor_pos for p in x.pairs])
            Ak = A[k][mask[k]].numpy()
            Dk = D[k][mask[k]].numpy()
            # best score per DISTINCT site position
            au = {}
            for p, v in zip(ap, Ak):
                au[p] = max(au.get(p, -1e9), v)
            du = {}
            for p, v in zip(dp, Dk):
                du[p] = max(du.get(p, -1e9), v)
            acc_hits += int(max(au, key=au.get) == ta)
            don_hits += int(max(du, key=du.get) == td)
            tot += 1
    return wins / tot, acc_hits / tot, don_hits / tot, tot


def main():
    device = "mps" if torch.backends.mps.is_available() else "cpu"
    cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
    rep = int(cfg["readout"]["representation_layer"])
    mc = cfg["model"]
    adapter = SpliceBertAdapter.from_pretrained(
        REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
        trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
    readout, _ = load_pair_checkpoint(
        REPO / "colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt", adapter=adapter)

    examples = []
    with (REPO / "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl").open() as f:
        for line in f:
            if line.strip():
                examples.append(SplicePairExample.from_json(line))
                if len(examples) >= N:
                    break

    res = {}
    print(f"{'condition':16s} {'acceptor@':>10s} {'PMR':>7s} {'A picks':>8s} {'D picks':>8s}")
    print(f"{'':16s} {'':>10s} {'':>7s} {'true acc':>8s} {'true don':>8s}")
    for k in (0, 1, 2, 3, 5, 10, 20, 50):
        exs = [crop(x, k, 0) for x in examples]
        exs = [x for x in exs if x is not None]
        pmr, ah, dh, tot = evaluate(adapter, readout, rep, exs)
        res[f"CROP-LEFT {k}"] = dict(pmr=pmr, acc_hit=ah, don_hit=dh, n=tot)
        print(f"{'CROP-LEFT '+str(k):16s} {200-k:>10d} {pmr:>7.4f} {ah:>8.4f} {dh:>8.4f}", flush=True)

    for k in (20, 50):
        exs = [crop(x, 0, k) for x in examples]
        exs = [x for x in exs if x is not None]
        pmr, ah, dh, tot = evaluate(adapter, readout, rep, exs)
        res[f"CROP-RIGHT {k}"] = dict(pmr=pmr, acc_hit=ah, don_hit=dh, n=tot)
        print(f"{'CROP-RIGHT '+str(k):16s} {200:>10d} {pmr:>7.4f} {ah:>8.4f} {dh:>8.4f}", flush=True)

    (REPO / "scratch/steelman_shift_results.json").write_text(json.dumps(res, indent=2))


if __name__ == "__main__":
    main()

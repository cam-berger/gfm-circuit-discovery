#!/usr/bin/env python
"""(a) Under LEFT-CROP-50 the true acceptor moves 200 -> 150. Where does the
acceptor term's argmax land? If f is a 'position-200' detector it should FOLLOW
INDEX 200 (i.e. land on the candidate acceptor nearest new-index 200 = old 250).
(b) Is the trained f's near-200 bump for DECOYS explained by biology? Compare
    f-bins against the fitted PWM acceptor score in the same bins."""
from __future__ import annotations
import pickle, sys, statistics
from pathlib import Path
import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))
from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.schema import SplicePairExample, SiteCandidate, PairCandidate  # noqa: E402
from gfmcd.splicing.readout import collate_pair_indices  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint  # noqa: E402
from gfmcd.splicing.baselines import site_window  # noqa: E402

N, BATCH = 200, 8
device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"]); mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
readout, ck = load_pair_checkpoint(
    REPO / "colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt", adapter=adapter)

baseline = pickle.load(open(REPO / "colab_results/splicebert_run/baselines/local_pair_baseline.pkl", "rb"))
apwm = baseline.acceptor_pwm

examples = []
with (REPO / "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl").open() as f:
    for line in f:
        if line.strip():
            examples.append(SplicePairExample.from_json(line))
        if len(examples) >= N:
            break


def leftcrop(x, left=50):
    seq = x.sequence[left:]; n = len(seq)
    amap, dmap, accs, dons = {}, {}, [], []
    for i, s in enumerate(x.acceptors):
        p = s.position - left
        if 2 <= p < n and seq[p-2:p] == s.motif:
            amap[i] = len(accs); accs.append(SiteCandidate(p, "acceptor", s.motif))
    for i, s in enumerate(x.donors):
        p = s.position - left
        if 0 <= p <= n-2 and seq[p:p+2] == s.motif:
            dmap[i] = len(dons); dons.append(SiteCandidate(p, "donor", s.motif))
    pairs, t = [], None
    for j, pr in enumerate(x.pairs):
        if pr.acceptor_index not in amap or pr.donor_index not in dmap:
            if j == x.true_pair_index: return None
            continue
        if j == x.true_pair_index: t = len(pairs)
        pairs.append(PairCandidate(pr.acceptor_pos-left, pr.donor_pos-left,
                                   amap[pr.acceptor_index], dmap[pr.donor_index]))
    if t is None: return None
    return SplicePairExample(x.example_id, seq, tuple(accs), tuple(dons), tuple(pairs), t,
                             x.split, x.chrom, x.strand, x.gene_id, x.transcript_id,
                             x.exon_number, x.genomic_exon_start, x.genomic_exon_end, x.metadata)


def acceptor_scores(exs):
    """-> list of dict{pos: f_score}, aligned with exs"""
    out = []
    for i in range(0, len(exs), BATCH):
        eb = exs[i:i+BATCH]
        tok = adapter.tokenize([e.sequence for e in eb])
        pb = collate_pair_indices(eb, token_offset=tok.prefix_tokens, device=adapter.device)
        with torch.no_grad():
            h = adapter.forward(tok, output_hidden_states=True).hidden_states[rep]
            b = torch.arange(h.shape[0], device=h.device)[:, None]
            A = readout.acceptor(h[b, pb.positions[..., 0]]).squeeze(-1).float().cpu()
        pos = pb.positions.cpu(); m = pb.mask.cpu(); off = tok.prefix_tokens
        for k in range(len(eb)):
            d = {}
            for p in range(m.shape[1]):
                if m[k, p]:
                    d[int(pos[k, p, 0]) - off] = float(A[k, p])
            out.append(d)
    return out

# ---- (a) left-crop argmax location
cropped = [c for c in (leftcrop(x) for x in examples) if c is not None]
sc = acceptor_scores(cropped)
follow_index200, at_true150, dists = 0, 0, []
for e, d in zip(cropped, sc):
    ta = e.pairs[e.true_pair_index].acceptor_pos  # == 150
    best = max(d, key=d.get)
    nearest200 = min(d, key=lambda p: (abs(p - 200), p))
    follow_index200 += int(best == nearest200)
    at_true150 += int(best == ta)
    dists.append(abs(best - 200))
n = len(cropped)
print(f"LEFT-CROP-50 (true acceptor now at index 150), n={n}")
print(f"  argmax f == TRUE acceptor (index 150)                : {at_true150/n:.3f}")
print(f"  argmax f == candidate acceptor NEAREST INDEX 200     : {follow_index200/n:.3f}")
print(f"  median |argmax_index - 200| = {statistics.median(dists):.1f}  "
      f"mean = {sum(dists)/n:.1f}")
d_true = [abs(max(d, key=d.get) - 150) for d in sc]
print(f"  mean |argmax_index - 150 (TRUE site)| = {sum(d_true)/n:.1f}")
import random as _r
_r.seed(0)
chance = [abs(_r.choice(list(d)) - 200) for d in sc for _ in range(20)]
print(f"  chance mean |random candidate - 200|  = {sum(chance)/len(chance):.1f}")

# ---- (b) is the near-200 bump biological? compare f vs PWM in the same bins
orig_sc = acceptor_scores(examples)
bins = {"TRUE (pos 200)": ([], []), "decoy |p-200|<=15": ([], []), "decoy |p-200|>15": ([], [])}
for e, d in zip(examples, orig_sc):
    ta = e.pairs[e.true_pair_index].acceptor_pos
    for p, f in d.items():
        w = site_window(e.sequence, p, "acceptor")
        pw = apwm.score(w)
        key = "TRUE (pos 200)" if p == ta else ("decoy |p-200|<=15" if abs(p-200) <= 15 else "decoy |p-200|>15")
        bins[key][0].append(f)
        if pw == pw:  # not nan
            bins[key][1].append(pw)
print("\nACCEPTOR-TERM f  vs  fitted PWM acceptor log-score, by position bin (n=200 examples)")
for k, (fs, pws) in bins.items():
    print(f"  {k:20s} n={len(fs):6d}  mean f = {sum(fs)/len(fs):+8.3f}   "
          f"mean PWM = {sum(pws)/len(pws):+8.3f}")

#!/usr/bin/env python
"""Data-check: is the tracing metric (true_pair_margin of the ADDITIVE readout) a
donor-detection channel?  Predicted signature of the finding under review:

  ablation effect on ACCEPTOR-BLIND margin (g + L only)  ~=  effect on FULL margin
  ablation effect on DONOR-BLIND    margin (f + L only)  ~=  small

Uses the real tracing splits (discovery for head selection, confirmation for the
effect) and the local additive-frozen seed0 checkpoint.  Read-only.
"""
from __future__ import annotations

import json
from pathlib import Path
import sys

import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))

from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.circuits.attribution import head_attribution_scan  # noqa: E402
from gfmcd.circuits.hf_bert import capture_head_outputs, edit_heads, matched_random_head_sets  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.io import load_jsonl  # noqa: E402
from gfmcd.splicing.readout import collate_pair_indices, true_pair_margin  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint  # noqa: E402

N_D = int(sys.argv[1]) if len(sys.argv) > 1 else 64      # discovery (head selection)
N_V = int(sys.argv[2]) if len(sys.argv) > 2 else 128     # confirmation (effect)
SET_SIZE = 5
BATCH = 8
NEG = float("-inf")

device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"])
mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
ckpt = REPO / "colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt"
readout, checkpoint = load_pair_checkpoint(ckpt, adapter=adapter)
assert checkpoint.get("backbone_state") is None
print("regime:", checkpoint.get("extra_metadata", {}).get("regime"),
      "| readout:", type(readout).__name__, "| rep layer:", rep, "| device:", device)

sd = REPO / "results/splicebert_partner_selection/circuits/discovery"
D = load_jsonl(sd / "discovery.jsonl")[:N_D]
V = load_jsonl(sd / "confirmation.jsonl")[:N_V]
print(f"D={len(D)}  Vc={len(V)}")


def batches(examples):
    out = []
    for i in range(0, len(examples), BATCH):
        ex = examples[i:i + BATCH]
        tok = adapter.tokenize([x.sequence for x in ex])
        pb = collate_pair_indices(ex, token_offset=tok.prefix_tokens, device=adapter.device)
        out.append((ex, tok, pb))
    return out


def margin_sum(tok, pb, grad=False):
    out = adapter.forward(tok, output_hidden_states=True, output_attentions=False, grad=grad)
    return true_pair_margin(readout(out.hidden_states[rep], pb), pb).sum()


# ---------- head selection: AtP necessity screen on D (same recipe as run_tracing) ----------
Db = batches(D)
caches = []
for ex, tok, pb in Db:
    with torch.no_grad():
        caches.append(capture_head_outputs(adapter, lambda tok=tok, pb=pb: float(margin_sum(tok, pb))))
agg: dict[tuple[int, int], float] = {}
for (ex, tok, pb), cache in zip(Db, caches):
    zeros = {l: torch.zeros_like(v) for l, v in cache.items()}
    res = head_attribution_scan(adapter, zeros, lambda tok=tok, pb=pb: margin_sum(tok, pb, grad=True))
    for e in res:
        agg[(e.layer, e.head)] = agg.get((e.layer, e.head), 0.0) - e.attribution  # act*grad
C = [k for k, _ in sorted(agg.items(), key=lambda kv: kv[1], reverse=True)[:SET_SIZE]]
print("AtP-necessity top heads (layer,head):", C)

# ---------- effect decomposition on Vc ----------
Vb = batches(V)


def terms(tok, pb, ablate=None):
    ctx = edit_heads(adapter, ablate[0], mode=ablate[1]) if ablate else None
    with torch.no_grad():
        if ctx is not None:
            with ctx:
                out = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
        else:
            out = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
        hidden = out.hidden_states[rep]
        b = torch.arange(hidden.shape[0], device=hidden.device)[:, None]
        A = readout.acceptor(hidden[b, pb.positions[..., 0]]).squeeze(-1).float().cpu()
        Dn = readout.donor(hidden[b, pb.positions[..., 1]]).squeeze(-1).float().cpu()
        L = readout.length(readout._length_features(pb.lengths)).squeeze(-1).float().cpu()
    return A, Dn, L


def collect(ablate=None):
    rows = []
    for ex, tok, pb in Vb:
        A, Dn, L = terms(tok, pb, ablate=ablate)
        mask = pb.mask.cpu()
        acc = (pb.positions[..., 0]).cpu()
        don = (pb.positions[..., 1]).cpu()
        for k, x in enumerate(ex):
            m = mask[k]
            rows.append(dict(A=A[k][m], D=Dn[k][m], L=L[k][m], acc=acc[k][m], don=don[k][m],
                             t=int((torch.arange(len(m))[m] == x.true_pair_index).nonzero()[0])))
    return rows


def margin_stats(rows):
    """full margin + its dA/dD/dL decomposition (vs each row's own best decoy),
    plus acceptor-blind (D+L) and donor-blind (A+L) margins."""
    out = dict(full=[], dA=[], dD=[], dL=[], accblind=[], donblind=[], shares_acc=[], shares_don=[])
    for r in rows:
        t = r["t"]
        s = r["A"] + r["D"] + r["L"]
        d = s.clone(); d[t] = NEG
        j = int(d.argmax())
        out["full"].append(float(s[t] - s[j]))
        out["dA"].append(float(r["A"][t] - r["A"][j]))
        out["dD"].append(float(r["D"][t] - r["D"][j]))
        out["dL"].append(float(r["L"][t] - r["L"][j]))
        out["shares_acc"].append(int(r["acc"][j]) == int(r["acc"][t]))
        out["shares_don"].append(int(r["don"][j]) == int(r["don"][t]))
        for name, sc in (("accblind", r["D"] + r["L"]), ("donblind", r["A"] + r["L"])):
            dd = sc.clone(); dd[t] = NEG
            out[name].append(float(sc[t] - dd.max()))
    return {k: (sum(v) / len(v)) for k, v in out.items()}


clean_rows = collect()
abl_rows = collect(ablate=(C, "mean"))
cs, as_ = margin_stats(clean_rows), margin_stats(abl_rows)

rand = matched_random_head_sets(adapter, C, n=3, seed=0, exclude_selected=True)
rand_stats = [margin_stats(collect(ablate=(list(rs), "mean"))) for rs in rand]

print("\n=== clean margin structure (Vc, n=%d) ===" % len(clean_rows))
print(f"  mean full margin        {cs['full']:+.4f}   (dA {cs['dA']:+.4f} | dD {cs['dD']:+.4f} | dL {cs['dL']:+.4f})")
print(f"  top decoy shares true acceptor {cs['shares_acc']:.3f} | shares true donor {cs['shares_don']:.3f}")
print(f"  acceptor-blind margin (D+L) {cs['accblind']:+.4f} | donor-blind margin (A+L) {cs['donblind']:+.4f}")

eff_full = cs["full"] - as_["full"]
print(f"\n=== mean-ablation of C={C} ===")
print(f"  EFFECT on FULL margin            {eff_full:+.4f}")
print(f"  EFFECT on ACCEPTOR-BLIND (D+L)   {cs['accblind'] - as_['accblind']:+.4f}"
      f"   ratio to full = {(cs['accblind']-as_['accblind'])/eff_full:+.3f}")
print(f"  EFFECT on DONOR-BLIND    (A+L)   {cs['donblind'] - as_['donblind']:+.4f}"
      f"   ratio to full = {(cs['donblind']-as_['donblind'])/eff_full:+.3f}")
print("  effect decomposition of the FULL margin:")
print(f"    via donor term    dD  {cs['dD'] - as_['dD']:+.4f}  ({100*(cs['dD']-as_['dD'])/eff_full:.1f}% of effect)")
print(f"    via acceptor term dA  {cs['dA'] - as_['dA']:+.4f}  ({100*(cs['dA']-as_['dA'])/eff_full:.1f}% of effect)")
print(f"    via length term   dL  {cs['dL'] - as_['dL']:+.4f}  ({100*(cs['dL']-as_['dL'])/eff_full:.1f}% of effect)")
print(f"  matched-random 5-head sets, effect on FULL margin: "
      f"{[round(cs['full'] - r['full'], 4) for r in rand_stats]}")

json.dump(dict(C=[list(c) for c in C], n_Vc=len(clean_rows), clean=cs, ablated=as_,
               random=rand_stats),
          open(REPO / "scratch/check_tracing_channel_results.json", "w"), indent=2)
print("\nwrote scratch/check_tracing_channel_results.json")

#!/usr/bin/env python
"""Referee check of the finding: "specificity=false is explained by margin headroom;
effect_O/effect_Vc tracks clean_margin_O/clean_margin_Vc".

Tests:
 1. Measure clean per-example true-pair margins on Vc (confirmation) and O (ordinary).
 2. For SEVERAL head sets (smoke C + random size-5 sets), measure mean-ablation effect on
    Vc and on O.  If the headroom law holds, eff_O/eff_Vc ~= margin_O/margin_Vc for EVERY set.
 3. Per-example regression of ablation effect on clean margin (within Vc, within O).
    The headroom mechanism predicts a strong positive proportionality at the example level.
Read-only.
"""
from __future__ import annotations
import json, sys, random
from pathlib import Path
import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))
from gfmcd.adapters.splicebert import SpliceBertAdapter
from gfmcd.circuits.hf_bert import edit_heads
from gfmcd.splicing.config import load_config
from gfmcd.splicing.io import load_jsonl
from gfmcd.splicing.readout import collate_pair_indices, true_pair_margin
from gfmcd.splicing.training import load_pair_checkpoint

N = int(sys.argv[1]) if len(sys.argv) > 1 else 256
SEED = int(sys.argv[2]) if len(sys.argv) > 2 else 0
BATCH = 8
device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"])
mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
ckpt = REPO / f"colab_results/splicebert_run/runs/additive-frozen_seed{SEED}/checkpoint.pt"
readout, checkpoint = load_pair_checkpoint(ckpt, adapter=adapter)
assert checkpoint.get("backbone_state") is None
print("seed", SEED, "regime", checkpoint.get("extra_metadata", {}).get("regime"), "rep", rep, device, flush=True)

sd = REPO / "results/splicebert_partner_selection/circuits/discovery"
Vc = load_jsonl(sd / "confirmation.jsonl")[:N]
O = load_jsonl(sd / "ordinary.jsonl")[:N]


def batches(ex_list):
    out = []
    for i in range(0, len(ex_list), BATCH):
        ex = ex_list[i:i + BATCH]
        tok = adapter.tokenize([x.sequence for x in ex])
        pb = collate_pair_indices(ex, token_offset=tok.prefix_tokens, device=adapter.device)
        out.append((tok, pb))
    return out


def margins(bs, heads=None):
    vals = []
    with torch.no_grad():
        for tok, pb in bs:
            if heads:
                with edit_heads(adapter, heads, mode="mean"):
                    out = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
                    m = true_pair_margin(readout(out.hidden_states[rep], pb), pb)
            else:
                out = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
                m = true_pair_margin(readout(out.hidden_states[rep], pb), pb)
            vals.extend([float(x) for x in m])
    return vals


bV, bO = batches(Vc), batches(O)
cV, cO = margins(bV), margins(bO)
mV, mO = sum(cV) / len(cV), sum(cO) / len(cO)
print(f"clean mean margin: Vc={mV:.3f}  O={mO:.3f}  ratio O/Vc={mO/mV:.3f}", flush=True)

rng = random.Random(7)
all_heads = [(l, h) for l in range(adapter.num_layers) for h in range(adapter.num_heads)]
head_sets = {"smoke_C": [(1, 1), (1, 7), (4, 2)]}
for i in range(4):
    head_sets[f"rand{i}"] = rng.sample(all_heads, 5)
head_sets["L2-L4_top"] = [(4, 0), (2, 13), (3, 4), (2, 5), (3, 9)]  # AtP top per DECISIONS.md

res = {"seed": SEED, "n": N, "clean_margin_Vc": mV, "clean_margin_O": mO,
       "margin_ratio_O_over_Vc": mO / mV, "sets": {}}


def corr(x, y):
    n = len(x)
    mx, my = sum(x) / n, sum(y) / n
    sxy = sum((a - mx) * (b - my) for a, b in zip(x, y))
    sxx = sum((a - mx) ** 2 for a in x)
    syy = sum((b - my) ** 2 for b in y)
    if sxx <= 0 or syy <= 0:
        return 0.0, 0.0
    return sxy / (sxx * syy) ** 0.5, sxy / sxx  # pearson r, OLS slope


for name, hs in head_sets.items():
    aV, aO = margins(bV, hs), margins(bO, hs)
    eV = [c - a for c, a in zip(cV, aV)]
    eO = [c - a for c, a in zip(cO, aO)]
    meV, meO = sum(eV) / len(eV), sum(eO) / len(eO)
    rV, slV = corr(cV, eV)
    rO, slO = corr(cO, eO)
    res["sets"][name] = {
        "heads": [list(h) for h in hs], "eff_Vc": meV, "eff_O": meO,
        "eff_ratio_O_over_Vc": (meO / meV) if meV != 0 else None,
        "headroom_prediction_ratio": mO / mV,
        "conflict_gt_ordinary": meV > meO,
        "per_example_r_effect_vs_cleanmargin_Vc": rV, "slope_Vc": slV,
        "per_example_r_effect_vs_cleanmargin_O": rO, "slope_O": slO,
        "frac_Vc_ablated_margin_negative": sum(1 for a in aV if a < 0) / len(aV),
    }
    print(f"{name:10s} eff_Vc={meV:+.4f} eff_O={meO:+.4f} ratio={res['sets'][name]['eff_ratio_O_over_Vc']} "
          f"(headroom predicts {mO/mV:.2f})  r(eff,margin) Vc={rV:+.3f} O={rO:+.3f}", flush=True)

out = REPO / f"scratch/ref_specificity_headroom_seed{SEED}.json"
out.write_text(json.dumps(res, indent=2) + "\n")
print("wrote", out)

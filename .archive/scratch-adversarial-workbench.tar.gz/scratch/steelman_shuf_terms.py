"""Under SHUF (positions bit-identical, content destroyed): does the ACCEPTOR MLP
still pick position 200?  If f were an 'am I at index 200?' detector, it MUST."""
from pathlib import Path
import random, sys
import numpy as np, torch
REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))
from gfmcd.adapters.splicebert import SpliceBertAdapter
from gfmcd.splicing.config import load_config
from gfmcd.splicing.schema import SplicePairExample
from gfmcd.splicing.readout import collate_pair_indices
from gfmcd.splicing.training import load_pair_checkpoint
sys.path.insert(0, str(REPO / "scratch"))
from steelman_position import dinuc_shuffle, plant_motifs

N, BATCH = 300, 6
device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"]); mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(REPO / mc["path"], tokenizer_mode=mc["tokenizer_mode"],
    device=device, trust_remote_code=False, local_files_only=True, model_class=mc["model_class"])
readout, _ = load_pair_checkpoint(REPO / "colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt", adapter=adapter)
examples = []
with (REPO / "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl").open() as f:
    for line in f:
        if line.strip():
            examples.append(SplicePairExample.from_json(line))
            if len(examples) >= N: break
rng = random.Random(0)
real = [x.sequence for x in examples]
shuf = [dinuc_shuffle(s, rng) for s in real]
shufm = [plant_motifs(s, x) for s, x in zip(shuf, examples)]

def run(seqs, tag):
    ah = dh = tot = 0; Atrue = []
    for i in range(0, len(examples), BATCH):
        ex = examples[i:i+BATCH]; sq = seqs[i:i+BATCH]
        tok = adapter.tokenize(sq)
        pb = collate_pair_indices(ex, token_offset=tok.prefix_tokens, device=adapter.device)
        with torch.no_grad():
            h = adapter.forward(tok, output_hidden_states=True).hidden_states[rep]
            b = torch.arange(h.shape[0], device=h.device)[:, None]
            A = readout.acceptor(h[b, pb.positions[...,0]]).squeeze(-1).float().cpu()
            D = readout.donor(h[b, pb.positions[...,1]]).squeeze(-1).float().cpu()
        m = pb.mask.cpu()
        for k, x in enumerate(ex):
            ap = np.array([p.acceptor_pos for p in x.pairs]); dp = np.array([p.donor_pos for p in x.pairs])
            Ak = A[k][m[k]].numpy(); Dk = D[k][m[k]].numpy()
            au, du = {}, {}
            for p, v in zip(ap, Ak): au[p] = max(au.get(p, -1e9), v)
            for p, v in zip(dp, Dk): du[p] = max(du.get(p, -1e9), v)
            ta, td = x.pairs[x.true_pair_index].acceptor_pos, x.pairs[x.true_pair_index].donor_pos
            ah += int(max(au, key=au.get) == ta); dh += int(max(du, key=du.get) == td)
            Atrue.append(au[ta]); tot += 1
    print(f"{tag:12s} A picks pos-200 (true acc): {ah/tot:.4f}   D picks true donor: {dh/tot:.4f}   mean f(h@200)={np.mean(Atrue):+.3f}", flush=True)

run(real, "REAL"); run(shuf, "SHUF"); run(shufm, "SHUF+MOTIF")

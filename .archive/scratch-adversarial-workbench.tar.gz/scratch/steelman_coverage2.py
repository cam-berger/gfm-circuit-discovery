import sys, numpy as np
sys.path.insert(0,'src')
from gfmcd.splicing.io import load_jsonl
from gfmcd.splicing.context_controls import retain_site_windows, retain_pair_endpoints_only
ex = load_jsonl('colab_results/splicebert_run/baselines/val_local_conflicts.jsonl')[:2000]
rf=[]; rf_ep=[]; accwin=[]; donwin=[]; bp=[]
for e in ex:
    s = retain_site_windows(e, flank=12, include_all_candidates=True)
    rf.append(sum(1 for c in s if c!='N')/len(s))
    s2 = retain_pair_endpoints_only(e, flank=12)
    rf_ep.append(sum(1 for c in s2 if c!='N')/len(s2))
    a=e.true_pair.acceptor_pos; d=e.true_pair.donor_pos
    w=s[max(0,a-20):a+3]; accwin.append(sum(1 for c in w if c!='N')/max(1,len(w)))
    w=s[max(0,d-3):d+6]; donwin.append(sum(1 for c in w if c!='N')/max(1,len(w)))
    w=s[max(0,a-40):a-12]; bp.append(sum(1 for c in w if c!='N')/max(1,len(w)))
q=lambda x:(np.mean(x), np.percentile(x,5), np.min(x))
print('retain_site_windows(flank=12,all_cands): retained-base fraction  mean=%.4f  p5=%.4f  min=%.4f'%q(rf))
print('retain_pair_endpoints_only(flank=12):    retained-base fraction  mean=%.4f  p5=%.4f  min=%.4f'%q(rf_ep))
print('acceptor MaxEnt window (-20..+3) visible under site-window control: mean=%.4f'%np.mean(accwin))
print('donor MaxEnt window (-3..+6)     visible under site-window control: mean=%.4f'%np.mean(donwin))
print('branchpoint band (-40..-13)      visible under site-window control: mean=%.4f'%np.mean(bp))

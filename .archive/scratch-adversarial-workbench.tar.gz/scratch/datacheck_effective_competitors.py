"""Data-check for finding: 'effective number of competitors ~1.3 => task is really 1.3-way'.

Counter-test: exp(entropy) of a TRAINED softmax is a confidence statistic, not a task-difficulty
statistic. If the RANDOM-backbone control (PMR 0.056) also shows a low effective-competitor count,
the statistic cannot be read as 'the task only has 1.3 real competitors'.
"""
from __future__ import annotations
import json, math, sys
from pathlib import Path
import numpy as np
import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))
from gfmcd.adapters.splicebert import SpliceBertAdapter
from gfmcd.splicing.config import load_config
from gfmcd.splicing.schema import SplicePairExample
from gfmcd.splicing.readout import collate_pair_indices
from gfmcd.splicing.training import load_pair_checkpoint

N, BATCH = 400, 8
device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"]); mc = cfg["model"]

examples = []
with (REPO / "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl").open() as f:
    for line in f:
        if line.strip():
            examples.append(SplicePairExample.from_json(line))
        if len(examples) >= N: break

def summarize(logit_rows, true_idx, label):
    ents, w2, alone, ok, rr = [], [], [], [], []
    for lg, t in zip(logit_rows, true_idx):
        lg = np.asarray(lg, dtype=np.float64); lg = lg[np.isfinite(lg)]
        m = lg.max(); p = np.exp(lg - m); p /= p.sum()
        ents.append(math.exp(-(p * np.log(p + 1e-300)).sum()))
        w = int((lg >= m - 2.0).sum()); w2.append(w); alone.append(w == 1)
        ok.append(bool(lg.argmax() == t))
        rank = int((lg > lg[t]).sum()) + 1; rr.append(1.0 / rank)
    ents = np.array(ents); w2 = np.array(w2)
    print(f"[{label}]  top1={np.mean(ok):.4f}  MRR={np.mean(rr):.4f}")
    print(f"   exp(entropy): median {np.median(ents):.3f}  mean {ents.mean():.3f}  p90 {np.percentile(ents,90):.2f}")
    print(f"   #within-2-logits: median {np.median(w2):.1f} mean {w2.mean():.2f} | frac top ALONE within 2: {np.mean(alone):.4f}")
    return dict(top1=float(np.mean(ok)), mrr=float(np.mean(rr)),
                ent_med=float(np.median(ents)), ent_mean=float(ents.mean()),
                ent_p90=float(np.percentile(ents,90)), w2_med=float(np.median(w2)),
                w2_mean=float(w2.mean()), frac_alone=float(np.mean(alone)))

out = {}
for regime in ["additive-frozen", "additive-random-frozen"]:
    adapter = SpliceBertAdapter.from_pretrained(
        REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
        trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
    ck = REPO / f"colab_results/splicebert_run/runs/{regime}_seed0/checkpoint.pt"
    readout, checkpoint = load_pair_checkpoint(ck, adapter=adapter)
    print(f"\n=== {regime} | randomized_backbone={checkpoint['extra_metadata'].get('randomized_backbone')} "
          f"| backbone_state loaded={checkpoint.get('backbone_state') is not None}")
    rows, tidx = [], []
    for i in range(0, len(examples), BATCH):
        ex = examples[i:i+BATCH]
        tok = adapter.tokenize([x.sequence for x in ex])
        pb = collate_pair_indices(ex, token_offset=tok.prefix_tokens, device=adapter.device)
        with torch.no_grad():
            hs = adapter.forward(tok, output_hidden_states=True, output_attentions=False).hidden_states[rep]
            lg = readout(hs, pb).float().cpu().numpy()
        mask = pb.mask.cpu().numpy()
        for k, x in enumerate(ex):
            rows.append(lg[k][mask[k]]); tidx.append(x.true_pair_index)
    out[regime] = summarize(rows, tidx, regime)
    del adapter, readout
    torch.mps.empty_cache() if device == "mps" else None

# PWM baseline scores on the same examples (a scorer that is 0% accurate on this set by construction)
import pickle
bl = pickle.load(open(REPO / "colab_results/splicebert_run/baselines/local_pair_baseline.pkl", "rb"))
print("\nbaseline pickle type:", type(bl))
json.dump(out, open(REPO / "scratch/datacheck_effective_competitors.json", "w"), indent=1)

#!/usr/bin/env python
"""REFEREE STEELMAN PROBE.

Best defense of the additive design: h_d is CONTEXTUAL. The backbone sees the whole
window, which contains the true acceptor. So g(h_d) could be high precisely because
h_d has integrated "I terminate a viable exon that begins at acceptor a*" (the
exon-definition model of splicing). Under that reading the additive constraint is the
POINT: it forces all pairing information to live inside the single-site representations,
which is exactly what the novelty sentence claims.

That defense makes a hard, falsifiable prediction that the true_pair_margin CANNOT test
(because the acceptor term cancels), but the RAW TERMS can:

    If g(h_d*) is partner-conditioned, then destroying the true acceptor's motif must
    DEGRADE g(h_d*) -- specifically, far more than destroying an equally-sized irrelevant
    window elsewhere.

We measure the raw readout terms f(h_a*) and g(h_d*) under:
    clean | acceptor-masked (+-12 N) | donor-masked (+-12 N) | random-window-masked (+-12 N)

Internal control (does the instrument work at all?):
    acceptor-mask MUST tank f(h_a*); donor-mask MUST tank g(h_d*). If it doesn't, the
    readout isn't reading the motif at all.

Steelman survives iff:  dg_acc := g(h_d*)_clean - g(h_d*)_acc-masked  is LARGE vs dg_rand
                        and vs the margin scale (~2.2-2.5 logits).
"""
from __future__ import annotations

import json
from pathlib import Path
import random
import sys

import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))

from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.schema import SplicePairExample  # noqa: E402
from gfmcd.splicing.readout import collate_pair_indices  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint  # noqa: E402
from gfmcd.splicing.context_controls import mask_true_partner_neighborhood  # noqa: E402

N = 192
BATCH = 8
FLANK = 12
SEEDS = [0, 1]

device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"])
mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))

conf_path = REPO / "results/splicebert_partner_selection/circuits/discovery/confirmation.jsonl"
examples: list[SplicePairExample] = []
with conf_path.open() as f:
    for line in f:
        if line.strip():
            examples.append(SplicePairExample.from_json(line))
        if len(examples) >= N:
            break
print(f"loaded {len(examples)} confirmation examples")


def random_mask(example: SplicePairExample, rng: random.Random) -> str:
    """Mask a +-FLANK window at a random position far from BOTH true sites."""
    a, d = example.true_pair.acceptor_pos, example.true_pair.donor_pos
    L = len(example.sequence)
    for _ in range(200):
        p = rng.randrange(FLANK, L - FLANK)
        if abs(p - a) > 3 * FLANK and abs(p - d) > 3 * FLANK:
            break
    s, e = p - FLANK, p + FLANK
    return example.sequence[:s] + "N" * (e - s) + example.sequence[e:]


def terms(readout, hidden, pb):
    """Raw per-pair A / D / Lterm from the additive readout."""
    from gfmcd.splicing.readout import _gather_sites
    acc, don = _gather_sites(hidden, pb.positions)
    A = readout.acceptor(acc).squeeze(-1)
    D = readout.donor(don).squeeze(-1)
    Lt = readout.length(readout._length_features(pb.lengths)).squeeze(-1)
    return A, D, Lt


results = {}
for seed in SEEDS:
    ckpt = REPO / f"colab_results/splicebert_run/runs/additive-frozen_seed{seed}/checkpoint.pt"
    readout, checkpoint = load_pair_checkpoint(ckpt, adapter=adapter)
    assert checkpoint.get("backbone_state") is None, "backbone must be frozen/pretrained"
    readout.eval()
    rng = random.Random(1234 + seed)

    rec = {k: [] for k in ("fa_clean", "gd_clean", "fa_am", "gd_am", "fa_dm", "gd_dm",
                           "fa_rm", "gd_rm", "margin", "share_a", "share_d",
                           "gd_best_decoy_clean", "gd_best_decoy_am")}

    for i in range(0, len(examples), BATCH):
        ex = examples[i:i + BATCH]
        variants = {
            "clean": [x.sequence for x in ex],
            "am": [mask_true_partner_neighborhood(x, kind="acceptor", flank=FLANK) for x in ex],
            "dm": [mask_true_partner_neighborhood(x, kind="donor", flank=FLANK) for x in ex],
            "rm": [random_mask(x, rng) for x in ex],
        }
        out_terms = {}
        for name, seqs in variants.items():
            tok = adapter.tokenize(seqs)
            pb = collate_pair_indices(ex, token_offset=tok.prefix_tokens, device=adapter.device)
            with torch.no_grad():
                out = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
                A, D, Lt = terms(readout, out.hidden_states[rep], pb)
            out_terms[name] = (A.float().cpu(), D.float().cpu(), Lt.float().cpu(), pb)

        for b, x in enumerate(ex):
            ti = x.true_pair_index
            ta, td = x.true_pair.acceptor_pos, x.true_pair.donor_pos
            A, D, Lt, pb = out_terms["clean"]
            npairs = len(x.pairs)
            logits = (A[b, :npairs] + D[b, :npairs] + Lt[b, :npairs]).clone()
            logits[ti] = float("-inf")
            j = int(logits.argmax())
            rec["margin"].append(float((A[b, ti] + D[b, ti] + Lt[b, ti])
                                       - (A[b, j] + D[b, j] + Lt[b, j])))
            rec["share_a"].append(int(x.pairs[j].acceptor_pos == ta))
            rec["share_d"].append(int(x.pairs[j].donor_pos == td))
            rec["gd_best_decoy_clean"].append(float(D[b, j]))

            Aam, Dam, _, _ = out_terms["am"]
            rec["gd_best_decoy_am"].append(float(Dam[b, j]))
            for tag, key in (("clean", ""), ("am", "_am"), ("dm", "_dm"), ("rm", "_rm")):
                At, Dt, _, _ = out_terms[tag]
                rec[f"fa{key or '_clean'}"].append(float(At[b, ti]))
                rec[f"gd{key or '_clean'}"].append(float(Dt[b, ti]))

    m = lambda k: sum(rec[k]) / len(rec[k])  # noqa: E731
    r = {
        "n": len(rec["margin"]),
        "mean_margin": m("margin"),
        "top_decoy_shares_true_acceptor": m("share_a"),
        "top_decoy_shares_true_donor": m("share_d"),
        "f_a_clean": m("fa_clean"), "g_d_clean": m("gd_clean"),
        # instrument checks: does masking a site destroy THAT site's own score?
        "delta_f_a_ACCEPTOR_mask": m("fa_clean") - m("fa_am"),
        "delta_g_d_DONOR_mask": m("gd_clean") - m("gd_dm"),
        # THE STEELMAN TEST: does masking the acceptor degrade the DONOR's score?
        "delta_g_d_ACCEPTOR_mask": m("gd_clean") - m("gd_am"),
        "delta_f_a_DONOR_mask": m("fa_clean") - m("fa_dm"),
        # control: equally sized mask at an irrelevant location
        "delta_g_d_RANDOM_mask": m("gd_clean") - m("gd_rm"),
        "delta_f_a_RANDOM_mask": m("fa_clean") - m("fa_rm"),
        # does acceptor-masking hurt the true donor MORE than the competing decoy donor?
        "delta_g_bestdecoy_ACCEPTOR_mask": m("gd_best_decoy_clean") - m("gd_best_decoy_am"),
    }
    results[f"seed{seed}"] = r
    print(f"\n=== additive-frozen seed{seed} (n={r['n']}) ===")
    for k, v in r.items():
        if k != "n":
            print(f"  {k:38s} {v:+.4f}")

(REPO / "scratch/ref_steelman_partner_conditioning.json").write_text(json.dumps(results, indent=2))
print("\nwrote scratch/ref_steelman_partner_conditioning.json")

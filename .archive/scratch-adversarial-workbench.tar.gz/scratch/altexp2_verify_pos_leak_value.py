#!/usr/bin/env python
"""Independent re-derivation of the finding's headline number.

Finding claims: a scorer using ONLY 1[acceptor_pos == 200] for the acceptor,
plus the REGISTERED donor PWM and the REGISTERED length prior, gets conflict
PMR = 0.4947, versus the registered baseline's 0.0000 (true by construction).

I re-implement from scratch and report several weightings of the indicator,
because (as a previous lane found with the oracle test) a +1 indicator in
log-odds units is arbitrary and can be swamped by the PWM spread.

Also re-derives: (a) the registered baseline PMR on the conflict set (must be
0.0 by construction), (b) the best-decoy composition, (c) the value of the
DONOR positional leak (donor is always at len-200) as a symmetric check.
"""
from __future__ import annotations

import json
import pickle
from pathlib import Path
import sys

import numpy as np

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))

from gfmcd.splicing.baselines import site_window  # noqa: E402
from gfmcd.splicing.schema import SplicePairExample  # noqa: E402

N = int(sys.argv[1]) if len(sys.argv) > 1 else 10_000_000

bl = pickle.loads((REPO / "colab_results/splicebert_run/baselines/local_pair_baseline.pkl").read_bytes())
print("baseline:", type(bl).__name__, "| length_weight =", bl.length_weight)

path = REPO / "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl"

WEIGHTS = [1.0, 2.0, 4.0, 8.0, 1e6]  # 1e6 == hard restriction to acceptor_pos==200
agg = {w: 0 for w in WEIGHTS}
agg_top1 = {w: 0 for w in WEIGHTS}
base_pmr = 0
n = 0
acc_at_200 = 0
don_at_end200 = 0
comp = {"decoy_shares_true_acc_only": 0, "decoy_shares_true_don_only": 0, "decoy_shares_neither": 0}
# symmetric check: donor positional indicator instead
don_leak = {w: 0 for w in WEIGHTS}
# both leaks
both_leak = 0

with path.open() as f:
    for line in f:
        if not line.strip():
            continue
        x = SplicePairExample.from_json(line)
        n += 1
        if n > N:
            n -= 1
            break
        seq = x.sequence
        tp = x.true_pair
        acc_at_200 += int(tp.acceptor_pos == 200)
        don_at_end200 += int(tp.donor_pos == len(seq) - 200)

        # per-site cached PWM scores
        acc_cache: dict[int, float] = {}
        don_cache: dict[int, float] = {}
        apos = np.array([p.acceptor_pos for p in x.pairs])
        dpos = np.array([p.donor_pos for p in x.pairs])
        elen = np.array([p.exon_length for p in x.pairs])
        for p in set(apos.tolist()):
            acc_cache[p] = bl.acceptor_pwm.score(site_window(seq, p, "acceptor"))
        for p in set(dpos.tolist()):
            don_cache[p] = bl.donor_pwm.score(site_window(seq, p, "donor"))
        A = np.array([acc_cache[p] for p in apos])
        D = np.array([don_cache[p] for p in dpos])
        L = bl.length_weight * np.array([bl.length_prior.score(int(l)) for l in elen])

        t = x.true_pair_index
        # (a) registered baseline (sanity: must be 0 PMR on the conflict set)
        s = A + D + L
        dec = s.copy(); dec[t] = -np.inf
        base_pmr += int(s[t] > dec.max())
        best_dec = int(np.argmax(dec))
        sa = apos[best_dec] == tp.acceptor_pos
        sd = dpos[best_dec] == tp.donor_pos
        if sa and not sd:
            comp["decoy_shares_true_acc_only"] += 1
        elif sd and not sa:
            comp["decoy_shares_true_don_only"] += 1
        else:
            comp["decoy_shares_neither"] += 1

        indA = (apos == 200).astype(float)          # the leak the model has, the PWM cannot
        indD = (dpos == len(seq) - 200).astype(float)
        for w in WEIGHTS:
            # acceptor PWM REPLACED by positional indicator; donor PWM + length kept
            s2 = w * indA + D + L
            d2 = s2.copy(); d2[t] = -np.inf
            agg[w] += int(s2[t] > d2.max())
            agg_top1[w] += int(int(np.argmax(s2)) == t)
            # symmetric: donor PWM REPLACED by positional indicator; acceptor PWM + length kept
            s3 = A + w * indD + L
            d3 = s3.copy(); d3[t] = -np.inf
            don_leak[w] += int(s3[t] > d3.max())
        # both leaks, no sequence at all (+ length prior)
        s4 = 1e6 * indA + 1e6 * indD + L
        d4 = s4.copy(); d4[t] = -np.inf
        both_leak += int(s4[t] > d4.max())

print(f"\nn conflict examples = {n}")
print(f"true acceptor at index 200:        {acc_at_200}/{n} = {acc_at_200/n:.4f}")
print(f"true donor at index len-200:       {don_at_end200}/{n} = {don_at_end200/n:.4f}")
print(f"\nregistered PWM+length baseline PMR (sanity, must be 0.0): {base_pmr/n:.4f}")
print("\nbest-decoy composition (registered baseline):")
for k, v in comp.items():
    print(f"  {k}: {v} ({v/n:.4f})")
print("\n[ACCEPTOR LEAK] score = w*1[acc==200] + donor_PWM + length_prior")
for w in WEIGHTS:
    tag = " (hard restrict)" if w >= 1e6 else ""
    print(f"  w={w:<8g} PMR = {agg[w]/n:.4f}   top1 = {agg_top1[w]/n:.4f}{tag}")
print("\n[DONOR LEAK, symmetric] score = acceptor_PWM + w*1[don==len-200] + length_prior")
for w in WEIGHTS:
    print(f"  w={w:<8g} PMR = {don_leak[w]/n:.4f}")
print(f"\n[BOTH LEAKS, ZERO SEQUENCE] PMR = {both_leak/n:.4f}")

out = dict(n=n, acc_at_200=acc_at_200 / n, don_at_end200=don_at_end200 / n,
           registered_baseline_pmr=base_pmr / n,
           decoy_composition={k: v / n for k, v in comp.items()},
           acceptor_leak_pmr={str(w): agg[w] / n for w in WEIGHTS},
           acceptor_leak_top1={str(w): agg_top1[w] / n for w in WEIGHTS},
           donor_leak_pmr={str(w): don_leak[w] / n for w in WEIGHTS},
           both_leaks_zero_sequence_pmr=both_leak / n)
(REPO / "scratch/altexp2_verify_pos_leak_value.json").write_text(json.dumps(out, indent=2))
print("\nwrote scratch/altexp2_verify_pos_leak_value.json")

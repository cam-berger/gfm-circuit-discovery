"""Does the registered baseline's mis-specification INFLATE the headline 0.807?

Split the frozen conflict set (n=10,034) into:
  RETAINED : still a conflict for a properly-specified local model (DISC_PWM_W)
  DROPPED  : NOT a conflict for that model -- i.e. the local cue actually points the
             RIGHT way; only the registered baseline's mis-specification put it here.
Measure additive-frozen seed0 PMR on each.
"""
from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np
import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))

from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.schema import SplicePairExample  # noqa: E402
from gfmcd.splicing.readout import collate_pair_indices  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint  # noqa: E402

NPER = 350
BATCH = 8
rng = np.random.default_rng(0)

z = np.load(REPO / "scratch/audit_baseline_conflicts.npz", allow_pickle=True)
ids = z["ids"]
flag = {k: dict(zip(ids, z[k])) for k in ("FROZEN", "DISC_PWM_W", "UNIFORM_BG")}

conf_path = REPO / "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl"
retained, dropped = [], []
with conf_path.open() as f:
    for line in f:
        if not line.strip():
            continue
        d = json.loads(line)
        eid = d["example_id"]
        assert flag["FROZEN"][eid], "conflict jsonl disagrees with reimplementation"
        (retained if flag["DISC_PWM_W"][eid] else dropped).append(line)
print(f"frozen conflicts: retained under DISC_PWM_W = {len(retained)}, dropped = {len(dropped)}")

sel = {
    "retained": [SplicePairExample.from_json(retained[i]) for i in rng.choice(len(retained), NPER, replace=False)],
    "dropped": [SplicePairExample.from_json(dropped[i]) for i in rng.choice(len(dropped), NPER, replace=False)],
}

device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))

out = {}
for seed in (0, 1, 2):
    ck = REPO / f"colab_results/splicebert_run/runs/additive-frozen_seed{seed}/checkpoint.pt"
    if not ck.exists():
        continue
    readout, checkpoint = load_pair_checkpoint(ck, adapter=adapter)
    assert checkpoint.get("backbone_state") is None
    for name, exs in sel.items():
        wins = 0
        for i in range(0, len(exs), BATCH):
            ex = exs[i:i + BATCH]
            tok = adapter.tokenize([x.sequence for x in ex])
            pb = collate_pair_indices(ex, token_offset=tok.prefix_tokens, device=adapter.device)
            with torch.no_grad():
                o = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
                h = o.hidden_states[int(cfg["readout"]["representation_layer"])]
                logits = readout(h, pb)
                masked = logits.masked_fill(~pb.mask, torch.finfo(logits.dtype).min)
                b = torch.arange(len(masked), device=masked.device)
                true = masked[b, pb.labels]
                tmp = masked.clone()
                tmp[b, pb.labels] = torch.finfo(logits.dtype).min
                wins += int((true > tmp.max(-1).values).sum())
        out[f"seed{seed}_{name}"] = wins / len(exs)
        print(f"seed{seed} {name:9s} PMR = {wins/len(exs):.3f}  (n={len(exs)})", flush=True)

print(json.dumps(out, indent=2))

#!/usr/bin/env python
"""REFEREE CHECK: is the PWM+length baseline a strawman whose weakness invalidates C1?

Axes of the finding:
  (1) generative positives-only fit   -> vs discriminative conditional-logit reweighting
  (2) background from positive windows-> vs background from ALL candidate windows
  (3) length_weight hard-coded to 1.0 -> sweep
  (4) window widths (20/3, 3/6)       -> vs wide (40/10, 10/12)
Then: how far does the CONFLICT SET move?
Streaming implementation (data is 8.6 GB train / 844 MB val).
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
DATA = REPO / "data/processed/splicebert_partner_selection/v1"
NTRAIN = 30000
NDISC = 4000
CODE = {"A": 0, "C": 1, "G": 2, "T": 3}
WIN = {"reg": (20, 3, 3, 6), "wide": (40, 10, 10, 12)}


def stream(path, n=None):
    with open(path) as f:
        for i, line in enumerate(f):
            if not line.strip():
                continue
            if n is not None and i >= n:
                return
            yield json.loads(line)


def encode(seq):
    arr = np.frombuffer(seq.encode(), dtype=np.uint8)
    a = np.full(len(seq), -1, dtype=np.int64)
    for b, i in CODE.items():
        a[arr == ord(b)] = i
    return a


def win_idx(pos, up, down, n):
    off = np.arange(-up, down)
    idx = pos[:, None] + off[None, :]
    ok = (idx[:, 0] >= 0) & (idx[:, -1] < n)
    return np.clip(idx, 0, n - 1), ok


class PWM:
    def __init__(self, up, down):
        self.up, self.down, self.L = up, down, up + down
        self.counts = np.full((self.L, 4), 0.5)
        self.posbg = np.full(4, 0.5)
        self.candbg = np.full(4, 0.5)

    def add_pos(self, code, p):
        idx, ok = win_idx(np.array([p]), self.up, self.down, len(code))
        if not ok[0]:
            return
        w = code[idx[0]]
        m = w >= 0
        np.add.at(self.counts, (np.nonzero(m)[0], w[m]), 1.0)
        np.add.at(self.posbg, w[m], 1.0)

    def add_cand(self, code, positions):
        idx, ok = win_idx(positions, self.up, self.down, len(code))
        w = code[idx[ok]]
        np.add.at(self.candbg, w[w >= 0].ravel(), 1.0)

    def finalize(self, bg):
        probs = self.counts / self.counts.sum(1, keepdims=True)
        background = (self.posbg if bg == "pos" else self.candbg)
        background = background / background.sum()
        lo = np.log(probs) - np.log(background)[None, :]
        return lo, (background[None, :] * lo).sum(1)


def score_sites(code, positions, lo, exp_unknown, up, down):
    idx, ok = win_idx(positions, up, down, len(code))
    w = code[idx]
    L = lo.shape[0]
    s = np.where(w >= 0, lo[np.arange(L)[None, :], np.clip(w, 0, 3)], exp_unknown[None, :]).sum(1)
    s[~ok] = -np.inf
    return s


def main():
    # ---------- pass 1: fit PWMs + length prior on train ----------
    pwms = {k: {"a": PWM(v[0], v[1]), "d": PWM(v[2], v[3])} for k, v in WIN.items()}
    lengths = []
    for n, ex in enumerate(stream(DATA / "train.jsonl", NTRAIN)):
        code = encode(ex["sequence"])
        tp = ex["pairs"][ex["true_pair_index"]]
        ap = np.array([a["position"] for a in ex["acceptors"]])
        dp = np.array([d["position"] for d in ex["donors"]])
        lengths.append(tp["donor_pos"] - tp["acceptor_pos"])
        for k in WIN:
            pwms[k]["a"].add_pos(code, tp["acceptor_pos"])
            pwms[k]["d"].add_pos(code, tp["donor_pos"])
            pwms[k]["a"].add_cand(code, ap)
            pwms[k]["d"].add_cand(code, dp)
        if (n + 1) % 10000 == 0:
            print(f"  train {n+1}", flush=True)
    print(f"fit on {len(lengths)} train examples", flush=True)

    lo_, hi_ = min(lengths), max(lengths)
    c = np.full(hi_ - lo_ + 1, 1.0)
    for L in lengths:
        c[L - lo_] += 1
    LOGP = np.log(c / c.sum())

    def len_score(lens):
        s = np.full(len(lens), -np.inf)
        m = (lens >= lo_) & (lens <= hi_)
        s[m] = LOGP[lens[m] - lo_]
        return s

    MODELS = {}   # name -> (winkey, lo_a, eu_a, lo_d, eu_d)
    for wk in WIN:
        for bg in ("pos", "cand"):
            la, ea = pwms[wk]["a"].finalize(bg)
            ld, ed = pwms[wk]["d"].finalize(bg)
            MODELS[f"{wk}|bg={bg}"] = (wk, la, ea, ld, ed)

    def feats(ex, name):
        wk, la, ea, ld, ed = MODELS[name]
        au, ad, du, dd = WIN[wk]
        code = encode(ex["sequence"])
        sa = score_sites(code, np.array([a["position"] for a in ex["acceptors"]]), la, ea, au, ad)
        sd = score_sites(code, np.array([d["position"] for d in ex["donors"]]), ld, ed, du, dd)
        ai = np.array([p["acceptor_index"] for p in ex["pairs"]])
        di = np.array([p["donor_index"] for p in ex["pairs"]])
        lens = np.array([p["donor_pos"] - p["acceptor_pos"] for p in ex["pairs"]])
        return np.stack([sa[ai], sd[di], len_score(lens)], 1)

    # ---------- pass 2: discriminative reweighting on train subsample ----------
    DISC = {}
    for name in ("reg|bg=pos", "wide|bg=cand"):
        F, T = [], []
        for ex in stream(DATA / "train.jsonl", NDISC):
            F.append(feats(ex, name).astype(np.float32))
            T.append(ex["true_pair_index"])
        w = np.array([1.0, 1.0, 1.0])
        for it in range(400):
            g = np.zeros(3)
            nll = 0.0
            for Fi, ti in zip(F, T):
                s = Fi @ w
                fin = np.isfinite(s)
                if not fin[ti]:
                    continue
                s = np.where(fin, s, -1e9)
                s -= s.max()
                p = np.exp(s)
                p /= p.sum()
                nll -= np.log(max(p[ti], 1e-12))
                g += (p[:, None] * np.where(fin[:, None], Fi, 0.0)).sum(0) - Fi[ti]
            g /= len(F)
            w -= 0.05 * g
            if it % 200 == 0:
                print(f"  disc[{name}] it={it} nll={nll/len(F):.4f} w={w.round(3)}", flush=True)
        DISC[name] = w
        print(f"DISCRIMINATIVE weights for {name}: {w.round(4)}", flush=True)

    # ---------- pass 3: evaluate on val ----------
    SCORERS = []  # (label, model_name, weight vector)
    for lw in (0.0, 0.5, 1.0, 2.0, 3.0):
        SCORERS.append((f"REGISTERED reg|bg=pos lw={lw}", "reg|bg=pos", np.array([1.0, 1.0, lw])))
    SCORERS.append(("wide|bg=pos lw=1", "wide|bg=pos", np.array([1.0, 1.0, 1.0])))
    SCORERS.append(("reg|bg=cand lw=1", "reg|bg=cand", np.array([1.0, 1.0, 1.0])))
    SCORERS.append(("wide|bg=cand lw=1", "wide|bg=cand", np.array([1.0, 1.0, 1.0])))
    SCORERS.append(("DISC reg|bg=pos", "reg|bg=pos", DISC["reg|bg=pos"]))
    SCORERS.append(("DISC wide|bg=cand (strongest)", "wide|bg=cand", DISC["wide|bg=cand"]))

    corr = {lab: [] for lab, _, _ in SCORERS}
    ids = []
    for n, ex in enumerate(stream(DATA / "val.jsonl")):
        ids.append(ex["example_id"])
        cache = {}
        t = ex["true_pair_index"]
        for lab, mname, w in SCORERS:
            if mname not in cache:
                cache[mname] = feats(ex, mname)
            s = cache[mname] @ w
            s = np.where(np.isfinite(s), s, -1e18)
            corr[lab].append(int(np.argmax(s)) == t)
        if (n + 1) % 5000 == 0:
            print(f"  val {n+1}", flush=True)
    N = len(ids)
    corr = {k: np.array(v) for k, v in corr.items()}

    print(f"\n=== val top-1 accuracy (n={N}) ===")
    for lab, _, _ in SCORERS:
        c_ = corr[lab]
        print(f"  {lab:34s} top1={c_.mean():.4f}   conflicts={int((~c_).sum())}")

    reg = corr["REGISTERED reg|bg=pos lw=1.0"]
    C0 = ~reg
    print(f"\n=== conflict-set movement (registered conflicts n={C0.sum()}) ===")
    for lab, _, _ in SCORERS:
        C = ~corr[lab]
        keep = int((C0 & C).sum())
        print(f"  {lab:34s} n={int(C.sum()):6d} keeps {keep:6d}/{int(C0.sum())} "
              f"({keep/C0.sum():.3f})  new={int((C & ~C0).sum()):5d}")

    np.savez(REPO / "scratch/ref_baseline_corr.npz",
             ids=np.array(ids), **{lab: corr[lab] for lab, _, _ in SCORERS})
    print("\nsaved scratch/ref_baseline_corr.npz")


if __name__ == "__main__":
    main()

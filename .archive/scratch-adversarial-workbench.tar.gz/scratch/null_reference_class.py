"""Test the finding: is the matched-random head null mis-specified?

Reproduces run_tracing.py's selection of C on D (seed0), then re-runs the Step-3
necessity null on Vc under THREE null universes:
  (1) full 96-head uniform      <- what the paper does
  (2) layers 2-4 only           <- finding's predicted signature (a)
  (3) magnitude-matched         <- finding's predicted signature (b)
Also scans single-head mean-ablation effect on Vc for all 96 heads.
"""
from __future__ import annotations
import json, random, statistics as st, sys, time
from pathlib import Path
import torch

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "src"))
sys.path.insert(0, str(REPO / "scripts" / "splicebert"))

from gfmcd.adapters.splicebert import SpliceBertAdapter
from gfmcd.circuits.hf_bert import capture_head_outputs, edit_heads, patch_heads
from gfmcd.splicing.config import load_config
from gfmcd.splicing.context_controls import mask_true_partner_neighborhood
from gfmcd.splicing.io import load_jsonl
from gfmcd.splicing.metrics import matched_random_pvalue
from gfmcd.splicing.training import load_pair_checkpoint, set_seed
from run_tracing import Chunk, Scorer, build_chunks, add_clean_cache, single_head_recovery

N_D = int(sys.argv[1]) if len(sys.argv) > 1 else 128
N_VC = int(sys.argv[2]) if len(sys.argv) > 2 else 128
N_DRAWS = int(sys.argv[3]) if len(sys.argv) > 3 else 200
BATCH, FLANK, SHORTLIST, SET_SIZE, SEED = 16, 12, 16, 5, 0

set_seed(SEED)
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"])
mc = cfg["model"]
ckpt = REPO / "colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt"
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=None,
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
readout, checkpoint = load_pair_checkpoint(ckpt, adapter=adapter)
assert checkpoint.get("extra_metadata", {}).get("regime") == "additive-frozen"
assert checkpoint.get("backbone_state") is None, "backbone must be frozen pretrained"
S = Scorer(adapter, readout, rep)
print(f"device={adapter.device} layers={adapter.num_layers} heads={adapter.num_heads}", flush=True)

sd = REPO / "results/splicebert_partner_selection/circuits/discovery"
D = load_jsonl(sd / "discovery.jsonl")[:N_D]
Vc = load_jsonl(sd / "confirmation.jsonl")[:N_VC]
print(f"n_D={len(D)} n_Vc={len(Vc)}", flush=True)

chunks = lambda exs, corrupt=None: [c for _e, c in build_chunks(adapter, exs, BATCH, corrupt=corrupt)]
masks = {m: (lambda exs, m=m: [mask_true_partner_neighborhood(x, kind=m.split("-")[0], flank=FLANK) for x in exs])
         for m in ("acceptor-mask", "donor-mask")}

t0 = time.time()
D_clean = chunks(D); add_clean_cache(S, D_clean)
Vc_clean = chunks(Vc); add_clean_cache(S, Vc_clean)
all_heads = [(l, h) for l in range(adapter.num_layers) for h in range(adapter.num_heads)]

# ---- Step 0: AtP shortlist on D (exactly as run_tracing) ----
zeros = [Chunk(tok=c.tok, pair_batch=c.pair_batch, n=c.n,
               clean_cache={l: torch.zeros_like(c.clean_cache[l]) for l in c.clean_cache}) for c in D_clean]
nec_attr = {k: -v for k, v in S.attribution(zeros, D_clean).items()}
nec_short = [k for k, _ in sorted(nec_attr.items(), key=lambda kv: kv[1], reverse=True)[:SHORTLIST]]
med_short = {}
D_cor = {}
for m in ("acceptor-mask", "donor-mask"):
    D_cor[m] = chunks(D, corrupt=masks[m])
    attr = S.attribution(D_clean, D_cor[m])
    med_short[m] = [k for k, _ in sorted(attr.items(), key=lambda kv: kv[1], reverse=True)[:SHORTLIST]]
shortlist = sorted(set(nec_short) | set(med_short["acceptor-mask"]) | set(med_short["donor-mask"]))
print(f"shortlist ({len(shortlist)}): {shortlist}  [{time.time()-t0:.0f}s]", flush=True)

# ---- Steps 1-2: necessity N on D ----
base_D = S.mean(D_clean)
nec_effects = {h: [base_D - S.mean(D_clean, ablate=([h], mode)) for mode in ("zero", "mean", "resample")]
               for h in shortlist}
N = {h: e for h, e in nec_effects.items() if sum(x > 0 for x in e) >= 2 and st.median(e) > 0}

# ---- Step 2b: mediation M on D ----
recovery_D = {m: {} for m in masks}
for m in masks:
    clean_s, corr_s = base_D, S.mean(D_cor[m])
    gap = clean_s - corr_s
    for h in shortlist:
        recovery_D[m][h] = single_head_recovery(S, D_clean, D_cor[m], h, clean_s, corr_s, gap)
M = [h for h in shortlist if recovery_D["acceptor-mask"].get(h, -1) > 0 and recovery_D["donor-mask"].get(h, -1) > 0]
conv = [h for h in M if h in N]
conv.sort(key=lambda h: (st.median(N[h]) + 0.5 * (recovery_D["acceptor-mask"][h] + recovery_D["donor-mask"][h])), reverse=True)
C = conv[:SET_SIZE]
print(f"N={sorted(N)}\nM={M}\nC={C}  [{time.time()-t0:.0f}s]", flush=True)
assert C, "no convergent set"

# ---- Step 3: observed effect of C on Vc ----
base_Vc = S.mean(Vc_clean)
obs = base_Vc - S.mean(Vc_clean, ablate=(C, "mean"))
print(f"base_Vc={base_Vc:.4f} observed C effect={obs:.4f}", flush=True)

# ---- Single-head mean-ablation effect on Vc for ALL 96 heads (layer dependence) ----
head_eff_Vc = {}
for i, h in enumerate(all_heads):
    head_eff_Vc[h] = base_Vc - S.mean(Vc_clean, ablate=([h], "mean"))
print(f"96-head Vc scan done [{time.time()-t0:.0f}s]", flush=True)

# single-head effect on D (the SELECTION side) for magnitude matching
head_eff_D = {}
for h in all_heads:
    head_eff_D[h] = base_D - S.mean(D_clean, ablate=([h], "mean"))
print(f"96-head D scan done [{time.time()-t0:.0f}s]", flush=True)

k = len(C)
def run_null(universe, name, seed=0):
    rng = random.Random(seed)
    pool = [h for h in universe if h not in C]
    sets = [tuple(sorted(rng.sample(pool, k))) for _ in range(N_DRAWS)]
    eff = [base_Vc - S.mean(Vc_clean, ablate=(list(s), "mean")) for s in sets]
    p = matched_random_pvalue(obs, eff)
    print(f"  {name:24s} |pool|={len(pool):3d} mean={st.mean(eff):+.4f} "
          f"max={max(eff):+.4f} p={p:.4f}", flush=True)
    return {"pool_size": len(pool), "mean": st.mean(eff), "sd": st.pstdev(eff),
            "max": max(eff), "p_add_one": p, "effects": eff}

res = {}
print("\nNULL UNIVERSES (observed = %.4f):" % obs, flush=True)
# (1) the paper's null
res["full_96"] = run_null(all_heads, "full 96 (paper)")
# (2) finding's signature (a): layer-restricted
res["layers_2_4"] = run_null([h for h in all_heads if h[0] in (2, 3, 4)], "layers 2-4 only")
# (2b) restrict to the layers C actually occupies
C_layers = sorted({h[0] for h in C})
res[f"C_layers_{C_layers}"] = run_null([h for h in all_heads if h[0] in C_layers], f"C's layers {C_layers}")
# (3) finding's signature (b): magnitude-matched on single-head D effect
#     pool = heads whose single-head D effect is >= min single-head D effect of C
cmin = min(head_eff_D[h] for h in C)
magpool = [h for h in all_heads if head_eff_D[h] >= cmin]
res["magnitude_matched_D"] = run_null(magpool, "magnitude-matched (D)") if len(magpool) > k else None
# (3b) matched on the AtP shortlist itself (the search's own candidate pool)
res["shortlist_pool"] = run_null(shortlist, "AtP shortlist pool") if len(shortlist) > k else None

out = {
    "n_D": len(D), "n_Vc": len(Vc), "n_draws": N_DRAWS,
    "C": [list(h) for h in C], "observed_effect_Vc": obs, "base_Vc": base_Vc,
    "C_single_head_eff_D": {f"{l}-{h}": head_eff_D[(l, h)] for l, h in C},
    "C_single_head_eff_Vc": {f"{l}-{h}": head_eff_Vc[(l, h)] for l, h in C},
    "head_eff_Vc": {f"{l}-{h}": v for (l, h), v in head_eff_Vc.items()},
    "head_eff_D": {f"{l}-{h}": v for (l, h), v in head_eff_D.items()},
    "nulls": {k2: ({kk: vv for kk, vv in v.items() if kk != "effects"} if v else None) for k2, v in res.items()},
}
by_layer = {l: [head_eff_Vc[(l, h)] for h in range(adapter.num_heads)] for l in range(adapter.num_layers)}
out["layer_mean_single_head_eff_Vc"] = {l: st.mean(v) for l, v in by_layer.items()}
print("\nLAYER PROFILE of single-head mean-ablation effect on Vc:", flush=True)
for l, v in by_layer.items():
    print(f"  L{l}: mean={st.mean(v):+.4f} max={max(v):+.4f} min={min(v):+.4f}", flush=True)
top = sorted(head_eff_Vc.items(), key=lambda kv: kv[1], reverse=True)[:12]
print("\nTOP-12 single heads by Vc mean-ablation effect:", flush=True)
for (l, h), v in top:
    print(f"  {l}-{h}: {v:+.4f}{'   <-- in C' if (l,h) in C else ''}", flush=True)
out["top12_Vc"] = [{"head": [l, h], "eff": v, "in_C": (l, h) in C} for (l, h), v in top]

(REPO / "scratch" / "null_reference_class_results.json").write_text(json.dumps(out, indent=1))
print(f"\nDONE [{time.time()-t0:.0f}s]", flush=True)

"""ADVERSARIAL VERIFICATION of the claim: "the L3H1-head-output rescue returns ~1.0 for
ANY upstream head Z, so it cannot fail."

Scan EVERY upstream head (layers 0-2, 48 heads) with the estimator used at
run_l2_accounting.py:149.  If the estimator is pinned at ~1.0 the claim stands.  If it
returns values clearly below 1 (CI excluding 1) for upstream heads with a usable
denominator, the estimator discriminates and the "cannot fail" claim is false.
"""
import sys
from contextlib import ExitStack
from pathlib import Path

import numpy as np
import torch

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "src"))

from gfmcd.splicing.circuit import (  # noqa: E402
    ADDRESSER, DEFAULT_FASTA, DEFAULT_GTF, DEFAULT_MODEL, READER, CouplingTask, ablate,
    capture_head_outputs, gboot_ratio, load_adapter, load_examples, patch_heads,
    pick_device, ratio_of_means,
)

N, BATCH = 90, 6
dev = pick_device(None)
ad = load_adapter(DEFAULT_MODEL, dev)
task = CouplingTask(ad, batch=BATCH)
X, _ = load_examples(DEFAULT_GTF, DEFAULT_FASTA, "val", N, task=task, tag="l2acct-val",
                     min_effect=0.3)
genes = [x.gene_id for x in X]
print(f"{len(X)} val exons, device={dev}")

ZS = [(l, h) for l in range(3) for h in range(ad.num_heads)]   # all 48 upstream heads
num = {z: [] for z in ZS}
dnm = {z: [] for z in ZS}

with torch.no_grad():
    for i in range(0, len(X), BATCH):
        cl, co, dn = task.pair(X[i:i + BATCH])
        h_cl = capture_head_outputs(ad, lambda: ad.model(**cl))
        h_co = capture_head_outputs(ad, lambda: ad.model(**co))
        cbase = (task.margin(ad.model(**cl).logits.float(), dn)
                 - task.margin(ad.model(**co).logits.float(), dn))
        for z in ZS:
            ABL = ablate(ad, [z])
            with ABL():
                cabl = (task.margin(ad.model(**cl).logits.float(), dn)
                        - task.margin(ad.model(**co).logits.float(), dn))
            with ExitStack() as st:
                st.enter_context(ABL()); st.enter_context(patch_heads(ad, h_cl, [READER]))
                r_cl = task.margin(ad.model(**cl).logits.float(), dn)
            with ExitStack() as st:
                st.enter_context(ABL()); st.enter_context(patch_heads(ad, h_co, [READER]))
                r_co = task.margin(ad.model(**co).logits.float(), dn)
            dnm[z] += (cbase - cabl).tolist()
            num[z] += ((r_cl - r_co) - cabl).tolist()
        print(f"  {min(i+BATCH, len(X))}/{len(X)}", end="\r", flush=True)
print()

rows = []
for z in ZS:
    supplies = float(np.mean(dnm[z]))
    r = ratio_of_means(num[z], dnm[z])
    lo, hi = gboot_ratio(num[z], dnm[z], genes)
    rows.append((z, supplies, r, lo, hi))

print("=" * 92)
print("rescue of Z's coupling contribution by restoring L3H1 HEAD OUTPUT @all-pos "
      f"(n={len(X)} val)")
print(f"{'Z':10s} {'Z supplies':>11s} {'rescue':>8s} {'95% CI (gene-boot)':>22s}  "
      f"{'CI excludes 1?':>14s}")
print("-" * 92)
for z, s, r, lo, hi in sorted(rows, key=lambda t: -t[1]):
    excl = "YES  <-- FAILS" if (lo > 1.0 or hi < 1.0) else ""
    star = " *L2H15*" if z == ADDRESSER else ""
    if abs(s) < 0.15:
        excl = "(denom ~0)"
    print(f"L{z[0]}H{z[1]:<6d} {s:11.3f} {r:8.3f}   [{lo:+.3f},{hi:+.3f}] {excl:>14s}{star}")
print("=" * 92)

usable = [(z, s, r, lo, hi) for z, s, r, lo, hi in rows if s >= 0.15]
print(f"\nheads with a usable denominator (supplies >= 0.15): {len(usable)}")
fails = [t for t in usable if t[4] < 1.0 or t[3] > 1.0]
print(f"  of these, rescue CI EXCLUDES 1.0 for: {len(fails)}")
for z, s, r, lo, hi in sorted(fails, key=lambda t: t[2]):
    print(f"    L{z[0]}H{z[1]}  supplies {s:+.3f}  rescue {r:.3f}  [{lo:+.3f},{hi:+.3f}]")

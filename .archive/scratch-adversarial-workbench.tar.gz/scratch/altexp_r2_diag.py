"""POSITIVE CONTROL: plant a partner-specific interaction that is KNOWN to exist
in the SAME frozen SpliceBERT reps + SAME candidate sets + SAME optimizer, and ask
whether BilinearPairReadout recovers it while AdditivePairReadout cannot."""
from __future__ import annotations
import sys, math
from pathlib import Path
import torch
from torch import nn
import torch.nn.functional as F

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO/"src"))
from gfmcd.adapters.splicebert import SpliceBertAdapter
from gfmcd.splicing.config import load_config
from gfmcd.splicing.schema import SplicePairExample
from gfmcd.splicing.readout import AdditivePairReadout, BilinearPairReadout, collate_pair_indices

torch.manual_seed(0)
N_EX, BATCH = 1200, 8
dev = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO/"configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"]); mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(REPO/mc["path"], tokenizer_mode=mc.get("tokenizer_mode","auto"),
    device=dev, trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class","masked_lm"))
examples=[]
with (REPO/"colab_results/splicebert_run/baselines/val_local_conflicts.jsonl").open() as f:
    for line in f:
        if line.strip():
            examples.append(SplicePairExample.from_json(line))
            if len(examples)>=N_EX: break
cache=[]
for i in range(0,len(examples),BATCH):
    ex=examples[i:i+BATCH]
    tok=adapter.tokenize([x.sequence for x in ex])
    pb=collate_pair_indices(ex,token_offset=tok.prefix_tokens,device=adapter.device)
    with torch.no_grad():
        hid=adapter.forward(tok,output_hidden_states=True,output_attentions=False).hidden_states[rep]
    b=torch.arange(hid.shape[0],device=hid.device)[:,None]
    HA=hid[b,pb.positions[...,0]].float().cpu(); HD=hid[b,pb.positions[...,1]].float().cpu()
    for k,x in enumerate(ex):
        m=pb.mask[k].cpu()
        cache.append(dict(ha=HA[k][m].clone(),hd=HD[k][m].clone(),length=pb.lengths[k].cpu()[m].clone(),
            ai=torch.tensor([p.acceptor_index for p in x.pairs]),di=torch.tensor([p.donor_index for p in x.pairs]),
            t=int(x.true_pair_index)))
print(f"cached {len(cache)}",flush=True)

# ---------- plant a PURE partner-specific interaction ----------
D=512; RANK=8
U=torch.randn(RANK,D)/math.sqrt(D); V=torch.randn(RANK,D)/math.sqrt(D)
def additive_resid(y,ai,di):
    na,nd=int(ai.max())+1,int(di.max())+1
    X=torch.zeros(len(y),na+nd+1); X[torch.arange(len(y)),ai]=1.; X[torch.arange(len(y)),na+di]=1.; X[:,-1]=1.
    sol=torch.linalg.lstsq(X,y.unsqueeze(1)).solution
    return y-(X@sol).squeeze(1)
for c in cache:
    hn_a=F.layer_norm(c["ha"],(D,)); hn_d=F.layer_norm(c["hd"],(D,))
    t=((hn_a@U.T)*(hn_d@V.T)).sum(-1)/math.sqrt(RANK)     # genuine joint fn of (h_a,h_d)
    r=additive_resid(t,c["ai"],c["di"])                    # remove ALL additive main effects (OLS-orthogonal)
    c["synth"]=int(r.argmax())                             # label determined ONLY by the joint residual

def collate(items,label_key):
    P=max(len(c["length"]) for c in items)
    ha=torch.zeros(len(items),P,D); hd=torch.zeros(len(items),P,D)
    ln=torch.zeros(len(items),P); mk=torch.zeros(len(items),P,dtype=torch.bool); lb=torch.zeros(len(items),dtype=torch.long)
    for k,c in enumerate(items):
        n=len(c["length"]); ha[k,:n]=c["ha"]; hd[k,:n]=c["hd"]; ln[k,:n]=c["length"]; mk[k,:n]=True; lb[k]=c[label_key]
    return ha.to(dev),hd.to(dev),ln.to(dev),mk.to(dev),lb.to(dev)

def score(mod,ha,hd,ln,mk):
    add = mod.additive if isinstance(mod,BilinearPairReadout) else mod
    s = add.acceptor(ha).squeeze(-1)+add.donor(hd).squeeze(-1)+add.length(add._length_features(ln)).squeeze(-1)
    if isinstance(mod,BilinearPairReadout):
        s = s + (mod.left(mod.left_norm(ha))*mod.right(mod.right_norm(hd))).sum(-1)*mod.scale + mod.interaction_bias
    return s.masked_fill(~mk,torch.finfo(s.dtype).min)

def run(make,label_key,tag,epochs=40):
    tr,va=cache[:900],cache[900:]
    mod=make().to(dev)
    opt=torch.optim.AdamW(mod.parameters(),lr=1e-3,weight_decay=1e-4)
    best=0.
    for ep in range(epochs):
        mod.train(); idx=torch.randperm(len(tr))
        for i in range(0,len(tr),BATCH):
            items=[tr[j] for j in idx[i:i+BATCH]]
            ha,hd,ln,mk,lb=collate(items,label_key)
            loss=F.cross_entropy(score(mod,ha,hd,ln,mk),lb)
            opt.zero_grad(); loss.backward()
            torch.nn.utils.clip_grad_norm_(mod.parameters(),1.0); opt.step()
        mod.eval(); hit=0
        with torch.no_grad():
            for i in range(0,len(va),BATCH):
                ha,hd,ln,mk,lb=collate(va[i:i+BATCH],label_key)
                s=score(mod,ha,hd,ln,mk)
                tv=s.gather(1,lb[:,None]).squeeze(1)
                s2=s.scatter(1,lb[:,None],torch.finfo(s.dtype).min)
                hit+=int((tv>s2.max(-1).values).sum())
        best=max(best,hit/len(va))
    print(f"  {tag:34s} best val PMR = {best:.3f}",flush=True)
    return best

chance=sum(1.0/len(c["length"]) for c in cache[900:])/len(cache[900:])
print(f"\nchance PMR ~= {chance:.4f}  (mean 1/n_pairs)\n",flush=True)
print("=== TASK: PLANTED partner-specific interaction (additive main effects removed by OLS) ===",flush=True)
a1=0
MOD=[]
def run2():
    global MOD
    import copy
    tr,va=cache[:900],cache[900:]
    mod=BilinearPairReadout(D,interaction_rank=32).to(dev)
    opt=torch.optim.AdamW(mod.parameters(),lr=1e-3,weight_decay=1e-4)
    for ep in range(40):
        mod.train(); idx=torch.randperm(len(tr))
        for i in range(0,len(tr),BATCH):
            items=[tr[j] for j in idx[i:i+BATCH]]
            ha,hd,ln,mk,lb=collate(items,"synth")
            loss=F.cross_entropy(score(mod,ha,hd,ln,mk),lb)
            opt.zero_grad(); loss.backward()
            torch.nn.utils.clip_grad_norm_(mod.parameters(),1.0); opt.step()
    MOD.append(mod)
    return 0
b1=run2()
import math as _m
mod=MOD[0].cpu().eval()
def _afit(y,ai,di):
    na,nd=int(ai.max())+1,int(di.max())+1
    X=torch.zeros(len(y),na+nd+1); X[torch.arange(len(y)),ai]=1.; X[torch.arange(len(y)),na+di]=1.; X[:,-1]=1.
    sol=torch.linalg.lstsq(X,y.unsqueeze(1)).solution
    p=(X@sol).squeeze(1); sr=((y-p)**2).sum(); st=((y-y.mean())**2).sum()
    return float(1-sr/st)
r2s=[]
with torch.no_grad():
    for c in cache[900:]:
        y=(mod.left(mod.left_norm(c["ha"]))*mod.right(mod.right_norm(c["hd"]))).sum(-1)*mod.scale+mod.interaction_bias
        v=_afit(y,c["ai"],c["di"])
        if not _m.isnan(v): r2s.append(v)
r2s=torch.tensor(r2s)
print(f"\n>>> additive-R^2 of interaction term for a bilinear that PROVABLY LEARNED an interaction: mean {r2s.mean():.4f} median {r2s.median():.4f}",flush=True)
print("\n=== TASK: REAL partner selection (same loop, same data, sanity anchor) ===",flush=True)
a2=0
b2=0



"""Split the both-real-site decoys into the two cases that decide the steelman.

For a decoy (a',d') where BOTH endpoints are genuine annotated splice sites:
  (ii) a' and d' are NOT partners of each other (a' splices to some other donor;
       d' splices to some other acceptor) -> SITE DETECTION PROVABLY FAILS,
       PARTNER BINDING PROVABLY SUCCEEDS. This is the authors' defense.
  (i)  (a',d') IS itself an annotated exon in another isoform -> even partner
       information cannot disambiguate; only the window centering can.
"""
import gzip
import json
from collections import defaultdict

GTF = "data/external/gencode/v50/gencode.v50.basic.annotation.gtf.gz"
CONF = "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl"

exons_by_tx = defaultdict(list)
with gzip.open(GTF, "rt") as fh:
    for line in fh:
        if line[0] == "#":
            continue
        f = line.split("\t")
        if f[2] != "exon":
            continue
        chrom, start, end, strand, attrs = f[0], int(f[3]) - 1, int(f[4]), f[6], f[8]
        tx = attrs.split('transcript_id "', 1)[1].split('"', 1)[0]
        exons_by_tx[(chrom, strand, tx)].append((start, end))

real_acc, real_don, real_exon = defaultdict(set), defaultdict(set), defaultdict(set)
for (chrom, strand, _tx), ex in exons_by_tx.items():
    ex.sort()
    if len(ex) < 2:
        continue
    order = ex if strand == "+" else ex[::-1]
    internal = order[1:-1]
    if strand == "+":
        for e in order[1:]:
            real_acc[(chrom, strand)].add(e[0])
        for e in order[:-1]:
            real_don[(chrom, strand)].add(e[1])
        for e in internal:
            real_exon[(chrom, strand)].add((e[0], e[1]))          # (acceptor anchor, donor anchor)
    else:
        for e in order[1:]:
            real_acc[(chrom, strand)].add(e[1] - 1)
        for e in order[:-1]:
            real_don[(chrom, strand)].add(e[0] - 1)
        for e in internal:
            real_exon[(chrom, strand)].add((e[1] - 1, e[0] - 1))

n = 0
site_oracle_hits = 0        # 1[a real] + 1[d real]
partner_oracle_hits = 0     # 1[(a,d) is an annotated exon]  <- pure partner knowledge
ex_needs_partner = 0        # has a both-real decoy that is NOT an annotated exon
ex_ambiguous = 0            # has a decoy that IS an annotated exon (unresolvable by biology)
d_bothreal_nonexon = 0
d_bothreal_exon = 0

with open(CONF) as fh:
    for line in fh:
        d = json.loads(line)
        n += 1
        chrom, strand = d["chrom"], d["strand"]
        ws = d["metadata"]["genomic_window_start"]
        we = d["metadata"]["genomic_window_end"]
        to_gen = (lambda i: ws + i) if strand == "+" else (lambda i: we - 1 - i)
        RA, RD, RE = real_acc[(chrom, strand)], real_don[(chrom, strand)], real_exon[(chrom, strand)]

        pairs = d["pairs"]
        tp = pairs[d["true_pair_index"]]
        ta, td = tp["acceptor_pos"], tp["donor_pos"]

        best_site, best_partner = 0, 0
        needs_partner = False
        ambiguous = False
        for p in pairs:
            a, dd = p["acceptor_pos"], p["donor_pos"]
            if a == ta and dd == td:
                continue
            ga, gd = to_gen(a), to_gen(dd)
            ar, dr = ga in RA, gd in RD
            s = ar + dr
            best_site = max(best_site, s)
            is_exon = (ga, gd) in RE
            best_partner = max(best_partner, 1 if is_exon else 0)
            if s == 2:
                if is_exon:
                    d_bothreal_exon += 1
                    ambiguous = True
                else:
                    d_bothreal_nonexon += 1
                    needs_partner = True
        if 2 > best_site:
            site_oracle_hits += 1
        if 1 > best_partner:
            partner_oracle_hits += 1
        if needs_partner:
            ex_needs_partner += 1
        if ambiguous:
            ex_ambiguous += 1

print(f"n = {n}\n")
print(f"SITE oracle    1[a real]+1[d real]              PMR = {site_oracle_hits/n:.4f}")
print(f"PARTNER oracle 1[(a,d) is an annotated exon]    PMR = {partner_oracle_hits/n:.4f}")
print()
print(f"examples where site detection PROVABLY FAILS but partner binding SUCCEEDS")
print(f"  (>=1 decoy = two real sites that are NOT partners): {ex_needs_partner}/{n} = {ex_needs_partner/n:.4f}")
print(f"examples with a decoy that IS a real annotated exon (biologically ambiguous):")
print(f"  {ex_ambiguous}/{n} = {ex_ambiguous/n:.4f}")
print()
print(f"both-real decoys that are NOT annotated exons (partner-discriminable): {d_bothreal_nonexon}")
print(f"both-real decoys that ARE annotated exons (ambiguous):                {d_bothreal_exon}")

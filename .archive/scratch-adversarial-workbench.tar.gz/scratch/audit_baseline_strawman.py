"""Referee test: is the registered PWM+length baseline under-fit in a way that
destabilises the conflict set?

Variants (all are STRICTLY LOCAL + ADDITIVE, i.e. same hypothesis class):
  FROZEN     : the pickled registered baseline (exact, fit on full train)
  REG_SUB    : registered config refit on a train subsample  -> subsample noise floor
  UNIFORM_BG : registered windows, background = 0.25 each     -> axis (2)
  CAND_BG    : registered windows, background from ALL CANDIDATE windows (decoys)
  WIDE       : windows (-40..+10)/(-10..+12), generative      -> axis (4)
  LW sweep   : registered windows, length_weight grid         -> axis (3)
  DISC3      : discriminative reweighting of the 3 registered features (w_a,w_d,w_L)
  DISC_PWM   : discriminative PWM weights (registered widths) + w_L   -> axis (1)
  DISC_PWM_W : discriminative PWM weights (wide widths) + w_L         -> axes (1)+(4)

Reports val top-1 and, for each, the conflict set (argmax != true) and its
Jaccard / retention against the FROZEN conflict set.
"""
from __future__ import annotations

import json
import pickle
import sys
import numpy as np
import torch

DATA = "data/processed/splicebert_partner_selection/v1"
BASE = "colab_results/splicebert_run/baselines/local_pair_baseline.pkl"
B2I = {"A": 0, "C": 1, "G": 2, "T": 3}
MAXP = 512
TRAIN_STRIDE = int(sys.argv[1]) if len(sys.argv) > 1 else 9  # ~19.7k train examples


def parse(line):
    d = json.loads(line)
    seq = d["sequence"].upper().replace("U", "T")
    acc = np.asarray([a["position"] for a in d["acceptors"]], dtype=np.int32)
    don = np.asarray([x["position"] for x in d["donors"]], dtype=np.int32)
    pa = np.asarray([p["acceptor_index"] for p in d["pairs"]], dtype=np.int32)
    pd = np.asarray([p["donor_index"] for p in d["pairs"]], dtype=np.int32)
    plen = np.asarray([p["donor_pos"] - p["acceptor_pos"] for p in d["pairs"]], dtype=np.int32)
    t = d["true_pair_index"]
    return dict(id=d["example_id"], seq=seq, acc=acc, don=don, pa=pa, pd=pd,
                plen=plen, t=t, ta=d["pairs"][t]["acceptor_pos"], td=d["pairs"][t]["donor_pos"])


def load(path, stride=1, limit=None):
    out = []
    with open(path) as f:
        for i, line in enumerate(f):
            if i % stride:
                continue
            out.append(parse(line))
            if limit and len(out) >= limit:
                break
    return out


def win_idx(seq, pos, kind, ua, da, ud, dd):
    """Return int array of base indices for the site window, or None if OOB."""
    if kind == "a":
        s, e = pos - ua, pos + da
    else:
        s, e = pos - ud, pos + dd
    if s < 0 or e > len(seq):
        return None
    w = seq[s:e]
    return np.asarray([B2I.get(b, 4) for b in w], dtype=np.int8)  # 4 = unknown/N


def build(exs, ua, da, ud, dd, dev):
    """Tensorise: global acceptor/donor window banks + padded pair tables."""
    WA, WD = ua + da, ud + dd
    accw, donw, accok, donok = [], [], [], []
    aoff, doff = [], []
    for x in exs:
        aoff.append(len(accw))
        doff.append(len(donw))
        for p in x["acc"]:
            w = win_idx(x["seq"], int(p), "a", ua, da, ud, dd)
            accok.append(w is not None)
            accw.append(w if w is not None else np.zeros(WA, dtype=np.int8))
        for p in x["don"]:
            w = win_idx(x["seq"], int(p), "d", ua, da, ud, dd)
            donok.append(w is not None)
            donw.append(w if w is not None else np.zeros(WD, dtype=np.int8))
    accw = torch.tensor(np.stack(accw).astype(np.int64), device=dev)
    donw = torch.tensor(np.stack(donw).astype(np.int64), device=dev)
    accok = torch.tensor(np.asarray(accok), device=dev)
    donok = torch.tensor(np.asarray(donok), device=dev)

    N = len(exs)
    pa = np.zeros((N, MAXP), dtype=np.int64)
    pd = np.zeros((N, MAXP), dtype=np.int64)
    pl = np.zeros((N, MAXP), dtype=np.int64)
    msk = np.zeros((N, MAXP), dtype=bool)
    lab = np.zeros(N, dtype=np.int64)
    for i, x in enumerate(exs):
        n = len(x["pa"])
        pa[i, :n] = x["pa"] + aoff[i]
        pd[i, :n] = x["pd"] + doff[i]
        pl[i, :n] = x["plen"]
        msk[i, :n] = True
        lab[i] = x["t"]
    return dict(accw=accw, donw=donw, accok=accok, donok=donok,
                pa=torch.tensor(pa, device=dev), pd=torch.tensor(pd, device=dev),
                pl=torch.tensor(pl, device=dev), msk=torch.tensor(msk, device=dev),
                lab=torch.tensor(lab, device=dev), WA=WA, WD=WD)


NEG = -1e9


def site_scores(T, Wa, Wd):
    """Wa: [WA,5], Wd: [WD,5] (index 4 = N)."""
    a = Wa.gather(1, T["accw"].t()).t().sum(-1) if False else \
        torch.stack([Wa[j][T["accw"][:, j]] for j in range(T["WA"])]).sum(0)
    d = torch.stack([Wd[j][T["donw"][:, j]] for j in range(T["WD"])]).sum(0)
    a = torch.where(T["accok"], a, torch.full_like(a, NEG))
    d = torch.where(T["donok"], d, torch.full_like(d, NEG))
    return a, d


def pair_logits(T, Wa, Wd, wL, lp_vec):
    a, d = site_scores(T, Wa, Wd)
    logits = a[T["pa"]] + d[T["pd"]] + wL * lp_vec[T["pl"]]
    return logits.masked_fill(~T["msk"], NEG)


def top1(T, logits):
    pred = logits.argmax(-1)
    return (pred == T["lab"]).float().mean().item(), (pred != T["lab"]).cpu().numpy()


# ---------- generative PWM fitting ----------
def fit_pwm(windows, bg_counts_from, pseudo=0.5):
    L = windows.shape[1]
    counts = np.full((L, 4), pseudo)
    for j in range(L):
        for b in range(4):
            counts[j, b] += (windows[:, j] == b).sum()
    probs = counts / counts.sum(1, keepdims=True)
    bg = bg_counts_from / bg_counts_from.sum()
    lo = np.log(probs) - np.log(bg)[None, :]
    out = np.zeros((L, 5))
    out[:, :4] = lo
    out[:, 4] = (bg[None, :] * lo).sum(1)  # N -> background expectation
    return out


def main():
    dev = "mps" if torch.backends.mps.is_available() else "cpu"
    print(f"device={dev} train_stride={TRAIN_STRIDE}", flush=True)
    tr = load(f"{DATA}/train.jsonl", stride=TRAIN_STRIDE)
    va = load(f"{DATA}/val.jsonl")
    print(f"train={len(tr)} val={len(va)}", flush=True)

    with open(BASE, "rb") as f:
        frozen = pickle.load(f)
    lp_frozen = np.full(1024, -30.0)
    for L in range(frozen.length_prior.min_length, frozen.length_prior.max_length + 1):
        lp_frozen[L] = frozen.length_prior.score(L)
    lp_frozen_t = torch.tensor(lp_frozen, dtype=torch.float32, device=dev)

    CFGS = {"reg": (20, 3, 3, 6), "wide": (40, 10, 10, 12)}
    T = {k: build(va, *CFGS[k], dev) for k in CFGS}
    Ttr = {k: build(tr, *CFGS[k], dev) for k in CFGS}
    print("tensorised", flush=True)

    # ---- true-site windows from the train subsample (for generative fits) ----
    def true_windows(exs, ua, da, ud, dd):
        aw, dw, lens = [], [], []
        for x in exs:
            a = win_idx(x["seq"], x["ta"], "a", ua, da, ud, dd)
            d = win_idx(x["seq"], x["td"], "d", ua, da, ud, dd)
            if a is not None and d is not None:
                aw.append(a); dw.append(d); lens.append(x["td"] - x["ta"])
        return np.stack(aw).astype(int), np.stack(dw).astype(int), np.asarray(lens)

    results = {}

    def evaluate(name, cfg, Wa, Wd, wL, lp_t):
        Wa_t = torch.tensor(Wa, dtype=torch.float32, device=dev)
        Wd_t = torch.tensor(Wd, dtype=torch.float32, device=dev)
        lg = pair_logits(T[cfg], Wa_t, Wd_t, wL, lp_t)
        acc, conf = top1(T[cfg], lg)
        results[name] = dict(val_top1=acc, n_conflict=int(conf.sum()), conflict=conf)
        print(f"{name:16s} val_top1={acc:.4f}  n_conflict={int(conf.sum())}", flush=True)
        return conf

    # FROZEN (exact registered baseline)
    Wa_f = np.zeros((frozen.acceptor_pwm.length, 5)); Wa_f[:, :4] = frozen.acceptor_pwm.log_odds
    Wa_f[:, 4] = (frozen.acceptor_pwm.background[None, :] * frozen.acceptor_pwm.log_odds).sum(1)
    Wd_f = np.zeros((frozen.donor_pwm.length, 5)); Wd_f[:, :4] = frozen.donor_pwm.log_odds
    Wd_f[:, 4] = (frozen.donor_pwm.background[None, :] * frozen.donor_pwm.log_odds).sum(1)
    conf_frozen = evaluate("FROZEN", "reg", Wa_f, Wd_f, frozen.length_weight, lp_frozen_t)

    # generative variants on the train subsample
    for cfg in ("reg", "wide"):
        ua, da, ud, dd = CFGS[cfg]
        AW, DW, LENS = true_windows(tr, ua, da, ud, dd)
        # length prior refit on subsample, same support as frozen
        cnt = np.full(frozen.length_prior.max_length - frozen.length_prior.min_length + 1, 1.0)
        for L in LENS:
            if frozen.length_prior.min_length <= L <= frozen.length_prior.max_length:
                cnt[L - frozen.length_prior.min_length] += 1
        lpv = np.full(1024, -30.0)
        lpv[frozen.length_prior.min_length:frozen.length_prior.max_length + 1] = np.log(cnt / cnt.sum())
        lp_t = torch.tensor(lpv, dtype=torch.float32, device=dev)

        bg_pos = np.array([(AW == b).sum() + (DW == b).sum() + 0.5 for b in range(4)], dtype=float)
        bg_a = np.array([(AW == b).sum() + 0.5 for b in range(4)], dtype=float)
        bg_d = np.array([(DW == b).sum() + 0.5 for b in range(4)], dtype=float)
        Wa = fit_pwm(AW, bg_a); Wd = fit_pwm(DW, bg_d)
        if cfg == "reg":
            evaluate("REG_SUB", cfg, Wa, Wd, 1.0, lp_t)
            evaluate("UNIFORM_BG", cfg, fit_pwm(AW, np.ones(4)), fit_pwm(DW, np.ones(4)), 1.0, lp_t)
            # background from ALL candidate windows (decoy composition)
            cw_a = np.bincount(Ttr["reg"]["accw"][Ttr["reg"]["accok"]].cpu().numpy().ravel(), minlength=5)[:4] + 0.5
            cw_d = np.bincount(Ttr["reg"]["donw"][Ttr["reg"]["donok"]].cpu().numpy().ravel(), minlength=5)[:4] + 0.5
            evaluate("CAND_BG", cfg, fit_pwm(AW, cw_a.astype(float)), fit_pwm(DW, cw_d.astype(float)), 1.0, lp_t)
            for w in (0.0, 0.5, 1.0, 1.5, 2.0, 3.0):
                evaluate(f"LW={w}", cfg, Wa, Wd, w, lp_t)
        else:
            evaluate("WIDE", cfg, Wa, Wd, 1.0, lp_t)
            for w in (0.5, 1.0, 2.0):
                evaluate(f"WIDE_LW={w}", cfg, Wa, Wd, w, lp_t)

        # ---- discriminative fits ----
        lp_tr = lp_t
        # DISC3: reweight the three registered features
        if cfg == "reg":
            Wa_t = torch.tensor(Wa_f, dtype=torch.float32, device=dev)
            Wd_t = torch.tensor(Wd_f, dtype=torch.float32, device=dev)
            a_tr, d_tr = site_scores(Ttr["reg"], Wa_t, Wd_t)
            w = torch.zeros(3, device=dev, requires_grad=True)
            with torch.no_grad():
                w += torch.tensor([1.0, 1.0, 1.0], device=dev)
            opt = torch.optim.Adam([w], lr=0.05)
            for step in range(400):
                lg = (w[0] * a_tr[Ttr["reg"]["pa"]] + w[1] * d_tr[Ttr["reg"]["pd"]]
                      + w[2] * lp_frozen_t[Ttr["reg"]["pl"]]).masked_fill(~Ttr["reg"]["msk"], NEG)
                loss = torch.nn.functional.cross_entropy(lg, Ttr["reg"]["lab"])
                opt.zero_grad(); loss.backward(); opt.step()
            wv = w.detach().cpu().numpy()
            print(f"  DISC3 weights = {wv}  train_loss={loss.item():.4f}", flush=True)
            evaluate("DISC3", "reg", Wa_f * wv[0], Wd_f * wv[1], float(wv[2]), lp_frozen_t)

        # DISC_PWM: free local weights, softmax CE over pairs
        Wa_p = torch.tensor(Wa, dtype=torch.float32, device=dev).clone().requires_grad_(True)
        Wd_p = torch.tensor(Wd, dtype=torch.float32, device=dev).clone().requires_grad_(True)
        wL_p = torch.tensor(1.0, device=dev, requires_grad=True)
        opt = torch.optim.Adam([Wa_p, Wd_p, wL_p], lr=0.05)
        for step in range(600):
            lg = pair_logits(Ttr[cfg], Wa_p, Wd_p, wL_p, lp_tr)
            loss = torch.nn.functional.cross_entropy(lg, Ttr[cfg]["lab"])
            opt.zero_grad(); loss.backward(); opt.step()
            if step % 200 == 0:
                print(f"  [{cfg}] disc step {step} loss {loss.item():.4f}", flush=True)
        name = "DISC_PWM" if cfg == "reg" else "DISC_PWM_W"
        with torch.no_grad():
            lg = pair_logits(T[cfg], Wa_p, Wd_p, wL_p, lp_tr)
            acc, conf = top1(T[cfg], lg)
        results[name] = dict(val_top1=acc, n_conflict=int(conf.sum()), conflict=conf)
        print(f"{name:16s} val_top1={acc:.4f}  n_conflict={int(conf.sum())}  wL={wL_p.item():.3f}", flush=True)

    # ---- conflict-set stability vs FROZEN ----
    print("\n=== conflict-set stability vs FROZEN (n=%d) ===" % conf_frozen.sum(), flush=True)
    summary = {}
    for name, r in results.items():
        c = r["conflict"]
        inter = int((c & conf_frozen).sum())
        union = int((c | conf_frozen).sum())
        summary[name] = dict(val_top1=r["val_top1"], n_conflict=int(c.sum()),
                             retained=inter, retained_frac=inter / int(conf_frozen.sum()),
                             jaccard=inter / union)
        print(f"{name:16s} top1={r['val_top1']:.4f} n={int(c.sum()):6d} "
              f"retained={inter/int(conf_frozen.sum()):.3f} jaccard={inter/union:.3f}", flush=True)
    with open("scratch/audit_baseline_strawman.json", "w") as f:
        json.dump(summary, f, indent=2)
    np.savez("scratch/audit_baseline_conflicts.npz",
             ids=np.asarray([x["id"] for x in va]),
             **{k: results[k]["conflict"] for k in results})


if __name__ == "__main__":
    main()

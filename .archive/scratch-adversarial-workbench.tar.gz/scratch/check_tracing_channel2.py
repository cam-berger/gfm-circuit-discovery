#!/usr/bin/env python
"""v2: select C by EXACT mean-ablation necessity on discovery (as run_tracing's N does),
then decompose the ablation effect on the confirmation set into the additive readout's
A / D / L channels.  Read-only.
"""
from __future__ import annotations

import json
from pathlib import Path
import sys

import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))

from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.circuits.attribution import head_attribution_scan  # noqa: E402
from gfmcd.circuits.hf_bert import capture_head_outputs, edit_heads, matched_random_head_sets  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.io import load_jsonl  # noqa: E402
from gfmcd.splicing.readout import collate_pair_indices, true_pair_margin  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint  # noqa: E402

N_D, N_V = int(sys.argv[1]), int(sys.argv[2])
SHORT, SET_SIZE, BATCH = 12, 5, 8
NEG = float("-inf")

device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"])
mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
readout, checkpoint = load_pair_checkpoint(
    REPO / "colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt", adapter=adapter)
assert checkpoint.get("backbone_state") is None

sd = REPO / "results/splicebert_partner_selection/circuits/discovery"
D = load_jsonl(sd / "discovery.jsonl")[:N_D]
V = load_jsonl(sd / "confirmation.jsonl")[:N_V]


def batches(examples):
    out = []
    for i in range(0, len(examples), BATCH):
        ex = examples[i:i + BATCH]
        tok = adapter.tokenize([x.sequence for x in ex])
        pb = collate_pair_indices(ex, token_offset=tok.prefix_tokens, device=adapter.device)
        out.append((ex, tok, pb))
    return out


def margin_sum(tok, pb, grad=False):
    out = adapter.forward(tok, output_hidden_states=True, output_attentions=False, grad=grad)
    return true_pair_margin(readout(out.hidden_states[rep], pb), pb).sum()


def mean_margin(bs, ablate=None):
    tot, n = 0.0, 0
    with torch.no_grad():
        for ex, tok, pb in bs:
            if ablate:
                with edit_heads(adapter, ablate[0], mode=ablate[1]):
                    tot += float(margin_sum(tok, pb))
            else:
                tot += float(margin_sum(tok, pb))
            n += len(ex)
    return tot / n


Db, Vb = batches(D), batches(V)

# AtP shortlist (necessity: act*grad)
agg = {}
for ex, tok, pb in Db:
    with torch.no_grad():
        cache = capture_head_outputs(adapter, lambda tok=tok, pb=pb: float(margin_sum(tok, pb)))
    zeros = {l: torch.zeros_like(v) for l, v in cache.items()}
    for e in head_attribution_scan(adapter, zeros, lambda tok=tok, pb=pb: margin_sum(tok, pb, grad=True)):
        agg[(e.layer, e.head)] = agg.get((e.layer, e.head), 0.0) - e.attribution
short = [k for k, _ in sorted(agg.items(), key=lambda kv: kv[1], reverse=True)[:SHORT]]

base_D = mean_margin(Db)
eff = {h: base_D - mean_margin(Db, ablate=([h], "mean")) for h in short}
C = [h for h, _ in sorted(eff.items(), key=lambda kv: kv[1], reverse=True)[:SET_SIZE]]
print("shortlist(AtP):", short)
print("exact single-head mean-ablation effects on D:",
      {f"{l}-{h}": round(v, 3) for (l, h), v in sorted(eff.items(), key=lambda kv: -kv[1])})
print("C (top-5 exact necessity):", C)


def collect(bs, ablate=None):
    rows = []
    for ex, tok, pb in bs:
        with torch.no_grad():
            if ablate:
                with edit_heads(adapter, ablate[0], mode=ablate[1]):
                    out = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
            else:
                out = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
            hid = out.hidden_states[rep]
            b = torch.arange(hid.shape[0], device=hid.device)[:, None]
            A = readout.acceptor(hid[b, pb.positions[..., 0]]).squeeze(-1).float().cpu()
            Dn = readout.donor(hid[b, pb.positions[..., 1]]).squeeze(-1).float().cpu()
            L = readout.length(readout._length_features(pb.lengths)).squeeze(-1).float().cpu()
        m_all = pb.mask.cpu()
        acc, don = pb.positions[..., 0].cpu(), pb.positions[..., 1].cpu()
        for k, x in enumerate(ex):
            m = m_all[k]
            rows.append(dict(A=A[k][m], D=Dn[k][m], L=L[k][m], acc=acc[k][m], don=don[k][m],
                             t=int((torch.arange(len(m))[m] == x.true_pair_index).nonzero()[0])))
    return rows


def stats(rows):
    o = dict(full=[], dA=[], dD=[], dL=[], accblind=[], donblind=[], shares_acc=[],
             site_acc=[], site_don=[])
    for r in rows:
        t = r["t"]
        s = r["A"] + r["D"] + r["L"]
        d = s.clone(); d[t] = NEG
        j = int(d.argmax())
        o["full"].append(float(s[t] - s[j]))
        o["dA"].append(float(r["A"][t] - r["A"][j]))
        o["dD"].append(float(r["D"][t] - r["D"][j]))
        o["dL"].append(float(r["L"][t] - r["L"][j]))
        o["shares_acc"].append(int(r["acc"][j]) == int(r["acc"][t]))
        for nm, sc in (("accblind", r["D"] + r["L"]), ("donblind", r["A"] + r["L"])):
            dd = sc.clone(); dd[t] = NEG
            o[nm].append(float(sc[t] - dd.max()))
        # site-detector accuracy of each term alone (argmax over distinct site positions)
        o["site_acc"].append(int(int(r["acc"][int(r["A"].argmax())]) == int(r["acc"][t])))
        o["site_don"].append(int(int(r["don"][int(r["D"].argmax())]) == int(r["don"][t])))
    return {k: sum(v) / len(v) for k, v in o.items()}


cl = stats(collect(Vb))
ab = stats(collect(Vb, ablate=(C, "mean")))
rnd = [stats(collect(Vb, ablate=(list(rs), "mean")))
       for rs in matched_random_head_sets(adapter, C, n=3, seed=0, exclude_selected=True)]

e = cl["full"] - ab["full"]
print(f"\nVc n={N_V}: clean full margin {cl['full']:+.4f} (dA {cl['dA']:+.4f} dD {cl['dD']:+.4f} dL {cl['dL']:+.4f})"
      f" | top decoy shares true acceptor {cl['shares_acc']:.3f}")
print(f"clean site-detection: A-term picks true acceptor {cl['site_acc']:.3f} | D-term picks true donor {cl['site_don']:.3f}")
print(f"\nABLATE C={C}: effect on FULL margin {e:+.4f}   (matched-random: "
      f"{[round(cl['full']-r['full'],3) for r in rnd]})")
print(f"  channel decomposition of the effect:")
print(f"    donor term    dD: {cl['dD']-ab['dD']:+.4f}  ({100*(cl['dD']-ab['dD'])/e:.0f}%)")
print(f"    acceptor term dA: {cl['dA']-ab['dA']:+.4f}  ({100*(cl['dA']-ab['dA'])/e:.0f}%)")
print(f"    length term   dL: {cl['dL']-ab['dL']:+.4f}  ({100*(cl['dL']-ab['dL'])/e:.0f}%)")
print(f"  effect on ACCEPTOR-BLIND margin (D+L): {cl['accblind']-ab['accblind']:+.4f} "
      f"(finding predicts ~= full {e:+.4f})")
print(f"  effect on DONOR-BLIND    margin (A+L): {cl['donblind']-ab['donblind']:+.4f} (finding predicts ~0)")
print(f"  ablated site-detection: A-term true acceptor {ab['site_acc']:.3f} (clean {cl['site_acc']:.3f}) | "
      f"D-term true donor {ab['site_don']:.3f} (clean {cl['site_don']:.3f})")

json.dump(dict(C=[list(c) for c in C], shortlist=[list(h) for h in short],
               single_head_effects={f"{l}-{h}": v for (l, h), v in eff.items()},
               clean=cl, ablated=ab, random=rnd, n_D=N_D, n_V=N_V),
          open(REPO / "scratch/check_tracing_channel2_results.json", "w"), indent=2)

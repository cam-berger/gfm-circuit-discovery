"""VERIFICATION: mediator-specificity of the rescue at run_l2_accounting.py:149.

Claimant's mechanism story is that freezing ANY layer-3 head output at all positions
"hard-codes the intact clean-vs-corrupt signal into BOTH runs", so num -> dnm trivially.
If that were the mechanism, restoring a DIFFERENT layer-3 head (not L3H1) should also
rescue ~1.0.  Test every layer-3 head as the mediator, L2H15 ablated throughout.
"""
import sys
from contextlib import ExitStack
from pathlib import Path

import numpy as np
import torch

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "src"))

from gfmcd.splicing.circuit import (  # noqa: E402
    ADDRESSER, DEFAULT_FASTA, DEFAULT_GTF, DEFAULT_MODEL, READER, CouplingTask, ablate,
    capture_head_outputs, gboot_ratio, load_adapter, load_examples, patch_heads,
    pick_device, ratio_of_means,
)

N, BATCH = 90, 6
dev = pick_device(None)
ad = load_adapter(DEFAULT_MODEL, dev)
task = CouplingTask(ad, batch=BATCH)
X, _ = load_examples(DEFAULT_GTF, DEFAULT_FASTA, "val", N, task=task, tag="l2acct-val",
                     min_effect=0.3)
genes = [x.gene_id for x in X]
ABL = ablate(ad, [ADDRESSER])

MEDS = [(3, h) for h in range(ad.num_heads)]
num = {m: [] for m in MEDS}
dnm = []

with torch.no_grad():
    for i in range(0, len(X), BATCH):
        cl, co, dn = task.pair(X[i:i + BATCH])
        h_cl = capture_head_outputs(ad, lambda: ad.model(**cl))
        h_co = capture_head_outputs(ad, lambda: ad.model(**co))
        cbase = (task.margin(ad.model(**cl).logits.float(), dn)
                 - task.margin(ad.model(**co).logits.float(), dn))
        with ABL():
            cabl = (task.margin(ad.model(**cl).logits.float(), dn)
                    - task.margin(ad.model(**co).logits.float(), dn))
        dnm += (cbase - cabl).tolist()
        for m in MEDS:
            with ExitStack() as st:
                st.enter_context(ABL()); st.enter_context(patch_heads(ad, h_cl, [m]))
                r_cl = task.margin(ad.model(**cl).logits.float(), dn)
            with ExitStack() as st:
                st.enter_context(ABL()); st.enter_context(patch_heads(ad, h_co, [m]))
                r_co = task.margin(ad.model(**co).logits.float(), dn)
            num[m] += ((r_cl - r_co) - cabl).tolist()
        print(f"  {min(i+BATCH, len(X))}/{len(X)}", end="\r", flush=True)
print()

print("=" * 80)
print(f"L2H15 ablated; restore ONE layer-3 head's output @all-pos.  n={len(X)}, "
      f"L2H15 supplies {np.mean(dnm):+.3f}")
print(f"{'mediator':10s} {'rescue':>8s} {'95% CI':>22s}")
for m in MEDS:
    r = ratio_of_means(num[m], dnm)
    lo, hi = gboot_ratio(num[m], dnm, genes)
    tag = "  <-- THE READER (L3H1)" if m == READER else ""
    print(f"L{m[0]}H{m[1]:<7d} {r:8.3f}   [{lo:+.3f},{hi:+.3f}]{tag}")
print("=" * 80)

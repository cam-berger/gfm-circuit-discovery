#!/usr/bin/env python
"""STEELMAN TEST: can the ADDITIVE readout's score / true_pair_margin -- the exact
quantity run_tracing.py uses as its causal objective -- register PARTNER-SPECIFIC
information at all?

The finding under review asserts the margin is 'a measurement channel that provably
cannot carry partner-specific information' because score = f(h_a) + g(h_d) + L(len)
has no joint term.

That argument is only valid if h_a and h_d were LOCAL functions of their own
neighborhoods.  They are not: they are contextual states of a 6-layer transformer
over the whole window.  So g(h_d) CAN depend on which acceptor is present.

Decisive assay (already implemented in the repo: gfmcd.splicing.perturb.
boundary_pair_factorial, used by scripts/splicebert/pair_swap_factorial.py):
build AA / AB / BA / BB chimeras on ONE background (first letter = source of the
24nt ACCEPTOR window, second = source of the 24nt DONOR window).  Positions and
exon length are identical across all four, so L cancels exactly.

  If the backbone were partner-blind (h_d a function of the donor window + generic
  context only), then g(h_d) would depend ONLY on the second letter, f(h_a) ONLY on
  the first, and the interaction contrast AA - AB - BA + BB would be EXACTLY 0.

Read-only.  Uses the frozen additive-frozen seed0 checkpoint and the frozen tracing
splits.
"""
from __future__ import annotations

import json
from pathlib import Path
import random
import sys

import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))

from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.io import load_jsonl  # noqa: E402
from gfmcd.splicing.perturb import boundary_pair_factorial  # noqa: E402
from gfmcd.splicing.readout import collate_pair_indices, true_pair_margin  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint  # noqa: E402

MAX_PAIRS = int(sys.argv[1]) if len(sys.argv) > 1 else 128
FLANK = 12

device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"])
mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
ckpt = REPO / "colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt"
readout, checkpoint = load_pair_checkpoint(ckpt, adapter=adapter)
assert checkpoint.get("backbone_state") is None, "backbone must be the pretrained one"
print("regime:", checkpoint.get("extra_metadata", {}).get("regime"),
      "| readout:", type(readout).__name__, "| rep:", rep, "| device:", device)

sd = REPO / "results/splicebert_partner_selection/circuits/discovery"
pool = (load_jsonl(sd / "discovery.jsonl") + load_jsonl(sd / "confirmation.jsonl")
        + load_jsonl(sd / "ordinary.jsonl"))
print("pool:", len(pool))

# aligned pairs: equal length + identical true boundaries + different gene
groups: dict[tuple[int, int, int], list] = {}
for x in pool:
    groups.setdefault((len(x.sequence), x.true_pair.acceptor_pos, x.true_pair.donor_pos), []).append(x)
pairs = []
rng = random.Random(0)
for key in sorted(groups):
    items = sorted(groups[key], key=lambda x: (x.gene_id, x.example_id))
    used = set()
    for i, a in enumerate(items):
        if a.example_id in used:
            continue
        b = next((x for x in items[i + 1:] if x.example_id not in used and x.gene_id != a.gene_id), None)
        if b is None:
            continue
        acc, don = a.true_pair.acceptor_pos, a.true_pair.donor_pos
        if acc - FLANK < 0 or don + FLANK > len(a.sequence) or acc + FLANK > don - FLANK:
            continue
        pairs.append((a, b))
        used.update((a.example_id, b.example_id))
pairs = pairs[:MAX_PAIRS]
print("aligned cross-gene factorial pairs:", len(pairs))

LAB = ("AA", "AB", "BA", "BB")  # first = acceptor window source, second = donor window source
rows = []
for a, b in pairs:
    seqs = boundary_pair_factorial(a, a, b, flank=FLANK)
    tok = adapter.tokenize([seqs[k] for k in LAB])
    with torch.no_grad():
        out = adapter.forward(tok, output_hidden_states=True, output_attentions=False, grad=False)
        h = out.hidden_states[rep]                      # [4, S, D]
        pb = collate_pair_indices([a, a, a, a], token_offset=tok.prefix_tokens, device=adapter.device)
        logits = readout(h, pb)                          # [4, P]
        marg = true_pair_margin(logits, pb)              # [4]
        acc_pos = a.true_pair.acceptor_pos + tok.prefix_tokens
        don_pos = a.true_pair.donor_pos + tok.prefix_tokens
        f = readout.acceptor(h[:, acc_pos]).squeeze(-1)  # [4]  MLP_acc(h_a*)
        g = readout.donor(h[:, don_pos]).squeeze(-1)     # [4]  MLP_don(h_d*)
        tl = logits[torch.arange(4), pb.labels]          # true-pair logit
    d = {k: {} for k in LAB}
    for i, k in enumerate(LAB):
        d[k] = {"f": float(f[i]), "g": float(g[i]), "logit": float(tl[i]), "margin": float(marg[i])}
    rows.append(d)

print(f"scored {len(rows)} quadruplets ({4*len(rows)} forwards)")


def col(k, field):
    return torch.tensor([r[k][field] for r in rows])


def stats(v):
    return {"mean": float(v.mean()), "sd": float(v.std()), "mean_abs": float(v.abs().mean()),
            "frac_pos": float((v > 0).float().mean())}


res = {"n_quadruplets": len(rows), "flank": FLANK}

# --- 1. interaction contrast: 0 iff the composed model is additive in the two windows
for field in ("logit", "f", "g", "margin"):
    inter = col("AA", field) - col("AB", field) - col("BA", field) + col("BB", field)
    # main effects for scale reference
    acc_main = 0.5 * ((col("AA", field) + col("AB", field)) - (col("BA", field) + col("BB", field)))
    don_main = 0.5 * ((col("AA", field) + col("BA", field)) - (col("AB", field) + col("BB", field)))
    res[f"contrast_{field}"] = {
        "interaction": stats(inter),
        "acceptor_main_effect": stats(acc_main),
        "donor_main_effect": stats(don_main),
        "ratio_mean_abs_interaction_over_donor_main": float(inter.abs().mean() / don_main.abs().mean()),
    }

# --- 2. THE partner test through the additive readout:
# does the DONOR's score g(h_d) depend on WHICH acceptor window sits 200nt away,
# with the donor window byte-identical?   cognate vs non-cognate acceptor.
#   donor window = A:  cognate acceptor = A (AA) vs foreign acceptor = B (BA)
#   donor window = B:  cognate acceptor = B (BB) vs foreign acceptor = A (AB)
dg_donorA = col("AA", "g") - col("BA", "g")
dg_donorB = col("BB", "g") - col("AB", "g")
dg = torch.cat([dg_donorA, dg_donorB])
res["donor_score_depends_on_acceptor_window"] = {
    "delta_g_cognate_minus_foreign": stats(dg),
    "2afc_cognate_acceptor_raises_its_donor": float((dg > 0).float().mean()),
    "mean_abs_delta_g_from_acceptor_swap": float(dg.abs().mean()),
    "mean_abs_delta_g_from_donor_swap": float((col("AA", "g") - col("AB", "g")).abs().mean()),
}
df_accA = col("AA", "f") - col("AB", "f")
df_accB = col("BB", "f") - col("BA", "f")
dfv = torch.cat([df_accA, df_accB])
res["acceptor_score_depends_on_donor_window"] = {
    "delta_f_cognate_minus_foreign": stats(dfv),
    "2afc_cognate_donor_raises_its_acceptor": float((dfv > 0).float().mean()),
    "mean_abs_delta_f_from_donor_swap": float(dfv.abs().mean()),
    "mean_abs_delta_f_from_acceptor_swap": float((col("AA", "f") - col("BA", "f")).abs().mean()),
}

# --- 3. does the TRACING METRIC ITSELF (true_pair_margin) move when only the
# partner (acceptor) window is swapped to a foreign one?
dm_donorA = col("AA", "margin") - col("BA", "margin")
dm_donorB = col("BB", "margin") - col("AB", "margin")
dm = torch.cat([dm_donorA, dm_donorB])
res["tracing_metric_responds_to_partner_swap"] = {
    "delta_margin_cognate_minus_foreign_acceptor": stats(dm),
    "frac_examples_margin_changed_by_gt_0.1": float((dm.abs() > 0.1).float().mean()),
}

print(json.dumps(res, indent=2))
(REPO / "scratch/steelman_factorial_channel_results.json").write_text(json.dumps(res, indent=2) + "\n")

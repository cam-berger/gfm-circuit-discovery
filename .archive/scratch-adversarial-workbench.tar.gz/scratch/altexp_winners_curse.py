"""ALT-EXPLANATION test for the 'metric is causally blind to the acceptor' finding.

Rival mechanism: the acceptor term is NOT ignored -- it is SATURATED. Because f(h_a)
discriminates a* so strongly, every acceptor-swapped decoy is knocked far below the
true pair, so the LAST-STANDING decoy is always an acceptor-sharing one. A
max-over-decoys margin then attributes ~0 credit to the very term that eliminated
most of the competition. That is a winner's curse, not blindness.

Falsifiable prediction of the rival mechanism (vs the finding's 'acceptor ignored'):
  P1. Margin vs the best ACCEPTOR-SWAPPED decoy is large and positive, and is
      supplied almost entirely by the ACCEPTOR term.
  P2. If f were truly uninformative (A := 0), the top-decoy shared-acceptor rate must
      collapse to ~the pool base rate (~6%), and PMR must collapse.
  P3. Counterfactual: freeze A, and instead SATURATE the donor (D := large indicator on
      the true donor). Then the top decoy must flip to sharing the true DONOR, and the
      margin decomposition must flip to ~100% ACCEPTOR. If so, the '100% donor' number
      is a property of WHICH TERM IS STRONGER, not of what the model reads.
"""
from __future__ import annotations
import json, random, sys
from pathlib import Path
import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))
from gfmcd.adapters.splicebert import SpliceBertAdapter
from gfmcd.splicing.config import load_config
from gfmcd.splicing.schema import SplicePairExample
from gfmcd.splicing.readout import collate_pair_indices
from gfmcd.splicing.training import load_pair_checkpoint

N, BATCH, NEG = 400, 8, float("-inf")
device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"]); mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
readouts = {}
for s in (0, 1):
    r, ck = load_pair_checkpoint(REPO / f"colab_results/splicebert_run/runs/additive-frozen_seed{s}/checkpoint.pt", adapter=adapter)
    assert ck.get("backbone_state") is None
    readouts[s] = r

conf = REPO / "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl"
random.seed(20260711); keep = set(random.sample(range(10034), N))
examples = []
with conf.open() as f:
    for idx, line in enumerate(f):
        if idx in keep and line.strip():
            examples.append(SplicePairExample.from_json(line))
print(f"random sample n={len(examples)}, mean pairs {sum(len(x.pairs) for x in examples)/len(examples):.1f}")

rows = []
for i in range(0, len(examples), BATCH):
    ex = examples[i:i+BATCH]
    tok = adapter.tokenize([x.sequence for x in ex])
    pb = collate_pair_indices(ex, token_offset=tok.prefix_tokens, device=adapter.device)
    with torch.no_grad():
        out = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
        h = out.hidden_states[rep]
        b = torch.arange(h.shape[0], device=h.device)[:, None]
        ha, hd = h[b, pb.positions[..., 0]], h[b, pb.positions[..., 1]]
        per = {s: (readouts[s].acceptor(ha).squeeze(-1).float().cpu(),
                   readouts[s].donor(hd).squeeze(-1).float().cpu(),
                   readouts[s].length(readouts[s]._length_features(pb.lengths)).squeeze(-1).float().cpu())
               for s in (0, 1)}
    m = pb.mask.cpu()
    acc = (pb.positions[..., 0] - tok.prefix_tokens).cpu(); don = (pb.positions[..., 1] - tok.prefix_tokens).cpu()
    for k, x in enumerate(ex):
        mk = m[k]; t = x.true_pair_index
        rows.append(dict(t=t, acc=acc[k][mk].clone(), don=don[k][mk].clone(),
                         terms={s: tuple(per[s][j][k][mk].clone() for j in range(3)) for s in (0, 1)}))
    if (i//BATCH) % 10 == 0: print("  batch", i//BATCH, flush=True)

n = len(rows)
res = {}
for s in (0, 1):
    same_a_rate = 0; poolrate = 0.0
    m_all, m_accswap, m_donswap = [], [], []
    dA_as = dD_as = dL_as = 0.0
    dA_all = dD_all = dL_all = 0.0
    A_rank_true = 0; D_rank_true = 0
    # A:=0 counterfactual
    z_share_a = 0; z_pmr = 0; z_tie = 0
    # D saturated counterfactual
    sat_share_a = 0; sat_share_d = 0; sat_dA = sat_dD = sat_dL = 0.0
    n_accswap_beating_true_without_A = 0
    for r in rows:
        A, D, L = r["terms"][s]; t = r["t"]
        S = A + D + L
        a_star, d_star = int(r["acc"][t]), int(r["don"][t])
        is_a = (r["acc"] == a_star); is_d = (r["don"] == d_star)
        pool = torch.ones(len(S), dtype=torch.bool); pool[t] = False
        poolrate += float((is_a & pool).sum()) / float(pool.sum())
        # overall
        d1 = S.clone(); d1[t] = NEG; j = int(d1.argmax())
        m_all.append(float(S[t] - S[j])); same_a_rate += int(int(r["acc"][j]) == a_star)
        dA_all += float(A[t]-A[j]); dD_all += float(D[t]-D[j]); dL_all += float(L[t]-L[j])
        # best ACCEPTOR-SWAPPED decoy (a != a*)
        ds = S.clone(); ds[is_a] = NEG
        if torch.isfinite(ds).any():
            js = int(ds.argmax()); m_accswap.append(float(S[t] - S[js]))
            dA_as += float(A[t]-A[js]); dD_as += float(D[t]-D[js]); dL_as += float(L[t]-L[js])
        # best DONOR-SWAPPED decoy (d != d*, a == a*)
        dd = S.clone(); dd[~is_a] = NEG; dd[t] = NEG
        if torch.isfinite(dd).any():
            m_donswap.append(float(S[t] - dd.max()))
        # site-level ranks
        A_rank_true += int(float(A[t]) >= float(A[~is_a].max())) if (~is_a).any() else 1
        D_rank_true += int(float(D[t]) >= float(D[~is_d].max())) if (~is_d).any() else 1
        # P2: A := 0
        S0 = D + L; d0 = S0.clone(); d0[t] = NEG; j0 = int(d0.argmax())
        z_share_a += int(int(r["acc"][j0]) == a_star)
        z_pmr += int(float(S0[t]) > float(d0.max())); z_tie += int(float(S0[t]) == float(d0.max()))
        n_accswap_beating_true_without_A += int(float(S0[~is_a].max()) > float(S0[t])) if (~is_a).any() else 0
        # P3: saturate the donor term instead (D := 20 * 1[d==d*]), keep trained A and L
        Dsat = 20.0 * is_d.float()
        S2 = A + Dsat + L; d2 = S2.clone(); d2[t] = NEG; j2 = int(d2.argmax())
        sat_share_a += int(int(r["acc"][j2]) == a_star); sat_share_d += int(int(r["don"][j2]) == d_star)
        sat_dA += float(A[t]-A[j2]); sat_dD += float(Dsat[t]-Dsat[j2]); sat_dL += float(L[t]-L[j2])
    tot_all = dA_all + dD_all + dL_all
    tot_as = dA_as + dD_as + dL_as
    tot_sat = sat_dA + sat_dD + sat_dL
    v = dict(
      n=n,
      pool_base_rate_shares_acceptor=poolrate/n,
      top_decoy_shares_acceptor=same_a_rate/n,
      mean_margin_all=sum(m_all)/len(m_all),
      margin_all_share_A=dA_all/tot_all, margin_all_share_D=dD_all/tot_all, margin_all_share_L=dL_all/tot_all,
      mean_margin_vs_best_ACCEPTOR_SWAPPED_decoy=sum(m_accswap)/len(m_accswap),
      accswap_margin_share_A=dA_as/tot_as, accswap_margin_share_D=dD_as/tot_as, accswap_margin_share_L=dL_as/tot_as,
      mean_margin_vs_best_DONOR_SWAPPED_decoy=sum(m_donswap)/len(m_donswap),
      A_term_ranks_true_acceptor_first=A_rank_true/n, D_term_ranks_true_donor_first=D_rank_true/n,
      # P2
      A0_top_decoy_shares_acceptor=z_share_a/n, A0_PMR=z_pmr/n, A0_exact_ties=z_tie/n,
      A0_frac_where_an_ACCEPTOR_SWAPPED_decoy_beats_true=n_accswap_beating_true_without_A/n,
      # P3
      Dsat_top_decoy_shares_acceptor=sat_share_a/n, Dsat_top_decoy_shares_donor=sat_share_d/n,
      Dsat_margin_share_A=sat_dA/tot_sat, Dsat_margin_share_D=sat_dD/tot_sat, Dsat_margin_share_L=sat_dL/tot_sat,
    )
    res[s] = v
    print(f"\n=== seed{s} ===")
    for k2, x in v.items(): print(f"  {k2:52s} {x:.4f}" if isinstance(x, float) else f"  {k2:52s} {x}")
(REPO/"scratch/altexp_winners_curse_results.json").write_text(json.dumps(res, indent=2))
print("\nwrote scratch/altexp_winners_curse_results.json")

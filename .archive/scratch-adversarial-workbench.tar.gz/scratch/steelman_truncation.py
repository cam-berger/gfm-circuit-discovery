#!/usr/bin/env python
"""Steelman test of the 'label-dependent candidate truncation' finding.

Part A (no model, all 10,034 conflict examples, streaming):
  A1. Reconstruct the UNTRUNCATED pair set from the stored (untruncated) site lists.
      -> how many pairs were dropped, is the stored set a subset, is the true pair kept.
  A2. Median offset of surviving candidates from the true pair (the finding's evidence).
  A3. The finding's OWN predicted exploit: 'how central am I in the candidate cloud'.
      Score each pair by -sum_j (|a_i-a_j| + |d_i-d_j|) over the retained cloud (L1 medoid),
      and by -(|a_i - median_a| + |d_i - median_d|) (centroid rule).  Report top-1 + PMR.
  A4. Conflict-set soundness: is the baseline's winning decoy on the truncated set still
      present in the untruncated set (i.e. can truncation MANUFACTURE a conflict)?

Part B (model, sub-sample spread over the whole file):
  additive-frozen seed0.  Because the readout is additive, score(a,d)=A(a)+D(d)+L(len),
  so all pairs (truncated or not) can be scored from one forward pass.
  B1. PMR on the TRUNCATED (label-dependent) pair set  -- the published protocol.
  B2. PMR on the FULL untruncated pair set             -- label-independent, strictly harder.
  B3. PMR on a label-INDEPENDENT random 512-subsample of the full set (true pair inserted).
  B4. Same three numbers for the PWM+length baseline.
"""
from __future__ import annotations

import json
import pickle
import random
import sys
from pathlib import Path

import numpy as np
import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))

from gfmcd.splicing.schema import SplicePairExample  # noqa: E402

CONF = REPO / "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl"
MIN_L, MAX_L = 20, 500

# ---------------------------------------------------------------- Part A
print("=" * 78)
print("PART A -- geometry of the retained candidate cloud (all conflict examples)")
print("=" * 78)

n = 0
n_capped = 0
full_counts = []
kept_counts = []
subset_ok = 0
med_off_a = []
med_off_d = []
medoid_top1 = 0
medoid_pmr = 0
centroid_top1 = 0
centroid_pmr = 0
medoid_rank = []
sample_lines: dict[int, str] = {}
SUB_EVERY = 25  # ~401 examples spread over the file, for Part B

with CONF.open() as f:
    for li, line in enumerate(f):
        if not line.strip():
            continue
        if li % SUB_EVERY == 0:
            sample_lines[li] = line
        d = json.loads(line)
        acc = np.array([s["position"] for s in d["acceptors"]], dtype=np.int64)
        don = np.array([s["position"] for s in d["donors"]], dtype=np.int64)
        pairs = d["pairs"]
        ti = int(d["true_pair_index"])
        ta = pairs[ti]["acceptor_pos"]
        td = pairs[ti]["donor_pos"]

        # untruncated pair set from the (untruncated) site lists
        A2, D2 = np.meshgrid(acc, don, indexing="ij")
        L2 = D2 - A2
        valid = (L2 >= MIN_L) & (L2 <= MAX_L)
        n_full = int(valid.sum())
        full_counts.append(n_full)
        kept_counts.append(len(pairs))
        n += 1
        if len(pairs) >= 512:
            n_capped += 1

        kept_a = np.array([p["acceptor_pos"] for p in pairs], dtype=np.int64)
        kept_d = np.array([p["donor_pos"] for p in pairs], dtype=np.int64)

        # stored set must be a subset of the reconstructed full set
        fullset = {(int(a), int(dd)) for a, dd in zip(A2[valid], D2[valid])}
        if all((int(a), int(x)) in fullset for a, x in zip(kept_a, kept_d)):
            subset_ok += 1

        med_off_a.append(float(np.median(kept_a) - ta))
        med_off_d.append(float(np.median(kept_d) - td))

        # ---- the finding's predicted exploit: centrality in the retained cloud
        # medoid: sum of L1 distances to every other retained candidate (lower = more central)
        da = np.abs(kept_a[:, None] - kept_a[None, :]).sum(1)
        dd = np.abs(kept_d[:, None] - kept_d[None, :]).sum(1)
        cost = (da + dd).astype(np.float64)
        score = -cost
        medoid_top1 += int(np.argmax(score) == ti)
        best_decoy = np.max(np.delete(score, ti))
        medoid_pmr += int(score[ti] > best_decoy)
        medoid_rank.append(int((score > score[ti]).sum()) + 1)

        ca, cd = np.median(kept_a), np.median(kept_d)
        cscore = -(np.abs(kept_a - ca) + np.abs(kept_d - cd)).astype(np.float64)
        centroid_top1 += int(np.argmax(cscore) == ti)
        centroid_pmr += int(cscore[ti] > np.max(np.delete(cscore, ti)))

full_counts = np.array(full_counts)
kept_counts = np.array(kept_counts)
print(f"n examples                    : {n}")
print(f"stored pairs subset of full   : {subset_ok}/{n}")
print(f"kept pairs   mean/median/max  : {kept_counts.mean():.1f} / {np.median(kept_counts):.0f} / {kept_counts.max()}")
print(f"at the 512 cap                : {n_capped}/{n} ({100*n_capped/n:.2f}%)")
print(f"FULL pairs   mean/median/max  : {full_counts.mean():.1f} / {np.median(full_counts):.0f} / {full_counts.max()}")
print(f"pairs DROPPED mean/median     : {(full_counts-kept_counts).mean():.1f} / {np.median(full_counts-kept_counts):.0f}")
print(f"frac of full set retained     : mean {np.mean(kept_counts/full_counts):.3f}  median {np.median(kept_counts/full_counts):.3f}")
print()
print(f"median(kept acceptor) - true_acceptor : mean {np.mean(med_off_a):+.1f}  median {np.median(med_off_a):+.1f}")
print(f"median(kept donor)    - true_donor    : mean {np.mean(med_off_d):+.1f}  median {np.median(med_off_d):+.1f}")
print()
print("THE FINDING'S OWN PREDICTED EXPLOIT ('predict the centroid of the candidate cloud'):")
print(f"  L1-medoid rule   top-1 = {medoid_top1/n:.4f}   PMR = {medoid_pmr/n:.4f}   "
      f"median rank of true pair = {np.median(medoid_rank):.0f} / {np.median(kept_counts):.0f}")
print(f"  centroid rule    top-1 = {centroid_top1/n:.4f}   PMR = {centroid_pmr/n:.4f}")
print(f"  chance top-1 (1/mean pairs) = {1/kept_counts.mean():.4f}")
print()

# ---------------------------------------------------------------- Part B
print("=" * 78)
print("PART B -- additive-frozen seed0 scored on truncated vs UNTRUNCATED candidate sets")
print("=" * 78)

from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint  # noqa: E402
from gfmcd.splicing.baselines import LocalPairBaseline, site_window  # noqa: E402

device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"])
mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
readout, checkpoint = load_pair_checkpoint(
    REPO / "colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt", adapter=adapter)
print("regime:", checkpoint.get("extra_metadata", {}).get("regime"),
      "| backbone_state is None:", checkpoint.get("backbone_state") is None,
      "| readout:", type(readout).__name__, "| device:", device)

with (REPO / "colab_results/splicebert_run/baselines/local_pair_baseline.pkl").open("rb") as fh:
    baseline: LocalPairBaseline = pickle.load(fh)

examples = [SplicePairExample.from_json(l) for l in sample_lines.values()]
print(f"model sub-sample: {len(examples)} examples (every {SUB_EVERY}th line of the conflict file)")

rng = random.Random(0)
res = {k: 0 for k in ["m_trunc", "m_full", "m_rand", "b_trunc", "b_full", "b_rand",
                      "b_full_conflict", "trunc_decoy_in_full"]}
n_full_pairs = []

for x in examples:
    tok = adapter.tokenize([x.sequence])
    with torch.no_grad():
        out = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
        h = out.hidden_states[rep][0]  # [S, D]
    off = tok.prefix_tokens
    acc_pos = np.array([s.position for s in x.acceptors], dtype=np.int64)
    don_pos = np.array([s.position for s in x.donors], dtype=np.int64)
    with torch.no_grad():
        A = readout.acceptor(h[torch.as_tensor(acc_pos + off, device=h.device)]).squeeze(-1).float().cpu().numpy()
        D = readout.donor(h[torch.as_tensor(don_pos + off, device=h.device)]).squeeze(-1).float().cpu().numpy()

    # PWM site scores (baseline is also additive over sites)
    Ab = np.array([baseline.acceptor_pwm.score(site_window(x.sequence, int(p), "acceptor")) for p in acc_pos])
    Db = np.array([baseline.donor_pwm.score(site_window(x.sequence, int(p), "donor")) for p in don_pos])

    ai = {int(p): i for i, p in enumerate(acc_pos)}
    di = {int(p): i for i, p in enumerate(don_pos)}

    # full untruncated pair list
    full = [(int(a), int(dd)) for a in acc_pos for dd in don_pos if MIN_L <= dd - a <= MAX_L]
    n_full_pairs.append(len(full))
    tp = (x.true_pair.acceptor_pos, x.true_pair.donor_pos)
    trunc = [(p.acceptor_pos, p.donor_pos) for p in x.pairs]
    rand = rng.sample(full, min(512, len(full)))
    if tp not in rand:
        rand[rng.randrange(len(rand))] = tp

    def lterm(lengths):
        t = torch.tensor(lengths, dtype=torch.float32)
        with torch.no_grad():
            return readout.length(readout._length_features(t.to(h.device))).squeeze(-1).float().cpu().numpy()

    def score(plist, model: bool):
        lens = [b - a for a, b in plist]
        if model:
            s = np.array([A[ai[a]] + D[di[b]] for a, b in plist]) + lterm(lens)
        else:
            s = np.array([Ab[ai[a]] + Db[di[b]] + baseline.length_weight * baseline.length_prior.score(L)
                          for (a, b), L in zip(plist, lens)])
        return s

    for tag, plist in (("trunc", trunc), ("full", full), ("rand", rand)):
        k = plist.index(tp)
        for pfx, model in (("m_", True), ("b_", False)):
            s = score(plist, model)
            res[pfx + tag] += int(s[k] > np.max(np.delete(s, k)))

    # does the baseline still fail on the FULL set (conflict soundness)?
    sb = score(full, False)
    res["b_full_conflict"] += int(int(np.argmax(sb)) != full.index(tp))
    # is the truncated-set winning decoy also present in the full set?  (must be)
    st = score(trunc, False)
    wd = trunc[int(np.argmax(st))]
    res["trunc_decoy_in_full"] += int(wd in full)

N = len(examples)
print(f"mean FULL pairs/example {np.mean(n_full_pairs):.1f}  (truncated: "
      f"{np.mean([len(x.pairs) for x in examples]):.1f})")
print()
print("PMR (true pair strictly beats best decoy):")
print(f"  additive-frozen  TRUNCATED (published protocol, label-dependent) : {res['m_trunc']/N:.4f}")
print(f"  additive-frozen  FULL untruncated set (label-independent)        : {res['m_full']/N:.4f}")
print(f"  additive-frozen  RANDOM label-independent 512-subsample          : {res['m_rand']/N:.4f}")
print(f"  PWM baseline     TRUNCATED                                        : {res['b_trunc']/N:.4f}")
print(f"  PWM baseline     FULL untruncated set                             : {res['b_full']/N:.4f}")
print(f"  PWM baseline     RANDOM 512-subsample                             : {res['b_rand']/N:.4f}")
print()
print(f"conflict soundness: baseline argmax STILL a decoy on the FULL set : {res['b_full_conflict']}/{N}")
print(f"truncated winning decoy also present in the full set              : {res['trunc_decoy_in_full']}/{N}")

out = {"n_all": n, "capped": n_capped, "medoid_top1": medoid_top1/n, "medoid_pmr": medoid_pmr/n,
       "centroid_top1": centroid_top1/n, "centroid_pmr": centroid_pmr/n,
       "median_offset_acceptor": float(np.median(med_off_a)), "median_offset_donor": float(np.median(med_off_d)),
       "full_mean": float(full_counts.mean()), "kept_mean": float(kept_counts.mean()),
       "retained_frac_median": float(np.median(kept_counts/full_counts)),
       "N_model": N, **{k: v/N for k, v in res.items()}}
(REPO / "scratch/steelman_truncation_results.json").write_text(json.dumps(out, indent=2))
print("\nwrote scratch/steelman_truncation_results.json")

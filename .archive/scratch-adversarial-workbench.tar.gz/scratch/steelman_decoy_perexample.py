"""STEELMAN: the finding's denominator is PAIRS. PMR only cares about the BEST decoy
per example. Re-do the annotation audit with the EXAMPLE as the unit, and check the
subset of discriminations that could, in principle, require partner binding."""
from __future__ import annotations
import gzip, json
from collections import defaultdict

GTF = "data/external/gencode/v50/gencode.v50.basic.annotation.gtf.gz"
CONFLICTS = "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl"
CHROMS = {"chr17", "chr18"}

tx_exons = defaultdict(list); tx_meta = {}
with gzip.open(GTF, "rt") as f:
    for line in f:
        if line.startswith("#"): continue
        c = line.rstrip("\n").split("\t")
        if c[2] != "exon" or c[0] not in CHROMS: continue
        tid = c[8].split('transcript_id "',1)[1].split('"',1)[0]
        tx_exons[tid].append((int(c[3])-1, int(c[4]))); tx_meta[tid] = (c[0], c[6])

acc_anchor = {"+": set(), "-": set()}; don_anchor = {"+": set(), "-": set()}
for tid, exons in tx_exons.items():
    chrom, strand = tx_meta[tid]
    ex = sorted(exons); ex = ex[::-1] if strand == "-" else ex
    n = len(ex)
    if n < 2: continue
    for i,(s,e) in enumerate(ex):
        a,d = (s,e) if strand=="+" else (e-1, s-1)
        if i > 0: acc_anchor[strand].add(a)
        if i < n-1: don_anchor[strand].add(d)

S = defaultdict(int); n_ex = 0
n_real_real_decoys_hist = []
for line in open(CONFLICTS):
    d = json.loads(line); n_ex += 1
    strand = d["strand"]; W = d["metadata"]["genomic_window_start"]; E = d["metadata"]["genomic_window_end"]
    g = (lambda p: W+p) if strand=="+" else (lambda p: E-1-p)
    A, D = acc_anchor[strand], don_anchor[strand]
    tp = d["pairs"][d["true_pair_index"]]; ta, td = tp["acceptor_pos"], tp["donor_pos"]
    accR = {s["position"]: (g(s["position"]) in A) for s in d["acceptors"]}
    donR = {s["position"]: (g(s["position"]) in D) for s in d["donors"]}
    S["true_acc_real"] += accR[ta]; S["true_don_real"] += donR[td]

    # per-example existence of genuinely ambiguous decoys
    nrr = 0; swap_don_real = 0; swap_acc_real = 0
    for pr in d["pairs"]:
        a, dd = pr["acceptor_pos"], pr["donor_pos"]
        if a == ta and dd == td: continue
        both = accR[a] and donR[dd]
        nrr += both
        if a == ta and donR[dd]: swap_don_real += 1       # same true acceptor, decoy donor is a REAL donor
        if dd == td and accR[a]: swap_acc_real += 1       # same true donor, decoy acceptor is a REAL acceptor
    n_real_real_decoys_hist.append(nrr)
    S["ex_has_real_real_decoy"] += (nrr > 0)
    S["ex_has_true_acc_x_real_don"] += (swap_don_real > 0)   # "which of these REAL donors is a*'s partner?"
    S["ex_has_true_don_x_real_acc"] += (swap_acc_real > 0)
    S["ex_has_either_partner_style"] += (swap_don_real > 0 or swap_acc_real > 0)
    S["sum_real_real_decoys"] += nrr
    S["sum_swap_don_real"] += swap_don_real
    S["sum_swap_acc_real"] += swap_acc_real
    S["sum_pairs"] += len(d["pairs"])

print(f"n examples = {n_ex}")
print(f"true acceptor annotated: {S['true_acc_real']/n_ex:.4f}   true donor annotated: {S['true_don_real']/n_ex:.4f}")
print()
print("PER-EXAMPLE UNIT (what PMR actually cares about):")
print(f"  examples with >=1 decoy pair whose BOTH endpoints are annotated sites : {S['ex_has_real_real_decoy']}/{n_ex} = {S['ex_has_real_real_decoy']/n_ex:.4f}")
print(f"  examples with >=1 decoy = (TRUE acceptor, REAL-but-wrong donor)       : {S['ex_has_true_acc_x_real_don']}/{n_ex} = {S['ex_has_true_acc_x_real_don']/n_ex:.4f}")
print(f"  examples with >=1 decoy = (REAL-but-wrong acceptor, TRUE donor)       : {S['ex_has_true_don_x_real_acc']}/{n_ex} = {S['ex_has_true_don_x_real_acc']/n_ex:.4f}")
print(f"  examples with >=1 'partner-style' decoy (either of the two above)      : {S['ex_has_either_partner_style']}/{n_ex} = {S['ex_has_either_partner_style']/n_ex:.4f}")
print()
print("PER-PAIR UNIT (the finding's denominator):")
print(f"  total candidate pairs {S['sum_pairs']}; real-real decoy pairs {S['sum_real_real_decoys']} = {S['sum_real_real_decoys']/S['sum_pairs']:.6f}")
print(f"  mean real-real decoys per example: {S['sum_real_real_decoys']/n_ex:.3f}")
print(f"  mean (true-acc, real-wrong-donor) decoys per example: {S['sum_swap_don_real']/n_ex:.3f}")
print(f"  mean (real-wrong-acc, true-donor) decoys per example: {S['sum_swap_acc_real']/n_ex:.3f}")
import statistics as st
print(f"  median real-real decoys per example: {st.median(n_real_real_decoys_hist)}")

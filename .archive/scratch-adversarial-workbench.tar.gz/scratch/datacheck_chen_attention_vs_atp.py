#!/usr/bin/env python
"""DATA-CHECK of the pre-emption finding's PREDICTED SIGNATURE.

Finding: "C4's localization is pre-empted -- Chen et al. already report donor-acceptor
pairing in attention in the SAME layers.  If this is the same phenomenon, simply RANKING
heads by Chen's correlational statistic -- mean attention(true acceptor <-> true donor)
minus mean attention over unpaired D-A combinations, computed on your own windows with no
probe and no gradients -- should recover the same top heads that AtP finds (4-0, 3-4,
layers 2-4), with high rank correlation."

So: compute (i) Chen's correlational attention statistic per head, (ii) the study's own AtP
necessity attribution per head (same recipe as scripts/splicebert/run_tracing.py), and
(iii) the EXACT single-head mean-ablation causal effect per head, all on the study's own
discovery split with the study's own additive-frozen seed0 checkpoint.  Then measure rank
correlation and top-k overlap.  Read-only.
"""
from __future__ import annotations

import json
from pathlib import Path
import sys

import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))

from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.circuits.attribution import head_attribution_scan  # noqa: E402
from gfmcd.circuits.hf_bert import capture_head_outputs, edit_heads  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.io import load_jsonl  # noqa: E402
from gfmcd.splicing.readout import collate_pair_indices, true_pair_margin  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint  # noqa: E402

N_D = int(sys.argv[1]) if len(sys.argv) > 1 else 64
BATCH_ATTN = 2
BATCH = 8
MAX_DECOY = 24  # subsample of decoy sites per example for the "unpaired" statistic

device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"])
mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
readout, checkpoint = load_pair_checkpoint(
    REPO / "colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt", adapter=adapter)
assert checkpoint.get("backbone_state") is None, "backbone must be the frozen pretrained one"
try:
    adapter.model.set_attn_implementation("eager")
except Exception:
    adapter.model.config._attn_implementation = "eager"
print("attn impl:", getattr(adapter.model.config, "_attn_implementation", "?"))
L, H = adapter.num_layers, adapter.num_heads
print(f"layers={L} heads={H} rep={rep} device={device} regime="
      f"{checkpoint.get('extra_metadata', {}).get('regime')}")

D = load_jsonl(REPO / "results/splicebert_partner_selection/circuits/discovery/discovery.jsonl")[:N_D]
print(f"discovery examples: {len(D)}")

g = torch.Generator().manual_seed(0)

# ---------------------------------------------------------------- (i) Chen statistic
pair_s = torch.zeros(L, H)
unpair_s = torch.zeros(L, H)      # all candidate (a,d) combos except the true pair
swap_s = torch.zeros(L, H)        # one endpoint true, other a decoy
bg_s = torch.zeros(L, H)          # mean attention over all token pairs (= 1/T per row)
cnt = 0
for i in range(0, len(D), BATCH_ATTN):
    ex = D[i:i + BATCH_ATTN]
    tok = adapter.tokenize([x.sequence for x in ex])
    with torch.no_grad():
        out = adapter.forward(tok, output_hidden_states=True, output_attentions=True)
    atts = out.attentions  # tuple(L) of [B,H,T,T]
    off = tok.prefix_tokens
    for b, x in enumerate(ex):
        tp = x.pairs[x.true_pair_index]
        ta, td = tp.acceptor_pos + off, tp.donor_pos + off
        accs = sorted({p.acceptor_pos + off for p in x.pairs} - {ta})
        dons = sorted({p.donor_pos + off for p in x.pairs} - {td})
        ai = torch.tensor(accs)[torch.randperm(len(accs), generator=g)[:MAX_DECOY]]
        di = torch.tensor(dons)[torch.randperm(len(dons), generator=g)[:MAX_DECOY]]
        ai, di = ai.to(device), di.to(device)
        for l in range(L):
            A = atts[l][b]  # [H,T,T]
            pair_s[l] += (0.5 * (A[:, td, ta] + A[:, ta, td])).float().cpu()
            # unpaired: decoy acceptors x decoy donors, both directions
            sub = 0.5 * (A[:, di][:, :, ai] + A[:, ai][:, :, di].transpose(1, 2))
            unpair_s[l] += sub.mean(dim=(1, 2)).float().cpu()
            # swap: true acceptor x decoy donors, true donor x decoy acceptors
            sw = 0.5 * (A[:, ta, di] + A[:, di, ta]).mean(dim=1) \
                 + 0.5 * (A[:, td, ai] + A[:, ai, td]).mean(dim=1)
            swap_s[l] += (0.5 * sw).float().cpu()
            bg_s[l] += (1.0 / A.shape[-1])
        cnt += 1
    del atts, out
pair_s /= cnt; unpair_s /= cnt; swap_s /= cnt; bg_s /= cnt
chen = pair_s - unpair_s                    # Chen's D-A(intron) minus D-A(unpair)
chen_swap = pair_s - swap_s
chen_fold = pair_s / bg_s                   # fold over background (Fig 3C style)

# ---------------------------------------------------------------- (ii) AtP necessity
def batches(examples):
    out = []
    for i in range(0, len(examples), BATCH):
        ex = examples[i:i + BATCH]
        tok = adapter.tokenize([x.sequence for x in ex])
        pb = collate_pair_indices(ex, token_offset=tok.prefix_tokens, device=adapter.device)
        out.append((ex, tok, pb))
    return out


def margin_sum(tok, pb, grad=False):
    o = adapter.forward(tok, output_hidden_states=True, output_attentions=False, grad=grad)
    return true_pair_margin(readout(o.hidden_states[rep], pb), pb).sum()


Db = batches(D)
atp = torch.zeros(L, H)
caches = []
for ex, tok, pb in Db:
    with torch.no_grad():
        caches.append(capture_head_outputs(adapter, lambda tok=tok, pb=pb: float(margin_sum(tok, pb))))
for (ex, tok, pb), cache in zip(Db, caches):
    zeros = {l: torch.zeros_like(v) for l, v in cache.items()}
    res = head_attribution_scan(adapter, zeros, lambda tok=tok, pb=pb: margin_sum(tok, pb, grad=True))
    for e in res:
        atp[e.layer, e.head] += -e.attribution  # act*grad = necessity attribution

# ---------------------------------------------------------------- (iii) exact ablation
clean = sum(float(margin_sum(tok, pb)) for _e, tok, pb in Db) / len(D)
exact = torch.zeros(L, H)
with torch.no_grad():
    for l in range(L):
        for h in range(H):
            with edit_heads(adapter, [(l, h)], mode="mean"):
                s = sum(float(margin_sum(tok, pb)) for _e, tok, pb in Db) / len(D)
            exact[l, h] = clean - s
    print(f"clean mean margin on D: {clean:.4f}")


# ---------------------------------------------------------------- comparison
def spearman(a, b):
    a, b = a.flatten(), b.flatten()
    ra = a.argsort().argsort().float()
    rb = b.argsort().argsort().float()
    ra = (ra - ra.mean()) / ra.std()
    rb = (rb - rb.mean()) / rb.std()
    return float((ra * rb).mean())


def topk(t, k=5):
    idx = t.flatten().argsort(descending=True)[:k]
    return [(int(i) // H, int(i) % H) for i in idx]


names = {"chen(pair-unpair)": chen, "chen(pair-swap)": chen_swap, "chen_fold(pair/bg)": chen_fold,
         "AtP_necessity": atp, "exact_mean_ablation": exact}
print("\nTOP-8 heads by each ranking (layer, head), 0-based layers:")
for n, t in names.items():
    print(f"  {n:22s} {topk(t, 8)}")

print("\nSPEARMAN rank correlation over all 96 heads:")
keys = list(names)
for i in range(len(keys)):
    for j in range(i + 1, len(keys)):
        print(f"  {keys[i]:22s} vs {keys[j]:22s}  rho = {spearman(names[keys[i]], names[keys[j]]):+.3f}")

print("\nTOP-5 OVERLAP with AtP / exact:")
for n, t in names.items():
    for ref in ("AtP_necessity", "exact_mean_ablation"):
        ov = len(set(topk(t, 5)) & set(topk(names[ref], 5)))
        print(f"  {n:22s} top5 ∩ {ref:20s} = {ov}/5")

print("\nLAYER PROFILE (mean over 16 heads, 0-based layer index):")
print(f"  {'layer':6s} {'chen(pair-unpair)':>18s} {'pair/bg fold':>13s} {'AtP':>9s} {'exact':>9s}")
for l in range(L):
    print(f"  {l:<6d} {float(chen[l].mean()):18.6f} {float(chen_fold[l].mean()):13.2f} "
          f"{float(atp[l].mean()):9.4f} {float(exact[l].mean()):9.4f}")

DEC = [(4, 0), (2, 13), (3, 4)]
print("\nRANK (1=best of 96) of the DECISIONS-reported AtP top heads under each statistic:")
for n, t in names.items():
    order = [(int(i) // H, int(i) % H) for i in t.flatten().argsort(descending=True)]
    print(f"  {n:22s} " + "  ".join(f"{h}: #{order.index(h)+1}" for h in DEC))

json.dump(dict(n_D=len(D), clean=clean,
               chen=chen.tolist(), chen_swap=chen_swap.tolist(), chen_fold=chen_fold.tolist(),
               atp=atp.tolist(), exact=exact.tolist(),
               spearman={f"{keys[i]}|{keys[j]}": spearman(names[keys[i]], names[keys[j]])
                         for i in range(len(keys)) for j in range(i + 1, len(keys))}),
          open(REPO / "scratch/datacheck_chen_attention_vs_atp.json", "w"), indent=2)
print("\nwrote scratch/datacheck_chen_attention_vs_atp.json")

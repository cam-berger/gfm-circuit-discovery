#!/usr/bin/env python
"""SITE-ONLY probe: train per-position binary splice-site classifiers on the FROZEN
SpliceBERT representation (never seeing a pair), then score conflict pairs as
f(h_a) + g(h_d) + w * length_prior(L).  Tests the predicted signature of the
'C1 is site detection' finding: does this reproduce the reported 0.807 conflict PMR?
"""
from __future__ import annotations

import json
import random
from pathlib import Path
import sys

import torch
import torch.nn as nn

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))

from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.schema import SplicePairExample  # noqa: E402
import pickle  # noqa: E402

N_TRAIN = 3500
N_EVAL = 1000
NEG_PER_EX = 30
BATCH = 8
SEED = 0

random.seed(SEED)
torch.manual_seed(SEED)

device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"])
mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
print("device", device, "rep layer", rep)

with (REPO / "colab_results/splicebert_run/baselines/local_pair_baseline.pkl").open("rb") as fh:
    baseline = pickle.load(fh)
lp = baseline.length_prior
print("length prior:", lp.min_length, lp.max_length, "weight", baseline.length_weight)


def load(path: Path, n: int) -> list[SplicePairExample]:
    out = []
    with path.open() as f:
        for line in f:
            if not line.strip():
                continue
            out.append(SplicePairExample.from_json(line))
            if len(out) >= n:
                break
    return out


train_ex = load(REPO / "data/processed/splicebert_partner_selection/v1/train.jsonl", N_TRAIN)
eval_ex = load(REPO / "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl", N_EVAL)
print(f"train {len(train_ex)}  eval(conflict) {len(eval_ex)}")


@torch.no_grad()
def embed(ex_batch):
    tok = adapter.tokenize([x.sequence for x in ex_batch])
    out = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
    return out.hidden_states[rep], tok.prefix_tokens


# ---------- build site-level training data (NO pairs anywhere) ----------
feats = {"acceptor": [], "donor": []}
labels = {"acceptor": [], "donor": []}
for i in range(0, len(train_ex), BATCH):
    chunk = train_ex[i:i + BATCH]
    hidden, off = embed(chunk)
    for k, x in enumerate(chunk):
        tp = x.pairs[x.true_pair_index]
        for kind, sites, truepos in (
            ("acceptor", x.acceptors, tp.acceptor_pos),
            ("donor", x.donors, tp.donor_pos),
        ):
            pos_list = [s.position for s in sites]
            neg = [p for p in pos_list if p != truepos]
            random.shuffle(neg)
            sel = [truepos] + neg[:NEG_PER_EX]
            lab = [1.0] + [0.0] * len(neg[:NEG_PER_EX])
            idx = torch.tensor([p + off for p in sel], device=hidden.device)
            feats[kind].append(hidden[k].index_select(0, idx).float().cpu())
            labels[kind].append(torch.tensor(lab))
    if i % 200 == 0:
        print("  train embed", i, flush=True)

for kind in feats:
    feats[kind] = torch.cat(feats[kind])
    labels[kind] = torch.cat(labels[kind])
    print(kind, "features", tuple(feats[kind].shape), "pos frac %.3f" % labels[kind].mean().item())


def make_head(hidden_size=512, site_hidden=128):
    return nn.Sequential(
        nn.LayerNorm(hidden_size),
        nn.Linear(hidden_size, site_hidden),
        nn.GELU(),
        nn.Linear(site_hidden, 1),
    )


heads = {}
for kind in ("acceptor", "donor"):
    X = feats[kind]
    y = labels[kind]
    head = make_head().to(device)
    opt = torch.optim.AdamW(head.parameters(), lr=1e-3, weight_decay=0.01)
    lossf = nn.BCEWithLogitsLoss()
    n = X.shape[0]
    for epoch in range(40):
        perm = torch.randperm(n)
        tot = 0.0
        for j in range(0, n, 256):
            b = perm[j:j + 256]
            opt.zero_grad()
            xb = X[b].to(device); yb = y[b].to(device)
            out = head(xb).squeeze(-1)
            loss = lossf(out, yb)
            loss.backward()
            opt.step()
            tot += loss.item() * len(b)
        if epoch % 10 == 9:
            with torch.no_grad():
                logit = torch.cat([head(X[j:j+4096].to(device)).squeeze(-1).cpu() for j in range(0, n, 4096)])
                pos = logit[y == 1]
                negs = logit[y == 0][:20000]
                auroc = (pos[:, None] > negs[None, :]).float().mean().item()
            print(f"  {kind} epoch {epoch} loss {tot/n:.4f} train AUROC {auroc:.4f}", flush=True)
    heads[kind] = head.eval()


# ---------- evaluate on the conflict set ----------
weights = [0.0, 0.5, 1.0, 2.0]
hits = {w: 0 for w in weights}
top1 = {w: 0 for w in weights}
acc_top1 = 0
don_top1 = 0
n_eval = 0
site_auroc = {"acceptor": [0, 0], "donor": [0, 0]}

for i in range(0, len(eval_ex), BATCH):
    chunk = eval_ex[i:i + BATCH]
    hidden, off = embed(chunk)
    for k, x in enumerate(chunk):
        h = hidden[k]
        a_pos = [s.position for s in x.acceptors]
        d_pos = [s.position for s in x.donors]
        with torch.no_grad():
            fa = heads["acceptor"](h.index_select(0, torch.tensor([p + off for p in a_pos], device=h.device)).float()).squeeze(-1).cpu()
            gd = heads["donor"](h.index_select(0, torch.tensor([p + off for p in d_pos], device=h.device)).float()).squeeze(-1).cpu()
        tp = x.pairs[x.true_pair_index]
        ai = a_pos.index(tp.acceptor_pos)
        di = d_pos.index(tp.donor_pos)
        if int(fa.argmax()) == ai:
            acc_top1 += 1
        if int(gd.argmax()) == di:
            don_top1 += 1
        # per-site AUROC (true vs all other candidates of same kind)
        for kind, sc, ti in (("acceptor", fa, ai), ("donor", gd, di)):
            others = torch.cat([sc[:ti], sc[ti + 1:]])
            site_auroc[kind][0] += (sc[ti] > others).float().sum().item()
            site_auroc[kind][1] += others.numel()

        ai_idx = torch.tensor([p.acceptor_index for p in x.pairs])
        di_idx = torch.tensor([p.donor_index for p in x.pairs])
        lens = torch.tensor([float(p.exon_length) for p in x.pairs])
        lprior = torch.tensor([lp.score(int(L)) for L in lens])
        base = fa[ai_idx] + gd[di_idx]
        t = x.true_pair_index
        for w in weights:
            s = base + w * lprior
            true_s = s[t].item()
            s2 = s.clone()
            s2[t] = float("-inf")
            best = s2.max().item()
            if true_s > best:
                hits[w] += 1
            if true_s >= s.max().item():
                top1[w] += 1
        n_eval += 1
    if i % 200 == 0:
        print("  eval", i, flush=True)

print("\n==== SITE-ONLY MODEL (trained with NO pair supervision) ====")
print(f"n eval conflict examples: {n_eval}  (train examples used: {len(train_ex)})")
for kind in ("acceptor", "donor"):
    c, tot = site_auroc[kind]
    print(f"per-site AUROC (true {kind} vs decoy motifs, within window): {c/tot:.4f}")
print(f"top-1 true acceptor among candidates: {acc_top1/n_eval:.4f}")
print(f"top-1 true donor among candidates:    {don_top1/n_eval:.4f}")
for w in weights:
    print(f"PAIR PMR  (length weight {w:>3}): {hits[w]/n_eval:.4f}   top1 {top1[w]/n_eval:.4f}")
print("\nreference: trained additive-frozen pair-supervised readout = 0.807 conflict PMR")

json.dump(
    {
        "n_train": len(train_ex),
        "n_eval": n_eval,
        "site_auroc": {k: v[0] / v[1] for k, v in site_auroc.items()},
        "acceptor_top1": acc_top1 / n_eval,
        "donor_top1": don_top1 / n_eval,
        "pmr": {str(w): hits[w] / n_eval for w in weights},
        "top1_pair": {str(w): top1[w] / n_eval for w in weights},
    },
    open(REPO / "scratch/site_only_probe_results_big.json", "w"),
    indent=2,
)

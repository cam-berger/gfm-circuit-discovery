#!/usr/bin/env python
"""Follow-up: (1) wide gauge sweep, (2) can a per-example length basis manufacture ~0.55?"""
from __future__ import annotations
from pathlib import Path
import sys
import numpy as np
import torch
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import lsqr

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))
from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.schema import SplicePairExample  # noqa: E402
from gfmcd.splicing.readout import collate_pair_indices  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint  # noqa: E402

N, BATCH, LMIN, LMAX = 250, 8, 20, 500
CACHE = REPO / "scratch/_gauge_rows.npz"

if CACHE.exists():
    z = np.load(CACHE, allow_pickle=True)
    rows = list(z["rows"])
else:
    device = "mps" if torch.backends.mps.is_available() else "cpu"
    cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
    rep = int(cfg["readout"]["representation_layer"]); mc = cfg["model"]
    adapter = SpliceBertAdapter.from_pretrained(
        REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
        trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
    readout, _ = load_pair_checkpoint(
        REPO / "colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt", adapter=adapter)
    examples = []
    with (REPO / "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl").open() as f:
        for line in f:
            if line.strip():
                examples.append(SplicePairExample.from_json(line))
            if len(examples) >= N:
                break
    rows = []
    for i in range(0, len(examples), BATCH):
        ex = examples[i:i + BATCH]
        tok = adapter.tokenize([x.sequence for x in ex])
        pb = collate_pair_indices(ex, token_offset=tok.prefix_tokens, device=adapter.device)
        with torch.no_grad():
            hid = adapter.forward(tok, output_hidden_states=True, output_attentions=False).hidden_states[rep]
            b = torch.arange(hid.shape[0], device=hid.device)[:, None]
            A = readout.acceptor(hid[b, pb.positions[..., 0]]).squeeze(-1).float().cpu()
            D = readout.donor(hid[b, pb.positions[..., 1]]).squeeze(-1).float().cpu()
            Lt = readout.length(readout._length_features(pb.lengths)).squeeze(-1).float().cpu()
        m_ = pb.mask.cpu()
        for k, x in enumerate(ex):
            m = m_[k]
            rows.append(dict(A=A[k][m].numpy().astype(np.float64), D=D[k][m].numpy().astype(np.float64),
                             L=Lt[k][m].numpy().astype(np.float64),
                             acc=np.array([p.acceptor_pos for p in x.pairs]),
                             don=np.array([p.donor_pos for p in x.pairs]),
                             length=np.array([p.exon_length for p in x.pairs]), t=x.true_pair_index))
    np.savez(CACHE, rows=np.array(rows, dtype=object))

n = len(rows)
t1 = lambda f: sum(int(np.argmax(f(r)) == r["t"]) for r in rows) / n
print(f"n={n}")
print(f"GROUND TRUTH  full (A+D+Lterm)      = {t1(lambda r: r['A']+r['D']+r['L']):.4f}")
print(f"GROUND TRUTH  length-ablated (A+D)  = {t1(lambda r: r['A']+r['D']):.4f}")

print("\n=== (1) WIDE GAUGE SWEEP — every b gives BIT-IDENTICAL model logits ===")
print("   b        'length-ablated' top1  =  top1 of (A+D) - b*len")
for bb in [-0.05, -0.03, -0.02, -0.01, 0.0, 0.01, 0.02, 0.03, 0.05, 0.08, 0.12]:
    v = t1(lambda r, bb=bb: r["A"] + r["D"] - bb * r["length"])
    print(f"  {bb:+.3f}     {v:.4f}")
print("  -> the 'contribution of length' is a FREE PARAMETER of an arbitrary gauge choice.")

print("\n=== (2) PER-EXAMPLE length basis (a plausible mis-parameterization) ===")
# Model's length MLP is GLOBAL/shared. If the auditor fit a length function with
# per-example freedom, it can absorb nearly all the signal.
col = 0
ri, ci, vv, yy, meta = [], [], [], [], []
rid = 0
for r in rows:
    ua = {p: col + i for i, p in enumerate(sorted(set(r["acc"].tolist())))}; col += len(ua)
    ud = {p: col + i for i, p in enumerate(sorted(set(r["don"].tolist())))}; col += len(ud)
    ul = {p: col + i for i, p in enumerate(sorted(set(r["length"].tolist())))}; col += len(ul)
    meta.append((ua, ud, ul))
    y = r["A"] + r["D"] + r["L"]
    for k in range(len(y)):
        ri += [rid, rid, rid]
        ci += [ua[int(r["acc"][k])], ud[int(r["don"][k])], ul[int(r["length"][k])]]
        vv += [1.0, 1.0, 1.0]
        yy.append(y[k]); rid += 1
X = coo_matrix((np.array(vv), (np.array(ri), np.array(ci))), shape=(rid, col)).tocsr()
sol = lsqr(X, np.array(yy), atol=1e-12, btol=1e-12, iter_lim=3000)[0]
print(f"  fit RMSE = {np.sqrt(((X@sol - np.array(yy))**2).mean()):.6f}  (still 'proves' additivity)")
hits_full = hits_abl = 0
for i, r in enumerate(rows):
    ua, ud, ul = meta[i]
    f = np.array([sol[ua[int(p)]] for p in r["acc"]])
    g = np.array([sol[ud[int(p)]] for p in r["don"]])
    Lh = np.array([sol[ul[int(p)]] for p in r["length"]])
    hits_full += int(np.argmax(f + g + Lh) == r["t"])
    hits_abl += int(np.argmax(f + g) == r["t"])
print(f"  top1 reconstructed full      = {hits_full/n:.4f}  (sanity: matches ground truth)")
print(f"  top1 'length-ablated' this way = {hits_abl/n:.4f}   <-- finding reports 0.5525")

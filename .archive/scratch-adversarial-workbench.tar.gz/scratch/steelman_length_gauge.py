"""Steelman check on the 'length is worth 25 PMR points' finding.

Key facts established from code:
  * PairCandidate.exon_length == donor_pos - acceptor_pos  (schema.py:59-61)
    => L is an EXACT function of (a, d).
  * AdditivePairReadout.length is an MLP on (log L, sqrt L) ONLY (readout.py:100-109),
    with weights saved in the checkpoint.  So the model's own length term is
    computable EXACTLY from the checkpoint alone, with no backbone forward pass.

So we can ablate the model's ACTUAL length head from the saved logits:
    score_noL(a,d) = logit(a,d) - MLP_len(L(a,d))
No least squares, no gauge ambiguity.

We then reproduce the finding's least-squares recovery and show it is
NON-IDENTIFIED: because L = d - a, the additive family f(a)+g(d)+h(L) admits the
exact gauge transform
    f(a) -> f(a) + c*a,   g(d) -> g(d) - c*d,   h(L) -> h(L) + c*L
which leaves every pair score unchanged (age-period-cohort degeneracy).  Hence
"drop the recovered length term" measures the solver's gauge, not the model.
"""
from __future__ import annotations
import json, math, sys
import numpy as np
import torch
from torch import nn

ROOT = "/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation"
CK = f"{ROOT}/colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt"
LOGITS = f"{ROOT}/results/splicebert_partner_selection/behavior/seed0_additive-frozen/val/val_local_conflicts/per_example_clean.jsonl"
CONF = f"{ROOT}/results/splicebert_partner_selection/baselines/val_local_conflicts.jsonl"

N = int(sys.argv[1]) if len(sys.argv) > 1 else 1200

# ---- model length head (exact) -------------------------------------------
ck = torch.load(CK, map_location="cpu", weights_only=False)
spec = ck["readout_spec"]
length_hidden = spec["length_hidden"]
lh = nn.Sequential(nn.Linear(2, length_hidden), nn.GELU(), nn.Linear(length_hidden, 1))
sd = {k[len("length."):]: v for k, v in ck["readout_state"].items() if k.startswith("length.")}
lh.load_state_dict(sd)
lh.eval()

@torch.no_grad()
def lterm(lengths: np.ndarray) -> np.ndarray:
    x = torch.tensor(lengths, dtype=torch.float32).clamp_min(1.0)
    feats = torch.stack((torch.log(x), torch.sqrt(x)), dim=-1)
    return lh(feats).squeeze(-1).numpy().astype(np.float64)

# ---- load logits ----------------------------------------------------------
want = {}
order = []
with open(LOGITS) as f:
    for line in f:
        d = json.loads(line)
        want[d["example_id"]] = d
        order.append(d["example_id"])
        if len(order) >= N:
            break
want_ids = set(order)

pairs_by_id = {}
with open(CONF) as f:
    for line in f:
        d = json.loads(line)
        if d["example_id"] in want_ids:
            pairs_by_id[d["example_id"]] = d
        if len(pairs_by_id) == len(want_ids):
            break

print(f"matched {len(pairs_by_id)}/{len(want_ids)} examples")

def top1(scores, ti):
    return int(np.argmax(scores) == ti)

def pmr(scores, ti):
    s = scores.copy()
    t = s[ti]
    s[ti] = -np.inf
    return int(t > s.max())

res = {k: [] for k in ["full_t1", "full_pmr", "noL_t1", "noL_pmr"]}
lsq = {"rmse": [], "t1_dropL": [], "pmr_dropL": [], "t1_full": []}
gauge_curve = {}
GAMMAS = [-0.30, -0.20, -0.10, -0.05, -0.02, 0.0, 0.02, 0.05, 0.10, 0.20, 0.30]
for g in GAMMAS:
    gauge_curve[g] = []
resid_gauge = []
true_gauge_t1 = []

for ex_id in order:
    ex = pairs_by_id[ex_id]
    rec = want[ex_id]
    pairs = ex["pairs"]
    ti = int(rec["true_pair_index"])
    assert ti == int(ex["true_pair_index"])
    logits = np.asarray(rec["logits"], dtype=np.float64)
    assert len(logits) == len(pairs), (len(logits), len(pairs))
    a = np.asarray([p["acceptor_pos"] for p in pairs], dtype=np.float64)
    d = np.asarray([p["donor_pos"] for p in pairs], dtype=np.float64)
    L = d - a
    # sanity: schema exon_length
    Lt = lterm(L)

    res["full_t1"].append(top1(logits, ti))
    res["full_pmr"].append(pmr(logits, ti))
    noL = logits - Lt
    res["noL_t1"].append(top1(noL, ti))
    res["noL_pmr"].append(pmr(noL, ti))

    # ---- least-squares recovery (the finding's method), free bins ----------
    ua, ia = np.unique(a, return_inverse=True)
    ud, id_ = np.unique(d, return_inverse=True)
    uL, iL = np.unique(L, return_inverse=True)
    P = len(pairs)
    X = np.zeros((P, len(ua) + len(ud) + len(uL)))
    X[np.arange(P), ia] = 1.0
    X[np.arange(P), len(ua) + id_] = 1.0
    X[np.arange(P), len(ua) + len(ud) + iL] = 1.0
    beta, *_ = np.linalg.lstsq(X, logits, rcond=None)  # min-norm solution
    pred = X @ beta
    lsq["rmse"].append(float(np.sqrt(np.mean((pred - logits) ** 2))))
    f_hat = beta[: len(ua)][ia]
    g_hat = beta[len(ua): len(ua) + len(ud)][id_]
    h_hat = beta[len(ua) + len(ud):][iL]
    lsq["t1_full"].append(top1(f_hat + g_hat + h_hat, ti))
    drop = f_hat + g_hat
    lsq["t1_dropL"].append(top1(drop, ti))
    lsq["pmr_dropL"].append(pmr(drop, ti))

    # ---- gauge sweep: exact reparameterisation, identical fit --------------
    for gam in GAMMAS:
        fg = f_hat + gam * a
        gg = g_hat - gam * d
        hg = h_hat + gam * L
        if gam == GAMMAS[0]:
            resid_gauge.append(float(np.max(np.abs((fg + gg + hg) - (f_hat + g_hat + h_hat)))))
        gauge_curve[gam].append(top1(fg + gg, ti))

    # ---- the TRUE gauge: use the model's own length head -------------------
    # f+g in the model's gauge is exactly logits - Lt (computed above)
    true_gauge_t1.append(top1(logits - Lt, ti))

n = len(order)
print(f"\nN = {n} conflict examples (seed0 additive-frozen, saved clean logits)")
print("\n[A] EXACT ablation of the model's OWN length head (checkpoint MLP on (logL,sqrtL)):")
print(f"  full  top1 = {np.mean(res['full_t1']):.4f}   PMR = {np.mean(res['full_pmr']):.4f}")
print(f"  no-L  top1 = {np.mean(res['noL_t1']):.4f}   PMR = {np.mean(res['noL_pmr']):.4f}")
print(f"  DELTA top1 = {np.mean(res['full_t1']) - np.mean(res['noL_t1']):+.4f}")

print("\n[B] Least-squares recovery (the finding's method), min-norm gauge:")
print(f"  median residual RMSE = {np.median(lsq['rmse']):.6f}   (fit is essentially exact)")
print(f"  reconstructed full top1 = {np.mean(lsq['t1_full']):.4f}")
print(f"  drop recovered length term: top1 = {np.mean(lsq['t1_dropL']):.4f}  PMR = {np.mean(lsq['pmr_dropL']):.4f}")

print("\n[C] Gauge sweep. f->f+c*a, g->g-c*d, h->h+c*L leaves EVERY pair score identical.")
print(f"  max |score change| under reparameterisation = {max(resid_gauge):.3e}")
print("  'drop the length term' top1 as a function of the (arbitrary) gauge c:")
for gam in GAMMAS:
    print(f"    c = {gam:+.2f}   top1(f+g) = {np.mean(gauge_curve[gam]):.4f}")
print(f"\n  model's TRUE gauge (its own length head): top1(f+g) = {np.mean(true_gauge_t1):.4f}")

json.dump(
    {
        "n": n,
        "exact_full_top1": float(np.mean(res["full_t1"])),
        "exact_full_pmr": float(np.mean(res["full_pmr"])),
        "exact_noL_top1": float(np.mean(res["noL_t1"])),
        "exact_noL_pmr": float(np.mean(res["noL_pmr"])),
        "lsq_median_rmse": float(np.median(lsq["rmse"])),
        "lsq_full_top1": float(np.mean(lsq["t1_full"])),
        "lsq_dropL_top1": float(np.mean(lsq["t1_dropL"])),
        "lsq_dropL_pmr": float(np.mean(lsq["pmr_dropL"])),
        "gauge_curve": {str(k): float(np.mean(v)) for k, v in gauge_curve.items()},
    },
    open(f"{ROOT}/scratch/steelman_length_gauge_results.json", "w"),
    indent=2,
)

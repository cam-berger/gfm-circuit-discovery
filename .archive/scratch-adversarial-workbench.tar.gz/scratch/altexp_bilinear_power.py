"""Two controls the finding omits:
 (A) additive-R^2 of the bilinear interaction term at RANDOM INIT vs TRAINED.
 (B) POSITIVE CONTROL: can BilinearPairReadout recover a partner-specific
     interaction that is KNOWN to exist, on the SAME frozen SpliceBERT reps?
"""
from __future__ import annotations
import json, sys, math
from pathlib import Path
import torch
from torch import nn

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))
from gfmcd.adapters.splicebert import SpliceBertAdapter
from gfmcd.splicing.config import load_config
from gfmcd.splicing.schema import SplicePairExample
from gfmcd.splicing.readout import AdditivePairReadout, BilinearPairReadout, PairIndexBatch, collate_pair_indices
from gfmcd.splicing.training import load_pair_checkpoint

torch.manual_seed(0)
N_EX, BATCH = 1200, 8
dev = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"]); mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode","auto"),
    device=dev, trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class","masked_lm"))

examples = []
with (REPO/"colab_results/splicebert_run/baselines/val_local_conflicts.jsonl").open() as f:
    for line in f:
        if line.strip():
            examples.append(SplicePairExample.from_json(line))
            if len(examples) >= N_EX: break
print(f"loaded {len(examples)} conflict examples", flush=True)

# ---- cache hidden states at candidate pair endpoints (frozen backbone) ----
cache = []
for i in range(0, len(examples), BATCH):
    ex = examples[i:i+BATCH]
    tok = adapter.tokenize([x.sequence for x in ex])
    pb = collate_pair_indices(ex, token_offset=tok.prefix_tokens, device=adapter.device)
    with torch.no_grad():
        hid = adapter.forward(tok, output_hidden_states=True, output_attentions=False).hidden_states[rep]
    b = torch.arange(hid.shape[0], device=hid.device)[:, None]
    HA = hid[b, pb.positions[...,0]].float().cpu()   # [B,P,512]
    HD = hid[b, pb.positions[...,1]].float().cpu()
    for k, x in enumerate(ex):
        m = pb.mask[k].cpu()
        cache.append(dict(
            ha=HA[k][m].clone(), hd=HD[k][m].clone(),
            length=pb.lengths[k].cpu()[m].clone(),
            ai=torch.tensor([p.acceptor_index for p in x.pairs]),
            di=torch.tensor([p.donor_index for p in x.pairs]),
            t=int(x.true_pair_index),
        ))
    if i % 400 == 0: print(f"  cached {i}", flush=True)
print(f"cached {len(cache)} examples; mean pairs {sum(len(c['length']) for c in cache)/len(cache):.1f}", flush=True)

def additive_fit(y, ai, di):
    """OLS fit of u[a]+v[d]+c to y over the example's candidate pairs; return R^2 and residual."""
    na, nd = int(ai.max())+1, int(di.max())+1
    X = torch.zeros(len(y), na+nd+1)
    X[torch.arange(len(y)), ai] = 1.0
    X[torch.arange(len(y)), na+di] = 1.0
    X[:, -1] = 1.0
    sol = torch.linalg.lstsq(X, y.unsqueeze(1)).solution
    pred = (X @ sol).squeeze(1)
    ss_res = ((y-pred)**2).sum(); ss_tot = ((y-y.mean())**2).sum()
    r2 = float(1 - ss_res/ss_tot) if ss_tot > 1e-9 else float("nan")
    return r2, (y - pred)

def interaction_term(mod, ha, hd):
    return (mod.left(mod.left_norm(ha)) * mod.right(mod.right_norm(hd))).sum(-1) * mod.scale + mod.interaction_bias

# ================= CONTROL A: trained vs RANDOM-INIT additive-R^2 =================
print("\n=== CONTROL A: additive-R^2 of the interaction term (trained vs random init) ===", flush=True)
sub = cache[:400]
for name in ["random-init", "seed0", "seed1", "seed2"]:
    mod = BilinearPairReadout(512, interaction_rank=32)
    if name != "random-init":
        ck = torch.load(REPO/f"colab_results/splicebert_run/runs/interaction-frozen_{name}/checkpoint.pt",
                        map_location="cpu", weights_only=False)
        mod.load_state_dict(ck["readout_state"])
    mod.eval()
    r2s = []
    with torch.no_grad():
        for c in sub:
            y = interaction_term(mod, c["ha"], c["hd"])
            r2, _ = additive_fit(y, c["ai"], c["di"])
            if not math.isnan(r2): r2s.append(r2)
    r2s = torch.tensor(r2s)
    print(f"  {name:12s} additive-R^2 of interaction term: mean {r2s.mean():.4f}  median {r2s.median():.4f}  p5 {r2s.quantile(0.05):.4f}", flush=True)

#!/usr/bin/env python
"""REFEREE data-check of the finding:
   'true_pair_margin is ~100% a DONOR score and is causally blind to the true acceptor'.

Independent reimplementation (does not reuse the lens agent's script). Runs on the
EXACT split the tracing pipeline uses: results/.../circuits/discovery/confirmation.jsonl
(full 512), additive-frozen seed0 + seed1 local checkpoints.

Measures:
  (1) top-decoy composition (shares true acceptor / true donor / neither)
  (2) margin decomposition into dA, dD, dL  (must sum exactly to margin)
  (3) exact-cancellation rate: frac of examples with dA == 0 EXACTLY
  (4) base rate of shared-acceptor decoys in the candidate pool
  (5) STEELMAN / slack test: margin = min(m_shared, m_other) where
        m_shared = true - max decoy sharing a*   (INVARIANT to f(h_a*))
        m_other  = true - max decoy with a != a* (falls 1:1 with f(h_a*))
      slack = m_other - m_shared = how far f(h_a*) can fall before the margin
      even starts to move. Large slack => margin genuinely blind to h_a*.
  (6) CAUSAL check: under the pipeline's own acceptor-mask corruption, how much
      does f(h_a*) actually move, and does the margin move?
"""
from __future__ import annotations

import json
from pathlib import Path
import sys

import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))

from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.io import load_jsonl  # noqa: E402
from gfmcd.splicing.readout import collate_pair_indices, true_pair_margin  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint  # noqa: E402
from gfmcd.splicing.context_controls import mask_true_partner_neighborhood  # noqa: E402

BATCH = 8
device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"])
mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))

EX = load_jsonl(REPO / "results/splicebert_partner_selection/circuits/discovery/confirmation.jsonl")
print(f"confirmation split: n={len(EX)}  device={device}  rep_layer={rep}")

out: dict = {"n": len(EX), "rep_layer": rep, "seeds": {}}


def terms(readout, hidden, pb):
    """Return (A, D, L) per candidate pair, each [B,P]; A+D+L == readout.forward (unmasked)."""
    b = torch.arange(hidden.shape[0], device=hidden.device)[:, None]
    ha = hidden[b, pb.positions[..., 0]]
    hd = hidden[b, pb.positions[..., 1]]
    A = readout.acceptor(ha).squeeze(-1)
    D = readout.donor(hd).squeeze(-1)
    L = readout.length(readout._length_features(pb.lengths)).squeeze(-1)
    return A, D, L


for seed in (0, 1):
    ck = REPO / f"colab_results/splicebert_run/runs/additive-frozen_seed{seed}/checkpoint.pt"
    readout, checkpoint = load_pair_checkpoint(ck, adapter=adapter)
    meta = checkpoint.get("extra_metadata", {})
    assert meta.get("regime") == "additive-frozen", meta
    assert checkpoint.get("backbone_state") is None
    readout.eval()

    rec = {
        "identity_max_err": 0.0,
        "shares_acc": 0, "shares_don": 0, "neither": 0, "shares_both": 0,
        "margins": [], "dA": [], "dD": [], "dL": [],
        "exact_zero_dA": 0,
        "pool_shared_acc_frac": [], "pool_shared_don_frac": [],
        "slack": [], "m_shared": [], "m_other": [],
        "fA_clean": [], "fA_accmask": [], "margin_clean": [], "margin_accmask": [],
        "fD_clean": [], "fD_donmask": [], "margin_donmask": [],
        "pmr_full": 0,
    }

    for i in range(0, len(EX), BATCH):
        ex = EX[i:i + BATCH]
        with torch.no_grad():
            tok = adapter.tokenize([x.sequence for x in ex])
            pb = collate_pair_indices(ex, token_offset=tok.prefix_tokens, device=adapter.device)
            h = adapter.forward(tok, output_hidden_states=True).hidden_states[rep]
            A, D, L = terms(readout, h, pb)
            logits_full = readout(h, pb)
            m_ref = true_pair_margin(logits_full, pb)
            raw = A + D + L
            err = (raw - logits_full).abs()[pb.mask].max().item()
            rec["identity_max_err"] = max(rec["identity_max_err"], err)

            # acceptor-mask + donor-mask corruptions (pipeline's own controls)
            tok_am = adapter.tokenize([mask_true_partner_neighborhood(x, kind="acceptor", flank=12) for x in ex])
            h_am = adapter.forward(tok_am, output_hidden_states=True).hidden_states[rep]
            A_am, D_am, L_am = terms(readout, h_am, pb)
            m_am = true_pair_margin(readout(h_am, pb), pb)

            tok_dm = adapter.tokenize([mask_true_partner_neighborhood(x, kind="donor", flank=12) for x in ex])
            h_dm = adapter.forward(tok_dm, output_hidden_states=True).hidden_states[rep]
            m_dm = true_pair_margin(readout(h_dm, pb), pb)

        NEG = torch.finfo(logits_full.dtype).min
        for bi, x in enumerate(ex):
            t = x.true_pair_index
            mask = pb.mask[bi]
            lg = logits_full[bi].clone()
            lg[~mask] = NEG
            lg[t] = NEG
            dj = int(lg.argmax())
            tp, dp = x.pairs[t], x.pairs[dj]

            sa = dp.acceptor_pos == tp.acceptor_pos
            sd = dp.donor_pos == tp.donor_pos
            if sa and sd:
                rec["shares_both"] += 1
            elif sa:
                rec["shares_acc"] += 1
            elif sd:
                rec["shares_don"] += 1
            else:
                rec["neither"] += 1

            marg = float(logits_full[bi, t] - logits_full[bi, dj])
            dA = float(A[bi, t] - A[bi, dj])
            dD = float(D[bi, t] - D[bi, dj])
            dL = float(L[bi, t] - L[bi, dj])
            rec["margins"].append(marg); rec["dA"].append(dA); rec["dD"].append(dD); rec["dL"].append(dL)
            if dA == 0.0:
                rec["exact_zero_dA"] += 1
            if marg > 0:
                rec["pmr_full"] += 1

            # pool base rates
            npairs = len(x.pairs)
            n_sa = sum(1 for p in x.pairs if p.acceptor_pos == tp.acceptor_pos) - 1
            n_sd = sum(1 for p in x.pairs if p.donor_pos == tp.donor_pos) - 1
            rec["pool_shared_acc_frac"].append(n_sa / (npairs - 1))
            rec["pool_shared_don_frac"].append(n_sd / (npairs - 1))

            # slack test
            shared_idx = [k for k, p in enumerate(x.pairs)
                          if k != t and p.acceptor_pos == tp.acceptor_pos]
            other_idx = [k for k, p in enumerate(x.pairs)
                         if k != t and p.acceptor_pos != tp.acceptor_pos]
            ms = float(logits_full[bi, t] - logits_full[bi, shared_idx].max()) if shared_idx else float("inf")
            mo = float(logits_full[bi, t] - logits_full[bi, other_idx].max()) if other_idx else float("inf")
            rec["m_shared"].append(ms); rec["m_other"].append(mo); rec["slack"].append(mo - ms)

            rec["fA_clean"].append(float(A[bi, t])); rec["fA_accmask"].append(float(A_am[bi, t]))
            rec["fD_clean"].append(float(D[bi, t]))
            rec["margin_clean"].append(float(m_ref[bi]))
            rec["margin_accmask"].append(float(m_am[bi]))
            rec["margin_donmask"].append(float(m_dm[bi]))

    n = len(EX)
    mean = lambda v: sum(v) / len(v)
    mm = mean(rec["margins"])
    res = {
        "identity_max_err": rec["identity_max_err"],
        "pmr_full": rec["pmr_full"] / n,
        "top_decoy_shares_true_acceptor": rec["shares_acc"] / n,
        "top_decoy_shares_true_donor": rec["shares_don"] / n,
        "top_decoy_shares_neither": rec["neither"] / n,
        "top_decoy_shares_both": rec["shares_both"] / n,
        "pool_base_rate_shared_acceptor": mean(rec["pool_shared_acc_frac"]),
        "pool_base_rate_shared_donor": mean(rec["pool_shared_don_frac"]),
        "mean_margin": mm,
        "mean_dA": mean(rec["dA"]), "mean_dD": mean(rec["dD"]), "mean_dL": mean(rec["dL"]),
        "share_dA": mean(rec["dA"]) / mm, "share_dD": mean(rec["dD"]) / mm,
        "share_dL": mean(rec["dL"]) / mm,
        "frac_dA_exactly_zero": rec["exact_zero_dA"] / n,
        "mean_slack_mother_minus_mshared": mean([s for s in rec["slack"] if s != float("inf")]),
        "median_slack": sorted([s for s in rec["slack"] if s != float("inf")])[n // 2],
        "frac_slack_gt_0": sum(1 for s in rec["slack"] if s > 0) / n,
        "mean_delta_fA_under_acceptor_mask": mean(rec["fA_accmask"]) - mean(rec["fA_clean"]),
        "mean_abs_delta_fA_under_acceptor_mask": mean(
            [abs(a - b) for a, b in zip(rec["fA_accmask"], rec["fA_clean"])]),
        "acceptor_mask_gap_clean_minus_corrupt": mean(rec["margin_clean"]) - mean(rec["margin_accmask"]),
        "donor_mask_gap_clean_minus_corrupt": mean(rec["margin_clean"]) - mean(rec["margin_donmask"]),
        "mean_margin_clean": mean(rec["margin_clean"]),
    }
    out["seeds"][seed] = res
    print(f"\n=== seed{seed} ===")
    for k, v in res.items():
        print(f"  {k:48s} {v:.4f}" if isinstance(v, float) else f"  {k:48s} {v}")

(REPO / "scratch/ref_datacheck_acceptor_blind.json").write_text(json.dumps(out, indent=2))
print("\nwrote scratch/ref_datacheck_acceptor_blind.json")

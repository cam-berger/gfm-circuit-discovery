#!/usr/bin/env python
"""ALT-EXPLANATION test for the 'length is worth 25 PMR points' finding.

The finding recovered f, g, L from SAVED LOGITS by least squares, then ablated L.
But exon_length == donor_pos - acceptor_pos EXACTLY (schema.py:60). So the
decomposition score = f(a) + g(d) + L(len) has an EXACT gauge freedom:

    L_b(len) = L(len) + b*len ;  f_b(a) = f(a) + b*a ;  g_b(d) = g(d) - b*d
    =>  f_b(a) + g_b(d) + L_b(len) == f(a) + g(d) + L(len)   for every pair.

Every logit is bit-identical, but the ABLATION "drop the length term" gives
    f_b + g_b = (f + g) - b*len
which is an ARBITRARY linear-in-length function. So the ablated accuracy is a
property of the gauge, not the model.

This script:
 (1) gets the GROUND-TRUTH A, D, Lterm from the actual readout submodules;
 (2) redoes the finding's least-squares recovery from logits alone;
 (3) compares recovered L_hat to true Lterm, extracts the gauge drift b;
 (4) sweeps b and shows the ablated top1 spans the whole range.
"""
from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np
import torch
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import lsqr

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))

from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.schema import SplicePairExample  # noqa: E402
from gfmcd.splicing.readout import collate_pair_indices  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint  # noqa: E402

N = 250
BATCH = 8

device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"])
mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
readout, checkpoint = load_pair_checkpoint(
    REPO / "colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt", adapter=adapter)
print("regime:", checkpoint.get("extra_metadata", {}).get("regime"),
      "| backbone_state is None:", checkpoint.get("backbone_state") is None)

examples: list[SplicePairExample] = []
with (REPO / "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl").open() as f:
    for line in f:
        if line.strip():
            examples.append(SplicePairExample.from_json(line))
        if len(examples) >= N:
            break
print(f"loaded {len(examples)} conflict examples")

rows = []
for i in range(0, len(examples), BATCH):
    ex = examples[i:i + BATCH]
    tok = adapter.tokenize([x.sequence for x in ex])
    pb = collate_pair_indices(ex, token_offset=tok.prefix_tokens, device=adapter.device)
    with torch.no_grad():
        hidden = adapter.forward(tok, output_hidden_states=True, output_attentions=False).hidden_states[rep]
        b = torch.arange(hidden.shape[0], device=hidden.device)[:, None]
        A = readout.acceptor(hidden[b, pb.positions[..., 0]]).squeeze(-1).float().cpu()
        D = readout.donor(hidden[b, pb.positions[..., 1]]).squeeze(-1).float().cpu()
        Lt = readout.length(readout._length_features(pb.lengths)).squeeze(-1).float().cpu()
    mask = pb.mask.cpu()
    for k, x in enumerate(ex):
        m = mask[k]
        rows.append(dict(
            A=A[k][m].numpy().astype(np.float64),
            D=D[k][m].numpy().astype(np.float64),
            L=Lt[k][m].numpy().astype(np.float64),
            acc=np.array([p.acceptor_pos for p in x.pairs], dtype=np.int64),
            don=np.array([p.donor_pos for p in x.pairs], dtype=np.int64),
            length=np.array([p.exon_length for p in x.pairs], dtype=np.int64),
            t=x.true_pair_index,
        ))
    print(f"  {len(rows)}/{N}", end="\r")
print()


def top1(scores_fn):
    hits = 0
    for r in rows:
        s = scores_fn(r)
        hits += int(int(np.argmax(s)) == r["t"])
    return hits / len(rows)


def donor_marginal(scores_fn):
    """fraction of examples whose ARGMAX pair carries the true donor position"""
    hits = 0
    for r in rows:
        j = int(np.argmax(scores_fn(r)))
        hits += int(r["don"][j] == r["don"][r["t"]])
    return hits / len(rows)


print("\n=== GROUND TRUTH (actual readout submodules) ===")
gt_full = top1(lambda r: r["A"] + r["D"] + r["L"])
gt_nolen = top1(lambda r: r["A"] + r["D"])
print(f"  top1 full (A+D+Lterm)        = {gt_full:.4f}")
print(f"  top1 length-ABLATED (A+D)    = {gt_nolen:.4f}   <-- TRUE cost of dropping length")
print(f"  donor marginal, full          = {donor_marginal(lambda r: r['A']+r['D']+r['L']):.4f}")
print(f"  donor marginal, length-ablated= {donor_marginal(lambda r: r['A']+r['D']):.4f}")

# ---------------------------------------------------------------- least squares
# Pooled fit: per-(example, acceptor_pos) free param, per-(example, donor_pos) free
# param, GLOBAL per-length param. Exactly the structure the model has.
print("\n=== REPRODUCING THE FINDING'S LEAST-SQUARES RECOVERY (logits only) ===")
LMIN, LMAX = 20, 500
nlen = LMAX - LMIN + 1
col = 0
ri, ci, vv, yy = [], [], [], []
acc_cols, don_cols = [], []
row_id = 0
for r in rows:
    ua = {p: col + i for i, p in enumerate(sorted(set(r["acc"].tolist())))}
    col += len(ua)
    ud = {p: col + i for i, p in enumerate(sorted(set(r["don"].tolist())))}
    col += len(ud)
    acc_cols.append(ua)
    don_cols.append(ud)
    y = r["A"] + r["D"] + r["L"]          # <- the SAVED LOGIT. no module access.
    for k in range(len(y)):
        ri += [row_id, row_id, row_id]
        ci += [ua[int(r["acc"][k])], ud[int(r["don"][k])], -1]  # -1 patched below
        vv += [1.0, 1.0, 1.0]
        yy.append(y[k])
        row_id += 1
LEN_BASE = col
ci = np.array(ci)
k = 0
for r in rows:
    for kk in range(len(r["A"])):
        ci[3 * k + 2] = LEN_BASE + int(r["length"][kk]) - LMIN
        k += 1
ncol = LEN_BASE + nlen
Xs = coo_matrix((np.array(vv), (np.array(ri), ci)), shape=(row_id, ncol)).tocsr()
yv = np.array(yy)
print(f"  design: {row_id} rows x {ncol} cols (rank-deficient by construction)")
sol = lsqr(Xs, yv, atol=1e-12, btol=1e-12, iter_lim=4000)[0]  # min-norm LS solution
resid = Xs @ sol - yv
print(f"  fit RMSE = {np.sqrt((resid**2).mean()):.6f}  (matches finding's ~0.0001 'proof of additivity')")

L_hat = sol[LEN_BASE:]
# TRUE length function from the module, on the same grid
with torch.no_grad():
    grid = torch.arange(LMIN, LMAX + 1, dtype=torch.float32, device=adapter.device)
    L_true = readout.length(readout._length_features(grid)).squeeze(-1).float().cpu().numpy().astype(np.float64)

# which lengths actually occur (weight the comparison by real candidate mass)
occ = np.zeros(nlen)
for r in rows:
    for lv in r["length"]:
        occ[int(lv) - LMIN] += 1
sel = occ > 0
d = L_hat[sel] - L_true[sel]
xs = np.arange(LMIN, LMAX + 1)[sel].astype(np.float64)
w = occ[sel]
# weighted slope of the discrepancy => the gauge drift b
bslope = np.polyfit(xs, d, 1, w=np.sqrt(w))[0]
print(f"\n  recovered L_hat vs TRUE Lterm:")
print(f"    weighted slope of (L_hat - Lterm) on len : b = {bslope:+.6f}  <-- gauge drift")
print(f"    (b == 0 would mean lstsq happened to land on the model's own gauge)")
resid_after = d - np.polyval(np.polyfit(xs, d, 1, w=np.sqrt(w)), xs)
print(f"    weighted SD of (L_hat - Lterm)            : {np.sqrt(np.average(d**2, weights=w)):.4f}")
print(f"    weighted SD after removing the linear gauge: {np.sqrt(np.average(resid_after**2, weights=w)):.4f}")
print(f"    (true Lterm weighted SD across candidates  : {np.sqrt(np.average((L_true[sel]-np.average(L_true[sel],weights=w))**2, weights=w)):.4f})")

# the finding's ablation: drop L_hat, keep f_hat + g_hat
def fg_hat(r, idx):
    ua, ud = acc_cols[idx], don_cols[idx]
    f = np.array([sol[ua[int(p)]] for p in r["acc"]])
    g = np.array([sol[ud[int(p)]] for p in r["don"]])
    return f + g

fg = [fg_hat(r, i) for i, r in enumerate(rows)]
lstsq_full = sum(int(np.argmax(fg[i] + L_hat[rows[i]["length"] - LMIN]) == rows[i]["t"]) for i in range(len(rows))) / len(rows)
lstsq_nolen = sum(int(np.argmax(fg[i]) == rows[i]["t"]) for i in range(len(rows))) / len(rows)
print(f"\n  top1 reconstructed full (f_hat+g_hat+L_hat) = {lstsq_full:.4f}  (sanity: == ground truth)")
print(f"  top1 length-ABLATED the FINDING's way       = {lstsq_nolen:.4f}  <-- the finding reports 0.5525")

# ---------------------------------------------------------------- gauge sweep
print("\n=== GAUGE SWEEP: every b below produces IDENTICAL model logits ===")
print("     b        top1 after 'dropping the length term'")
for bb in [-0.02, -0.01, -0.005, 0.0, bslope, 0.005, 0.01, 0.02, 0.03]:
    v = sum(int(np.argmax(fg[i] - bb * rows[i]["length"]) == rows[i]["t"]) for i in range(len(rows))) / len(rows)
    tag = "  <- lstsq's arbitrary choice" if bb == 0.0 else ("  <- gauge that matches the model" if bb == bslope else "")
    print(f"  {bb:+.5f}   {v:.4f}{tag}")

out = REPO / "scratch/altexp_length_gauge_results.json"
out.write_text(json.dumps(dict(
    n=len(rows), gt_top1_full=gt_full, gt_top1_length_ablated=gt_nolen,
    lstsq_top1_full=lstsq_full, lstsq_top1_length_ablated=lstsq_nolen,
    fit_rmse=float(np.sqrt((resid**2).mean())), gauge_drift_b=float(bslope),
), indent=2))
print("\nwrote", out)

"""ALT-EXPLANATION: is random-backbone acceptor-argmax=1.0 SITE DETECTION or POSITION READING?
Test: replace the sequence with random nucleotides (candidate positions preserved).
A site detector must collapse. A position detector is unaffected."""
from __future__ import annotations
import sys, random
from pathlib import Path
import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))
from gfmcd.adapters.splicebert import SpliceBertAdapter
from gfmcd.splicing.config import load_config
from gfmcd.splicing.schema import SplicePairExample
from gfmcd.splicing.readout import collate_pair_indices
from gfmcd.splicing.training import load_pair_checkpoint

N, BATCH = 200, 8
device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"]); mc = cfg["model"]

examples = []
with (REPO / "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl").open() as f:
    for line in f:
        if line.strip(): examples.append(SplicePairExample.from_json(line))
        if len(examples) >= N: break

# structural facts
acc200 = sum(1 for e in examples if e.pairs[e.true_pair_index].acceptor_pos == 200)
donend = sum(1 for e in examples if len(e.sequence) - e.pairs[e.true_pair_index].donor_pos == 200)
print(f"[data] true acceptor at token 200: {acc200}/{len(examples)} | true donor at len-200: {donend}/{len(examples)}")
# is 200 always among acceptor candidates, and is true acceptor the candidate CLOSEST to 200?
closest = 0
for e in examples:
    accs = sorted({p.acceptor_pos for p in e.pairs})
    tp = e.pairs[e.true_pair_index]
    if min(accs, key=lambda a: abs(a - 200)) == tp.acceptor_pos: closest += 1
print(f"[data] true acceptor is the candidate CLOSEST to token 200: {closest}/{len(examples)}")

rng = random.Random(0)
def randomize_seq(s): return "".join(rng.choice("ACGT") for _ in s)

for regime in ("additive-frozen", "additive-random-frozen"):
    adapter = SpliceBertAdapter.from_pretrained(
        REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode","auto"), device=device,
        trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class","masked_lm"))
    readout, ck = load_pair_checkpoint(REPO / f"colab_results/splicebert_run/runs/{regime}_seed0/checkpoint.pt", adapter=adapter)
    for cond in ("real-seq", "RANDOM-seq"):
        na = nd = npmr = 0; dist_agree = 0
        for i in range(0, len(examples), BATCH):
            eb = examples[i:i+BATCH]
            seqs = [e.sequence if cond=="real-seq" else randomize_seq(e.sequence) for e in eb]
            tok = adapter.tokenize(seqs)
            pb = collate_pair_indices(eb, token_offset=tok.prefix_tokens, device=adapter.device)
            with torch.no_grad():
                h = adapter.forward(tok, output_hidden_states=True).hidden_states[rep]
                b = torch.arange(h.shape[0], device=h.device)[:, None]
                A = readout.acceptor(h[b, pb.positions[...,0]]).squeeze(-1).float().cpu()
                D = readout.donor(h[b, pb.positions[...,1]]).squeeze(-1).float().cpu()
                Lt = readout.length(readout._length_features(pb.lengths)).squeeze(-1).float().cpu()
            m = pb.mask.cpu(); pos = pb.positions.cpu(); off = tok.prefix_tokens
            full = A + D + Lt
            for k, e in enumerate(eb):
                sa, sd = {}, {}
                for p in range(m.shape[1]):
                    if m[k,p]:
                        sa[int(pos[k,p,0])-off] = float(A[k,p]); sd[int(pos[k,p,1])-off] = float(D[k,p])
                tp = e.pairs[e.true_pair_index]
                amax = max(sa, key=sa.get)
                na += int(amax == tp.acceptor_pos)
                nd += int(max(sd, key=sd.get) == tp.donor_pos)
                dist_agree += int(amax == min(sa, key=lambda a: abs(a-200)))
                s = full[k].clone(); s[~m[k]] = -1e30
                tv = float(s[e.true_pair_index]); s[e.true_pair_index] = -1e30
                npmr += int(tv > float(s.max()))
        n = len(examples)
        print(f"{regime:24s} {cond:11s} acc-argmax {na/n:.4f} | don-argmax {nd/n:.4f} | PMR {npmr/n:.4f} | acc-argmax==closest-to-200 {dist_agree/n:.4f}")

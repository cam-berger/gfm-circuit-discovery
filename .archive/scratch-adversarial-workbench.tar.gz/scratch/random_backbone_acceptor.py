#!/usr/bin/env python
"""Does the RANDOM-backbone control (PMR 0.056) also solve the ACCEPTOR side?

If the acceptor term is an absolute-position detector, a random backbone -- which
still has absolute position embeddings -- should ALSO pick the true acceptor
(index 200) at high rate, while failing on the donor (which needs real biology).
That would fully reconcile the low random-control PMR with a positional shortcut,
since PMR requires BOTH endpoints.
"""
from __future__ import annotations
import sys
from pathlib import Path
import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))
from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.schema import SplicePairExample  # noqa: E402
from gfmcd.splicing.readout import collate_pair_indices  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint  # noqa: E402

N, BATCH = 200, 8
device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"]); mc = cfg["model"]

examples = []
with (REPO / "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl").open() as f:
    for line in f:
        if line.strip():
            examples.append(SplicePairExample.from_json(line))
        if len(examples) >= N:
            break

for regime in ("additive-frozen", "additive-random-frozen"):
    adapter = SpliceBertAdapter.from_pretrained(
        REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
        trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
    ckp = REPO / f"colab_results/splicebert_run/runs/{regime}_seed0/checkpoint.pt"
    readout, ck = load_pair_checkpoint(ckp, adapter=adapter)  # loads backbone_state if present
    has_bb = ck.get("backbone_state") is not None
    na = nd = npmr = 0
    for i in range(0, len(examples), BATCH):
        eb = examples[i:i+BATCH]
        tok = adapter.tokenize([e.sequence for e in eb])
        pb = collate_pair_indices(eb, token_offset=tok.prefix_tokens, device=adapter.device)
        with torch.no_grad():
            h = adapter.forward(tok, output_hidden_states=True).hidden_states[rep]
            b = torch.arange(h.shape[0], device=h.device)[:, None]
            A = readout.acceptor(h[b, pb.positions[..., 0]]).squeeze(-1).float().cpu()
            D = readout.donor(h[b, pb.positions[..., 1]]).squeeze(-1).float().cpu()
            Lt = readout.length(readout._length_features(pb.lengths)).squeeze(-1).float().cpu()
        m = pb.mask.cpu(); pos = pb.positions.cpu(); off = tok.prefix_tokens
        full = A + D + Lt
        for k, e in enumerate(eb):
            sa, sd = {}, {}
            for p in range(m.shape[1]):
                if m[k, p]:
                    sa[int(pos[k, p, 0]) - off] = float(A[k, p])
                    sd[int(pos[k, p, 1]) - off] = float(D[k, p])
            tp = e.pairs[e.true_pair_index]
            na += int(max(sa, key=sa.get) == tp.acceptor_pos)
            nd += int(max(sd, key=sd.get) == tp.donor_pos)
            s = full[k].clone(); s[~m[k]] = -1e30
            tv = float(s[e.true_pair_index]); s[e.true_pair_index] = -1e30
            npmr += int(tv > float(s.max()))
    n = len(examples)
    print(f"{regime:24s} backbone_state_in_ckpt={has_bb}  "
          f"acceptor-term picks TRUE acceptor {na/n:.3f} | "
          f"donor-term picks TRUE donor {nd/n:.3f} | PMR {npmr/n:.3f}")

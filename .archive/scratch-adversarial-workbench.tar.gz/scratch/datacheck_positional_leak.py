#!/usr/bin/env python
"""DATA-CHECK of the 'positional leak' finding.

PART A (no model): verify the leak facts and the finding's baseline-swap PMRs on
ALL conflict examples, using the study's OWN frozen baseline (PWM + length prior).

PART B (model): the finding asserts the additive-random-frozen control (0.056)
"does not rule this out" because a random backbone's position embeddings are
N(0,0.02) and therefore (allegedly) not decodable.  The random-frozen checkpoint
SAVES its backbone (save_backbone=True), so this is directly testable: load the
actual random backbone + its trained readout and ask whether ITS acceptor term
picks index 200.
"""
from __future__ import annotations

import json
from pathlib import Path
import pickle
import sys

import numpy as np

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))

from gfmcd.splicing.schema import SplicePairExample  # noqa: E402

CONF = REPO / "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl"
PKL = REPO / "colab_results/splicebert_run/baselines/local_pair_baseline.pkl"

examples: list[SplicePairExample] = []
with CONF.open() as f:
    for line in f:
        if line.strip():
            examples.append(SplicePairExample.from_json(line))
print(f"conflict examples: {len(examples)}")

# ---------------- PART A: the leak, on every conflict example ----------------
bad_a = sum(1 for x in examples if x.true_pair.acceptor_pos != 200)
bad_len = sum(1 for x in examples if len(x.sequence) != 400 + x.true_pair.exon_length)
bad_d = sum(1 for x in examples if x.true_pair.donor_pos != len(x.sequence) - 200)
print(f"[A] true acceptor != 200            : {bad_a}/{len(examples)}")
print(f"[A] len(seq) != 400 + exon_length   : {bad_len}/{len(examples)}")
print(f"[A] true donor != len(seq) - 200    : {bad_d}/{len(examples)}")

baseline = pickle.loads(PKL.read_bytes())
print(f"[A] baseline: {type(baseline).__name__}, length_weight={baseline.length_weight}")


def pmr_for(scorer) -> float:
    ok = 0
    for x in examples:
        s = np.array([scorer(x, p) for p in x.pairs], dtype=float)
        t = x.true_pair_index
        best = np.max(np.delete(s, t))
        ok += int(s[t] > best)
    return ok / len(examples)


def pwm_acc(x, p):
    from gfmcd.splicing.baselines import site_window
    return baseline.acceptor_pwm.score(site_window(x.sequence, p.acceptor_pos, "acceptor"))


def pwm_don(x, p):
    from gfmcd.splicing.baselines import site_window
    return baseline.donor_pwm.score(site_window(x.sequence, p.donor_pos, "donor"))


def lenp(x, p):
    return baseline.length_weight * baseline.length_prior.score(p.exon_length)


def ind_a(x, p):
    return 1.0 if p.acceptor_pos == 200 else 0.0


def ind_d(x, p):
    return 1.0 if p.donor_pos == len(x.sequence) - 200 else 0.0


rows = {
    "real baseline  PWM_acc + PWM_don + len": lambda x, p: pwm_acc(x, p) + pwm_don(x, p) + lenp(x, p),
    "1[a==200]      + PWM_don + len        ": lambda x, p: ind_a(x, p) + pwm_don(x, p) + lenp(x, p),
    "PWM_acc        + 1[d==len-200] + len  ": lambda x, p: pwm_acc(x, p) + ind_d(x, p) + lenp(x, p),
    "1[a==200]      + 1[d==len-200] + len  ": lambda x, p: ind_a(x, p) + ind_d(x, p) + lenp(x, p),
    "1[a==200]      + 1[d==len-200] (no len)": lambda x, p: ind_a(x, p) + ind_d(x, p),
    "1[a==200] only                        ": ind_a,
}
partA = {}
for name, fn in rows.items():
    v = pmr_for(fn)
    partA[name.strip()] = v
    print(f"[A] PMR {name} = {v:.4f}")

# ---------------- PART B: is the shortcut available on the RANDOM backbone? ----
import torch  # noqa: E402
from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.readout import collate_pair_indices  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint  # noqa: E402

N = 300
BATCH = 8
device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"])
mc = cfg["model"]

sub = examples[:N]
partB = {}

for regime in ("additive-random-frozen", "additive-frozen"):
    adapter = SpliceBertAdapter.from_pretrained(
        REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
        trust_remote_code=False, local_files_only=True,
        model_class=mc.get("model_class", "masked_lm"))
    ck_path = REPO / f"colab_results/splicebert_run/runs/{regime}_seed0/checkpoint.pt"
    readout, ck = load_pair_checkpoint(ck_path, adapter=adapter)
    has_bb = ck.get("backbone_state") is not None
    print(f"\n[B] {regime}: backbone_state present = {has_bb} "
          f"(randomized_backbone flag = {ck.get('config', {}).get('randomized_backbone', ck.get('randomized_backbone'))})")

    n_acc = n_don = n_pmr = n_indA = 0
    tot = 0
    Aall, Apos = [], []
    for i in range(0, len(sub), BATCH):
        eb = sub[i:i + BATCH]
        tok = adapter.tokenize([e.sequence for e in eb])
        pb = collate_pair_indices(eb, token_offset=tok.prefix_tokens, device=adapter.device)
        with torch.no_grad():
            out = adapter.forward(tok, output_hidden_states=True)
            hidden = out.hidden_states[rep]
            b = torch.arange(hidden.shape[0], device=hidden.device)[:, None]
            A = readout.acceptor(hidden[b, pb.positions[..., 0]]).squeeze(-1).float().cpu()
            D = readout.donor(hidden[b, pb.positions[..., 1]]).squeeze(-1).float().cpu()
            Lt = readout.length(readout._length_features(pb.lengths)).squeeze(-1).float().cpu()
        mask = pb.mask.cpu()
        pos = pb.positions.cpu()
        off = tok.prefix_tokens
        for k, e in enumerate(eb):
            m = mask[k]
            t = e.true_pair_index
            ta, td = e.pairs[t].acceptor_pos, e.pairs[t].donor_pos
            sa, sd = {}, {}
            for p in range(m.shape[0]):
                if not m[p]:
                    continue
                sa[int(pos[k, p, 0]) - off] = float(A[k, p])
                sd[int(pos[k, p, 1]) - off] = float(D[k, p])
            n_acc += int(max(sa, key=sa.get) == ta)
            n_don += int(max(sd, key=sd.get) == td)
            for p_, v_ in sa.items():
                Apos.append(p_)
                Aall.append(v_)
            full = (A[k] + D[k] + Lt[k]).clone()
            full[~m] = -1e30
            ts = float(full[t]); full[t] = -1e30
            n_pmr += int(ts > float(full.max()))
            # readout with the trained acceptor MLP REPLACED by 1[a==200]
            indA = torch.zeros(m.shape[0])
            for p in range(len(e.pairs)):
                indA[p] = 1.0 if e.pairs[p].acceptor_pos == 200 else 0.0
            sw = (indA + D[k] + Lt[k]).clone()
            sw[~m] = -1e30
            ts2 = float(sw[t]); sw[t] = -1e30
            n_indA += int(ts2 > float(sw.max()))
            tot += 1

    Apos = np.array(Apos); Aall = np.array(Aall)
    pred = np.zeros_like(Aall)
    for p_ in np.unique(Apos):
        mm = Apos == p_
        pred[mm] = Aall[mm].mean()
    r2 = 1 - ((Aall - pred) ** 2).sum() / ((Aall - Aall.mean()) ** 2).sum()

    partB[regime] = dict(
        n=tot, pmr=n_pmr / tot, acc_term_picks_true_acceptor=n_acc / tot,
        don_term_picks_true_donor=n_don / tot,
        pmr_with_indicator_acceptor=n_indA / tot, r2_A_on_abs_pos=float(r2),
        backbone_state_present=has_bb)
    v = partB[regime]
    print(f"[B] {regime}: PMR={v['pmr']:.3f} | A-term picks TRUE acceptor (=idx200) "
          f"{v['acc_term_picks_true_acceptor']:.3f} | D-term picks TRUE donor "
          f"{v['don_term_picks_true_donor']:.3f} | PMR with A replaced by 1[a==200] "
          f"{v['pmr_with_indicator_acceptor']:.3f} | R^2(A|abs pos)={v['r2_A_on_abs_pos']:.3f}")
    del adapter, readout

json.dump(dict(partA=partA, partB=partB, n_conflict=len(examples), n_model=N),
          open(REPO / "scratch/datacheck_positional_leak_results.json", "w"), indent=2)
print("\nwrote scratch/datacheck_positional_leak_results.json")

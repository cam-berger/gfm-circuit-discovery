#!/usr/bin/env python
"""Referee re-check of the claim:
  'the additive-random-frozen control solves the ACCEPTOR half at ceiling (1.0)
   and collapses only on DONORS.'
Independent implementation. Random sample (not first-N). Multiple seeds.
"""
from __future__ import annotations
import json, random, sys
from pathlib import Path
import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))
from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa
from gfmcd.splicing.config import load_config  # noqa
from gfmcd.splicing.schema import SplicePairExample  # noqa
from gfmcd.splicing.readout import collate_pair_indices  # noqa
from gfmcd.splicing.training import load_pair_checkpoint  # noqa

N, BATCH = 600, 8
device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"]); mc = cfg["model"]

lines = [l for l in (REPO / "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl").open() if l.strip()]
print(f"conflict file lines = {len(lines)}")
rng = random.Random(12345)
sample_lines = rng.sample(lines, N)
examples = [SplicePairExample.from_json(l) for l in sample_lines]

# positional degeneracy sanity check on the sample
bad_a = sum(1 for e in examples if e.pairs[e.true_pair_index].acceptor_pos != 200)
bad_d = sum(1 for e in examples if e.pairs[e.true_pair_index].donor_pos != len(e.sequence) - 200)
print(f"true acceptor != 200: {bad_a}/{N};  true donor != len-200: {bad_d}/{N}")

out = {}
for regime in ("additive-frozen", "additive-random-frozen"):
    for seed in (0, 1, 2):
        adapter = SpliceBertAdapter.from_pretrained(
            REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
            trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
        # snapshot a pretrained encoder weight to verify the loaded backbone really differs
        ref_name, ref_w = next((n, p.detach().float().cpu().clone())
                               for n, p in adapter.model.named_parameters()
                               if "encoder" in n and p.dim() == 2)
        ckp = REPO / f"colab_results/splicebert_run/runs/{regime}_seed{seed}/checkpoint.pt"
        readout, ck = load_pair_checkpoint(ckp, adapter=adapter)
        has_bb = ck.get("backbone_state") is not None
        now = dict(adapter.model.named_parameters())[ref_name].detach().float().cpu()
        same_as_pretrained = bool(torch.equal(ref_w, now))
        cosw = float(torch.nn.functional.cosine_similarity(ref_w.flatten(), now.flatten(), dim=0))

        na = nd = npmr = 0
        a_at_200 = 0        # does the acceptor argmax land exactly on token 200?
        d_at_len200 = 0
        for i in range(0, len(examples), BATCH):
            eb = examples[i:i + BATCH]
            tok = adapter.tokenize([e.sequence for e in eb])
            pb = collate_pair_indices(eb, token_offset=tok.prefix_tokens, device=adapter.device)
            with torch.no_grad():
                h = adapter.forward(tok, output_hidden_states=True).hidden_states[rep]
                b = torch.arange(h.shape[0], device=h.device)[:, None]
                A = readout.acceptor(h[b, pb.positions[..., 0]]).squeeze(-1).float().cpu()
                D = readout.donor(h[b, pb.positions[..., 1]]).squeeze(-1).float().cpu()
                Lt = readout.length(readout._length_features(pb.lengths)).squeeze(-1).float().cpu()
            m = pb.mask.cpu(); pos = pb.positions.cpu(); off = tok.prefix_tokens
            full = A + D + Lt
            for k, e in enumerate(eb):
                sa, sd = {}, {}
                for p in range(m.shape[1]):
                    if m[k, p]:
                        sa[int(pos[k, p, 0]) - off] = float(A[k, p])
                        sd[int(pos[k, p, 1]) - off] = float(D[k, p])
                tp = e.pairs[e.true_pair_index]
                besta = max(sa, key=sa.get); bestd = max(sd, key=sd.get)
                na += int(besta == tp.acceptor_pos)
                nd += int(bestd == tp.donor_pos)
                a_at_200 += int(besta == 200)
                d_at_len200 += int(bestd == len(e.sequence) - 200)
                s = full[k].clone(); s[~m[k]] = -1e30
                tv = float(s[e.true_pair_index]); s[e.true_pair_index] = -1e30
                npmr += int(tv > float(s.max()))
        key = f"{regime}_seed{seed}"
        out[key] = dict(backbone_state_in_ckpt=has_bb, backbone_equals_pretrained=same_as_pretrained,
                        cos_to_pretrained=cosw, acceptor_argmax=na / N, donor_argmax=nd / N,
                        pmr=npmr / N, acceptor_argmax_at_tok200=a_at_200 / N,
                        donor_argmax_at_len_minus_200=d_at_len200 / N)
        print(key, json.dumps(out[key]))

(REPO / "scratch/ref_check_random_control.json").write_text(json.dumps(out, indent=2))

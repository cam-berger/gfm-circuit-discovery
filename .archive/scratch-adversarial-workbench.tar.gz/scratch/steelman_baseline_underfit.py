#!/usr/bin/env python
"""STEELMAN TEST of the 'baseline is under-fit' finding.

Fix ALL FOUR axes the finding names:
  (1) discriminative weighting of the three features (vs generative, positives-only)
  (2) background estimated from the ACTUAL DECOY/candidate distribution (vs positives)
  (3) length_weight tuned (vs hard-coded 1.0)
  (4) window widths selected (vs registered MaxEntScan defaults)
Rebuild the conflict set under the STRONG baseline, then re-score the SAME trained
additive-frozen seed0 readout and ask: does conflict PMR move?
"""
from __future__ import annotations

import json
from pathlib import Path
import random
import sys

import numpy as np
import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))

from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.schema import SplicePairExample  # noqa: E402
from gfmcd.splicing.readout import collate_pair_indices  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint  # noqa: E402

B2I = {"A": 0, "C": 1, "G": 2, "T": 3}
N_TRAIN = 12000        # train examples for PWM fit + weight tuning
N_TUNE = 3000          # of those, held out for window/weight selection
N_VAL = 1600           # val examples to score with the model
PSEUDO = 0.5


def seq_idx(seq: str) -> np.ndarray:
    a = np.full(len(seq), -1, dtype=np.int64)
    for i, b in enumerate(seq):
        j = B2I.get(b, -1)
        a[i] = j
    return a


def fit_pwm(windows: list[np.ndarray], length: int, bg: np.ndarray | None):
    counts = np.full((length, 4), PSEUDO)
    bgc = np.full(4, PSEUDO)
    for w in windows:
        for p in range(length):
            j = w[p]
            if j >= 0:
                counts[p, j] += 1
                bgc[j] += 1
    probs = counts / counts.sum(1, keepdims=True)
    background = (bgc / bgc.sum()) if bg is None else (bg / bg.sum())
    return np.log(probs) - np.log(background[None, :]), background


def site_scores(sidx: np.ndarray, positions: np.ndarray, up: int, down: int, lo: np.ndarray) -> np.ndarray:
    """Score every candidate site position under PWM `lo` (window pos-up .. pos+down)."""
    L = up + down
    out = np.full(len(positions), -np.inf)
    for k, p in enumerate(positions):
        s, e = p - up, p + down
        if s < 0 or e > len(sidx):
            continue
        w = sidx[s:e]
        tot = 0.0
        ok = True
        for q in range(L):
            j = w[q]
            if j < 0:
                continue
            tot += lo[q, j]
        if ok:
            out[k] = tot
    return out


def load_lines(path: Path, n: int, skip: int = 0) -> list[SplicePairExample]:
    out = []
    with path.open() as f:
        for i, line in enumerate(f):
            if i < skip:
                continue
            if not line.strip():
                continue
            out.append(SplicePairExample.from_json(line))
            if len(out) >= n:
                break
    return out


print("loading train subsample ...", flush=True)
train = load_lines(REPO / "data/processed/splicebert_partner_selection/v1/train.jsonl", N_TRAIN)
fit_ex, tune_ex = train[:N_TRAIN - N_TUNE], train[N_TRAIN - N_TUNE:]
print(f"  train fit={len(fit_ex)} tune={len(tune_ex)}", flush=True)

print("loading val ...", flush=True)
val_all = load_lines(REPO / "data/processed/splicebert_partner_selection/v1/val.jsonl", 17069)
rng = random.Random(0)
val = rng.sample(val_all, N_VAL)
del val_all
print(f"  val sample={len(val)}", flush=True)

# cache sequence indices
cache = {}
for x in fit_ex + tune_ex + val:
    cache[x.example_id] = seq_idx(x.sequence)

# ---------------- length prior (shared) ----------------
lens = [x.true_pair.exon_length for x in fit_ex]
LMIN, LMAX = 20, 500
lcounts = np.full(LMAX - LMIN + 1, 1.0)
for L in lens:
    if LMIN <= L <= LMAX:
        lcounts[L - LMIN] += 1
LOGP = np.log(lcounts / lcounts.sum())


def lprior(L: int) -> float:
    return LOGP[L - LMIN] if LMIN <= L <= LMAX else -np.inf


LPRIOR_VEC = np.concatenate([np.full(LMIN, -np.inf), LOGP])  # index by length


def build(cfg, use_decoy_bg: bool):
    (au, ad), (du, dd) = cfg
    accw, donw = [], []
    for x in fit_ex:
        s = cache[x.example_id]
        p = x.true_pair
        if p.acceptor_pos - au >= 0 and p.acceptor_pos + ad <= len(s):
            accw.append(s[p.acceptor_pos - au: p.acceptor_pos + ad])
        if p.donor_pos - du >= 0 and p.donor_pos + dd <= len(s):
            donw.append(s[p.donor_pos - du: p.donor_pos + dd])
    abg = dbg = None
    if use_decoy_bg:
        # background from the ACTUAL candidate (decoy-dominated) window distribution
        ac = np.full(4, PSEUDO)
        dc = np.full(4, PSEUDO)
        for x in fit_ex[:3000]:
            s = cache[x.example_id]
            for c in x.acceptors:
                st, e = c.position - au, c.position + ad
                if st >= 0 and e <= len(s):
                    for j in s[st:e]:
                        if j >= 0:
                            ac[j] += 1
            for c in x.donors:
                st, e = c.position - du, c.position + dd
                if st >= 0 and e <= len(s):
                    for j in s[st:e]:
                        if j >= 0:
                            dc[j] += 1
        abg, dbg = ac / ac.sum(), dc / dc.sum()
    alo, _ = fit_pwm(accw, au + ad, abg)
    dlo, _ = fit_pwm(donw, du + dd, dbg)
    return alo, dlo


def score_example(x, alo, dlo, cfg, wa, wd, wl):
    (au, ad), (du, dd) = cfg
    s = cache[x.example_id]
    ap = np.array([c.position for c in x.acceptors])
    dp = np.array([c.position for c in x.donors])
    A = site_scores(s, ap, au, ad, alo)
    D = site_scores(s, dp, du, dd, dlo)
    ai = {p: i for i, p in enumerate(ap)}
    di = {p: i for i, p in enumerate(dp)}
    sc = np.empty(len(x.pairs))
    for k, pr in enumerate(x.pairs):
        sc[k] = wa * A[ai[pr.acceptor_pos]] + wd * D[di[pr.donor_pos]] + wl * LPRIOR_VEC[pr.exon_length]
    return sc


def top1(exs, alo, dlo, cfg, wa, wd, wl):
    ok = 0
    for x in exs:
        sc = score_example(x, alo, dlo, cfg, wa, wd, wl)
        if int(np.nanargmax(sc)) == x.true_pair_index:
            ok += 1
    return ok / len(exs)


REG_CFG = ((20, 3), (3, 6))   # registered = MaxEntScan windows
WIDE_CFG = ((40, 10), (10, 12))

results = {}
# --- reproduce registered baseline (sanity) ---
alo_r, dlo_r = build(REG_CFG, use_decoy_bg=False)
results["registered_tune_top1"] = top1(tune_ex, alo_r, dlo_r, REG_CFG, 1.0, 1.0, 1.0)
print("registered (refit) tune top1:", results["registered_tune_top1"], flush=True)

# --- STRONG baseline: wide windows + decoy background + tuned weights ---
best = None
for cfg_name, cfg in [("reg", REG_CFG), ("wide", WIDE_CFG)]:
    for bg in [False, True]:
        alo, dlo = build(cfg, use_decoy_bg=bg)
        for wd in [0.5, 0.75, 1.0, 1.5, 2.0]:
            for wl in [0.0, 0.5, 1.0, 1.5, 2.0, 3.0]:
                t = top1(tune_ex[:1200], alo, dlo, cfg, 1.0, wd, wl)
                if best is None or t > best[0]:
                    best = (t, cfg_name, cfg, bg, wd, wl, alo, dlo)
                    print(f"  new best tune-top1={t:.4f}  cfg={cfg_name} decoybg={bg} wd={wd} wl={wl}", flush=True)

t, cfg_name, S_CFG, S_BG, S_WD, S_WL, alo_s, dlo_s = best
results["strong"] = {"windows": cfg_name, "decoy_bg": S_BG, "w_donor": S_WD, "w_length": S_WL,
                     "tune_top1": t}
print("STRONG baseline:", results["strong"], flush=True)

# --- val: conflict membership under BOTH baselines (use SHIPPED pickle for registered) ---
import pickle  # noqa: E402
with (REPO / "colab_results/splicebert_run/baselines/local_pair_baseline.pkl").open("rb") as f:
    shipped = pickle.load(f)

reg_conflict = np.zeros(len(val), dtype=bool)
strong_conflict = np.zeros(len(val), dtype=bool)
for i, x in enumerate(val):
    reg_conflict[i] = shipped.predict(x) != x.true_pair_index
    sc = score_example(x, alo_s, dlo_s, S_CFG, 1.0, S_WD, S_WL)
    strong_conflict[i] = int(np.nanargmax(sc)) != x.true_pair_index

results["val_top1_shipped"] = float(1 - reg_conflict.mean())
results["val_top1_strong"] = float(1 - strong_conflict.mean())
print(f"val top1: shipped={results['val_top1_shipped']:.4f}  strong={results['val_top1_strong']:.4f}", flush=True)

# --- score the trained readout ---
device = "mps" if torch.backends.mps.is_available() else "cpu"
cfgj = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfgj["readout"]["representation_layer"])
mc = cfgj["model"]
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
readout, checkpoint = load_pair_checkpoint(
    REPO / "colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt", adapter=adapter)
print("backbone_state is None:", checkpoint.get("backbone_state") is None, flush=True)

wins = np.zeros(len(val), dtype=bool)
BATCH = 8
for i in range(0, len(val), BATCH):
    ex = val[i:i + BATCH]
    tok = adapter.tokenize([x.sequence for x in ex])
    pb = collate_pair_indices(ex, token_offset=tok.prefix_tokens, device=adapter.device)
    with torch.no_grad():
        out = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
        logits = readout(out.hidden_states[rep], pb).float().cpu()
    m = pb.mask.cpu()
    for k, x in enumerate(ex):
        lg = logits[k].clone()
        lg[~m[k]] = -np.inf
        t_ = lg[x.true_pair_index].item()
        lg[x.true_pair_index] = -np.inf
        wins[i + k] = t_ > lg.max().item()
    if i % 200 == 0:
        print(f"  scored {i}/{len(val)}", flush=True)


def pmr(mask):
    return float(wins[mask].mean()) if mask.sum() else None


both = reg_conflict & strong_conflict
dropped = reg_conflict & ~strong_conflict     # conflicts the STRONG baseline solves
added = ~reg_conflict & strong_conflict       # new conflicts the STRONG baseline creates
results["pmr"] = {
    "all_val": pmr(np.ones(len(val), bool)),
    "registered_conflict": pmr(reg_conflict),
    "STRONG_conflict": pmr(strong_conflict),
    "intersection": pmr(both),
    "dropped_from_registered": pmr(dropped),
    "added_by_strong": pmr(added),
}
results["counts"] = {
    "n_val": len(val),
    "registered_conflict": int(reg_conflict.sum()),
    "strong_conflict": int(strong_conflict.sum()),
    "intersection": int(both.sum()),
    "dropped": int(dropped.sum()),
    "added": int(added.sum()),
    "churn_frac_of_registered": float((dropped.sum() + added.sum()) / max(reg_conflict.sum(), 1)),
}
print(json.dumps(results, indent=2, default=float))
(REPO / "scratch/steelman_baseline_underfit_results.json").write_text(json.dumps(results, indent=2, default=float))

#!/usr/bin/env python
"""Does the trained additive readout's acceptor term f(h_a) implement
'am I at absolute position 200?' or does it read biology?

Design (2x2 crop test). Both crops remove 50nt from the OUTER edge of a 200nt
flank, so the local sequence context of BOTH true sites is untouched, and the
exon-length feature L = donor_pos - acceptor_pos is exactly preserved.

  LEFT-CROP-50 (seq[50:], all positions -50):
      true acceptor abs pos: 200 -> 150   (CHANGED)
      true donor  abs pos:   -50          (CHANGED)
      true donor  dist-from-end: 200 -> 200 (PRESERVED)
  RIGHT-CROP-50 (seq[:-50], positions unchanged):
      true acceptor abs pos: 200 -> 200   (PRESERVED)
      true donor  abs pos:   unchanged    (PRESERVED)
      true donor  dist-from-end: 200 -> 150 (CHANGED)

Predictions
  f is a position-200 detector  -> acceptor accuracy COLLAPSES under left-crop,
                                   SURVIVES under right-crop.
  f is a biological detector    -> acceptor accuracy survives BOTH.
"""
from __future__ import annotations

import json
from pathlib import Path
import sys

import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))

from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.schema import SplicePairExample, SiteCandidate, PairCandidate  # noqa: E402
from gfmcd.splicing.readout import collate_pair_indices  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint  # noqa: E402

N = int(sys.argv[1]) if len(sys.argv) > 1 else 200
BATCH = 8

device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"])
mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
readout, ck = load_pair_checkpoint(
    REPO / "colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt", adapter=adapter)
assert ck.get("backbone_state") is None
print("readout:", type(readout).__name__, "| rep layer", rep, "| device", device)

conf = REPO / "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl"
examples: list[SplicePairExample] = []
with conf.open() as f:
    for line in f:
        if line.strip():
            examples.append(SplicePairExample.from_json(line))
        if len(examples) >= N:
            break
print("loaded", len(examples))


def crop(x: SplicePairExample, left: int, right: int) -> SplicePairExample | None:
    """Remove `left` nt from the start and `right` nt from the end."""
    seq = x.sequence[left: len(x.sequence) - right] if right else x.sequence[left:]
    n = len(seq)
    # remap sites; drop any that fall outside the valid motif window
    amap, dmap = {}, {}
    accs, dons = [], []
    for i, s in enumerate(x.acceptors):
        p = s.position - left
        if 2 <= p < n and seq[p - 2:p] == s.motif:
            amap[i] = len(accs)
            accs.append(SiteCandidate(position=p, kind="acceptor", motif=s.motif))
    for i, s in enumerate(x.donors):
        p = s.position - left
        if 0 <= p <= n - 2 and seq[p:p + 2] == s.motif:
            dmap[i] = len(dons)
            dons.append(SiteCandidate(position=p, kind="donor", motif=s.motif))
    pairs, true_idx = [], None
    for j, pr in enumerate(x.pairs):
        if pr.acceptor_index not in amap or pr.donor_index not in dmap:
            if j == x.true_pair_index:
                return None
            continue
        if j == x.true_pair_index:
            true_idx = len(pairs)
        pairs.append(PairCandidate(
            acceptor_pos=pr.acceptor_pos - left, donor_pos=pr.donor_pos - left,
            acceptor_index=amap[pr.acceptor_index], donor_index=dmap[pr.donor_index]))
    if true_idx is None or len(pairs) < 2:
        return None
    return SplicePairExample(
        example_id=x.example_id, sequence=seq, acceptors=tuple(accs), donors=tuple(dons),
        pairs=tuple(pairs), true_pair_index=true_idx, split=x.split, chrom=x.chrom,
        strand=x.strand, gene_id=x.gene_id, transcript_id=x.transcript_id,
        exon_number=x.exon_number, genomic_exon_start=x.genomic_exon_start,
        genomic_exon_end=x.genomic_exon_end, metadata=x.metadata)


VARIANTS = {
    "original":       (0, 0),
    "left-crop-50":   (50, 0),
    "right-crop-50":  (0, 50),
    "both-crop-50":   (50, 50),
}

results = {}
for name, (l, r) in VARIANTS.items():
    if (l, r) == (0, 0):
        exs = examples
    else:
        exs = [c for c in (crop(x, l, r) for x in examples) if c is not None]
    n_acc_ok = n_don_ok = n_pmr = 0
    tot = 0
    for i in range(0, len(exs), BATCH):
        eb = exs[i:i + BATCH]
        tok = adapter.tokenize([e.sequence for e in eb])
        pb = collate_pair_indices(eb, token_offset=tok.prefix_tokens, device=adapter.device)
        with torch.no_grad():
            out = adapter.forward(tok, output_hidden_states=True)
            hidden = out.hidden_states[rep]
            b = torch.arange(hidden.shape[0], device=hidden.device)[:, None]
            A = readout.acceptor(hidden[b, pb.positions[..., 0]]).squeeze(-1).float().cpu()
            D = readout.donor(hidden[b, pb.positions[..., 1]]).squeeze(-1).float().cpu()
            Lt = readout.length(readout._length_features(pb.lengths)).squeeze(-1).float().cpu()
        mask = pb.mask.cpu()
        pos = pb.positions.cpu()
        full = A + D + Lt
        for k, e in enumerate(eb):
            m = mask[k]
            t = e.true_pair_index
            ta = e.pairs[t].acceptor_pos
            td = e.pairs[t].donor_pos
            # per-site argmax over DISTINCT candidate site positions
            best_a, best_a_pos = -1e30, None
            best_d, best_d_pos = -1e30, None
            seen_a, seen_d = {}, {}
            for p in range(m.shape[0]):
                if not m[p]:
                    continue
                ap = int(pos[k, p, 0]); dp = int(pos[k, p, 1])
                seen_a[ap] = float(A[k, p]); seen_d[dp] = float(D[k, p])
            ba = max(seen_a, key=seen_a.get); bd = max(seen_d, key=seen_d.get)
            off = tok.prefix_tokens
            n_acc_ok += int(ba - off == ta)
            n_don_ok += int(bd - off == td)
            sc = full[k].clone()
            sc[~m] = -1e30
            true_s = float(sc[t]); sc[t] = -1e30
            n_pmr += int(true_s > float(sc.max()))
            tot += 1
    results[name] = dict(n=tot, acc_site=n_acc_ok / tot, don_site=n_don_ok / tot, pmr=n_pmr / tot)
    print(f"{name:15s} n={tot:4d}  acceptor-term picks TRUE acceptor {n_acc_ok/tot:.3f}   "
          f"donor-term picks TRUE donor {n_don_ok/tot:.3f}   PMR {n_pmr/tot:.3f}")

json.dump(results, open(REPO / "scratch/crop_position_results.json", "w"), indent=2)

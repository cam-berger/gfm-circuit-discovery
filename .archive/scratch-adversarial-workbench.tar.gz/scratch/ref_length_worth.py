#!/usr/bin/env python
"""REFEREE CHECK of the finding 'length is worth 25 PMR points'.

Two decompositions of the SAME additive-frozen seed0 logits on the conflict set:
  (A) EXACT: run the checkpoint's own MLP_acc / MLP_don / MLP_len modules.
  (B) LEAST-SQUARES recovery from the saved logits (what the finding did).
Compare "drop the length term" top1 under both, and test the identifiability
(gauge) hypothesis: exon_length = donor_pos - acceptor_pos EXACTLY, so
  f(a)+c*a , g(d)-c*d , L(l)+c*l
is an exactly equivalent decomposition for any c.  The LS "length function" is
therefore only identified up to a linear-in-length slope.
"""
from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np
import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))

from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.schema import SplicePairExample  # noqa: E402
from gfmcd.splicing.readout import collate_pair_indices  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint  # noqa: E402

N = int(sys.argv[1]) if len(sys.argv) > 1 else 1200
BATCH = 8

device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"])
mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
ckpt_path = REPO / "artifacts/splicebert_partner_selection/readouts/additive-frozen/seed0/checkpoint.pt"
readout, checkpoint = load_pair_checkpoint(ckpt_path, adapter=adapter)
print("ckpt:", ckpt_path.name, "| regime:", checkpoint.get("extra_metadata", {}).get("regime"),
      "| backbone_state None:", checkpoint.get("backbone_state") is None, "| rep layer:", rep)

conf_path = REPO / "results/splicebert_partner_selection/baselines/val_local_conflicts.jsonl"
examples: list[SplicePairExample] = []
with conf_path.open() as f:
    for line in f:
        if line.strip():
            examples.append(SplicePairExample.from_json(line))
        if len(examples) >= N:
            break
print(f"loaded {len(examples)} conflicts; mean pairs {np.mean([len(x.pairs) for x in examples]):.1f}")

# saved logits, for identity check against the file the finding used
saved = {}
with (REPO / "results/splicebert_partner_selection/behavior/seed0_additive-frozen/val/val_local_conflicts/per_example_clean.jsonl").open() as f:
    for line in f:
        d = json.loads(line)
        saved[d["example_id"]] = np.asarray(d["logits"], dtype=np.float64)

rows = []
max_saved_err = 0.0
max_ident_err = 0.0
for i in range(0, len(examples), BATCH):
    ex = examples[i:i + BATCH]
    tok = adapter.tokenize([x.sequence for x in ex])
    pb = collate_pair_indices(ex, token_offset=tok.prefix_tokens, device=adapter.device)
    with torch.no_grad():
        out = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
        h = out.hidden_states[rep]
        b = torch.arange(h.shape[0], device=h.device)[:, None]
        acc_h = h[b, pb.positions[..., 0]]
        don_h = h[b, pb.positions[..., 1]]
        A = readout.acceptor(acc_h).squeeze(-1).float().cpu().numpy()
        D = readout.donor(don_h).squeeze(-1).float().cpu().numpy()
        L = readout.length(readout._length_features(pb.lengths)).squeeze(-1).float().cpu().numpy()
        full = readout(h, pb).float().cpu().numpy()
    for k, x in enumerate(ex):
        n = len(x.pairs)
        a = A[k, :n].astype(np.float64)
        d = D[k, :n].astype(np.float64)
        l = L[k, :n].astype(np.float64)
        fl = full[k, :n].astype(np.float64)
        max_ident_err = max(max_ident_err, float(np.abs(a + d + l - fl).max()))
        if x.example_id in saved:
            sv = saved[x.example_id][:n]
            max_saved_err = max(max_saved_err, float(np.abs(sv - fl).max()))
        rows.append(dict(
            eid=x.example_id, A=a, D=d, Lt=l, full=fl, t=x.true_pair_index,
            apos=np.array([p.acceptor_pos for p in x.pairs]),
            dpos=np.array([p.donor_pos for p in x.pairs]),
            elen=np.array([p.exon_length for p in x.pairs]),
        ))
    if i % 200 == 0:
        print("  ...", i, flush=True)

print(f"identity max|A+D+L - forward| = {max_ident_err:.2e}")
print(f"max|saved per_example_clean logits - recomputed| = {max_saved_err:.2e}  (same checkpoint?)")


def top1(rows, key):
    ok = don_ok = acc_ok = 0
    for r in rows:
        s = key(r)
        j = int(np.argmax(s))
        ok += int(j == r["t"])
        don_ok += int(r["dpos"][j] == r["dpos"][r["t"]])
        acc_ok += int(r["apos"][j] == r["apos"][r["t"]])
    n = len(rows)
    return ok / n, acc_ok / n, don_ok / n


print("\n=== EXACT decomposition (checkpoint modules) ===")
for name, key in [
    ("full  A+D+L ", lambda r: r["A"] + r["D"] + r["Lt"]),
    ("A+D (no len)", lambda r: r["A"] + r["D"]),
    ("A+L (no don)", lambda r: r["A"] + r["Lt"]),
    ("D+L (no acc)", lambda r: r["D"] + r["Lt"]),
    ("L only      ", lambda r: r["Lt"] + 0.0),
]:
    t1, am, dm = top1(rows, key)
    print(f"  {name}: pair top1 {t1:.4f}   acceptor-marginal {am:.4f}   donor-marginal {dm:.4f}")

# ---------------- LS recovery, exactly as the finding describes ----------------
print("\n=== LEAST-SQUARES recovery from logits (per example, min-norm) ===")
ls_stats = []
ls_rows = []
for r in rows:
    ap = r["apos"]; dp = r["dpos"]; el = r["elen"]
    ua, ai = np.unique(ap, return_inverse=True)
    ud, di = np.unique(dp, return_inverse=True)
    ul, li = np.unique(el, return_inverse=True)
    n = len(ap)
    X = np.zeros((n, len(ua) + len(ud) + len(ul)))
    X[np.arange(n), ai] = 1
    X[np.arange(n), len(ua) + di] = 1
    X[np.arange(n), len(ua) + len(ud) + li] = 1
    beta, *_ = np.linalg.lstsq(X, r["full"], rcond=None)
    pred = X @ beta
    rmse = float(np.sqrt(np.mean((pred - r["full"]) ** 2)))
    f_ls = beta[:len(ua)][ai]
    g_ls = beta[len(ua):len(ua) + len(ud)][di]
    L_ls = beta[len(ua) + len(ud):][li]
    # gauge test: is L_ls - L_true (exact) an affine function of exon_length?
    diff = L_ls - r["Lt"]
    Z = np.stack([np.ones(n), el.astype(float)], 1)
    c, *_ = np.linalg.lstsq(Z, diff, rcond=None)
    resid = diff - Z @ c
    r2 = 1.0 - float(np.var(resid) / max(np.var(diff), 1e-12))
    ls_stats.append((rmse, float(c[1]), r2, len(ua) + len(ud) + len(ul), n))
    ls_rows.append(dict(r, fg_ls=f_ls + g_ls, L_ls=L_ls))

rmses, slopes, r2s, nun, nq = map(np.array, zip(*ls_stats))
print(f"  LS residual RMSE: median {np.median(rmses):.6f}  (score IS additive)")
print(f"  unknowns/equations per example: median {np.median(nun):.0f}/{np.median(nq):.0f} "
      f"(ratio {np.median(nun / nq):.2f})")
print(f"  GAUGE TEST  L_LS - L_true  ~= const + c*exon_length :  median R^2 = {np.median(r2s):.4f}, "
      f"median slope c = {np.median(slopes):.4f}, IQR c = [{np.percentile(slopes,25):.4f},{np.percentile(slopes,75):.4f}]")

for name, key in [
    ("full (LS)      ", lambda r: r["fg_ls"] + r["L_ls"]),
    ("f+g (drop L_LS)", lambda r: r["fg_ls"]),
]:
    t1, am, dm = top1(ls_rows, key)
    print(f"  {name}: pair top1 {t1:.4f}   acceptor-marginal {am:.4f}   donor-marginal {dm:.4f}")

# how big is the true length term really?
alls = np.concatenate([r["Lt"] for r in rows])
print(f"\n  TRUE length term range: min {alls.min():.3f} max {alls.max():.3f} sd {alls.std():.3f}")
dl = np.array([r["Lt"][r["t"]] - r["Lt"][int(np.argmax(r['A']+r['D']+r['Lt']))] for r in rows])
print(f"  mean (L_true[true] - L_true[argmax]) = {dl.mean():.4f}")
# margin decomposition true - best decoy under full score
dA=[];dD=[];dL=[]
for r in rows:
    s = r["A"]+r["D"]+r["Lt"]; s2=s.copy(); s2[r["t"]]=-1e18; j=int(np.argmax(s2))
    dA.append(r["A"][r["t"]]-r["A"][j]); dD.append(r["D"][r["t"]]-r["D"][j]); dL.append(r["Lt"][r["t"]]-r["Lt"][j])
print(f"  margin decomposition vs best decoy: dA {np.mean(dA):+.4f}  dD {np.mean(dD):+.4f}  dL {np.mean(dL):+.4f}")

json.dump(dict(n=len(rows), ident_err=max_ident_err, saved_err=max_saved_err,
               ls_rmse_median=float(np.median(rmses)), gauge_r2_median=float(np.median(r2s)),
               gauge_slope_median=float(np.median(slopes))),
          open(REPO / "scratch/ref_length_worth.json", "w"), indent=2)

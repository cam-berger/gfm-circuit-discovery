#!/usr/bin/env python
"""Decisive test of the finding's core claim: "the specificity failure is ARITHMETIC --
the effect ratio O/Vc is fixed by the clean-margin ratio O/Vc (1.92)".

If that were true, the ratio eff_O/eff_Vc would be ~1.9 for ANY head set, because
arithmetic does not care which heads you ablate.  Measure eff_O/eff_Vc for several
head sets (AtP-necessity top-5, the smoke-run convergent C, random 5-head sets,
whole layers) with per-example SEs.  Read-only.
"""
from __future__ import annotations

import json
from pathlib import Path
import sys

import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))

from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.circuits.hf_bert import edit_heads, matched_random_head_sets  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.io import load_jsonl  # noqa: E402
from gfmcd.splicing.readout import collate_pair_indices, true_pair_margin  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint  # noqa: E402

N_EVAL = 192
BATCH = 8

device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"])
mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
readout, checkpoint = load_pair_checkpoint(
    REPO / "colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt", adapter=adapter)
assert checkpoint.get("backbone_state") is None

sd = REPO / "results/splicebert_partner_selection/circuits/discovery"
Vc = load_jsonl(sd / "confirmation.jsonl")[:N_EVAL]
O = load_jsonl(sd / "ordinary.jsonl")[:N_EVAL]


def batches(examples):
    out = []
    for i in range(0, len(examples), BATCH):
        ex = examples[i:i + BATCH]
        tok = adapter.tokenize([x.sequence for x in ex])
        pb = collate_pair_indices(ex, token_offset=tok.prefix_tokens, device=adapter.device)
        out.append((tok, pb))
    return out


def margins(bs, ablate=None):
    vals = []
    with torch.no_grad():
        for tok, pb in bs:
            if ablate is not None:
                with edit_heads(adapter, ablate, mode="mean"):
                    out = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
            else:
                out = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
            vals.extend(true_pair_margin(readout(out.hidden_states[rep], pb), pb).float().cpu().tolist())
    return torch.tensor(vals)


Vb, Ob = batches(Vc), batches(O)
m_vc, m_o = margins(Vb), margins(Ob)
print(f"clean margin  Vc {m_vc.mean():+.4f}  O {m_o.mean():+.4f}   margin ratio O/Vc = {m_o.mean()/m_vc.mean():.3f}")
print("  --> the finding predicts eff_O/eff_Vc ~= 1.95 for EVERY head set (it is 'arithmetic')\n")

sets = {
    "AtP-necessity top5": [(1, 7), (2, 3), (3, 7), (1, 0), (1, 4)],
    "smoke convergent C": [(1, 1), (1, 2), (1, 7), (4, 2)],
    "AtP top heads (DECISIONS)": [(4, 0), (2, 13), (3, 4)],
    "layer2 (all 16 heads)": [(2, h) for h in range(16)],
    "layer5 (all 16 heads)": [(5, h) for h in range(16)],
}
rs = matched_random_head_sets(adapter, [(1, 7), (2, 3), (3, 7), (1, 0), (1, 4)], n=4, seed=0, exclude_selected=True)
for i, r in enumerate(rs):
    sets[f"random5 #{i}"] = list(r)

rows = []
print(f"{'head set':28s} {'eff_Vc':>16s} {'eff_O':>16s} {'ratio O/Vc':>11s} {'norm_Vc':>8s} {'norm_O':>8s}  spec_pass")
for name, hs in sets.items():
    e_vc = m_vc - margins(Vb, ablate=list(hs))
    e_o = m_o - margins(Ob, ablate=list(hs))
    se_vc = float(e_vc.std() / len(e_vc) ** 0.5)
    se_o = float(e_o.std() / len(e_o) ** 0.5)
    ratio = float(e_o.mean() / e_vc.mean())
    nv, no = float(e_vc.mean() / m_vc.mean()), float(e_o.mean() / m_o.mean())
    ok = float(e_vc.mean()) > float(e_o.mean())
    print(f"{name:28s} {float(e_vc.mean()):+8.4f}+-{se_vc:.4f} {float(e_o.mean()):+8.4f}+-{se_o:.4f} "
          f"{ratio:11.3f} {nv:8.4f} {no:8.4f}  {ok}")
    rows.append(dict(name=name, heads=[list(h) for h in hs], eff_vc=float(e_vc.mean()), se_vc=se_vc,
                     eff_o=float(e_o.mean()), se_o=se_o, ratio=ratio, norm_vc=nv, norm_o=no,
                     conflict_gt_ordinary=ok))

json.dump(dict(clean_vc=float(m_vc.mean()), clean_o=float(m_o.mean()),
               margin_ratio=float(m_o.mean() / m_vc.mean()), n=N_EVAL, sets=rows),
          open(REPO / "scratch/steelman_specificity_headsets_results.json", "w"), indent=2)
print("\nwrote scratch/steelman_specificity_headsets_results.json")

#!/usr/bin/env python
"""ALT-EXPLANATION TEST for the 'fixed acceptor position = positional shortcut' finding.

The finding asserts the trained acceptor MLP f(h_a) is effectively 'am I at token 200?'.
That is a claim about the TRAINED MODEL, and it has never been tested -- the offered
evidence (f is higher for decoys near 200 than far from 200) is confounded with biology
(AGs near a real 3'ss sit in the polypyrimidine tract / branch-point context, which a
CONTENT-based acceptor detector would also score up).

Decisive dissociation: move the true acceptor OFF index 200 while preserving its local
sequence context exactly.  Prepending K random nucleotides shifts every original position
i -> i+K and leaves every site's +/-200nt context intact.

  * If f is a POSITION detector  -> after the shift it should keep firing near index 200,
    i.e. pick a DECOY acceptor ~K nt upstream of the true one; acceptor accuracy collapses.
  * If f is a CONTENT detector   -> acceptor accuracy is preserved under the shift.

Complementary condition: keep positions, destroy content (uniform-random sequence).
  * POSITION detector -> acceptor accuracy stays ~1.0 (it just fires at 200).
  * CONTENT detector  -> collapses to chance.

Also: append K nt on the RIGHT (positions unchanged) to break the donor's constant
distance-from-end (true donor is always at len-200), testing the donor side for a
'distance from [SEP]' shortcut.

Nothing in the repo is modified; this only reads checkpoints and data.
"""
from __future__ import annotations

import json
from pathlib import Path
import random
import sys

import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))

from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.schema import SplicePairExample  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint  # noqa: E402

N = int(sys.argv[1]) if len(sys.argv) > 1 else 200
BATCH = 4
NEG = float("-inf")
SEEDS = [0, 1, 2, 3, 4]
rng = random.Random(1234)

device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"])
mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))

readouts = {}
for s in SEEDS:
    p = REPO / f"colab_results/splicebert_run/runs/additive-frozen_seed{s}/checkpoint.pt"
    r, ck = load_pair_checkpoint(p, adapter=adapter)
    assert ck.get("backbone_state") is None
    readouts[s] = r

conf = REPO / "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl"
examples: list[SplicePairExample] = []
with conf.open() as f:
    for line in f:
        if line.strip():
            examples.append(SplicePairExample.from_json(line))
        if len(examples) >= N:
            break
# keep only examples short enough that +120nt still fits SpliceBERT's 1022nt budget
examples = [x for x in examples if len(x.sequence) + 120 <= 1020]
print(f"n={len(examples)}; seq len min={min(len(x.sequence) for x in examples)} "
      f"max={max(len(x.sequence) for x in examples)}")
bad_a = sum(1 for x in examples if x.true_pair.acceptor_pos != 200)
bad_d = sum(1 for x in examples if x.true_pair.donor_pos != len(x.sequence) - 200)
print(f"true acceptor != 200: {bad_a}/{len(examples)} | true donor != len-200: {bad_d}/{len(examples)}")


def rand_seq(k: int) -> str:
    return "".join(rng.choice("ACGT") for _ in range(k))


CONDITIONS = {
    # name: (left_pad, right_pad, randomize_content)
    "shiftL64": (64, 0, False),
    "shiftL120": (120, 0, False),
}


def run(cond: str):
    lpad, rpad, randomize = CONDITIONS[cond]
    rows = []
    for i in range(0, len(examples), BATCH):
        ex = examples[i:i + BATCH]
        seqs = []
        for x in ex:
            core = rand_seq(len(x.sequence)) if randomize else x.sequence
            seqs.append(rand_seq(lpad) + core + rand_seq(rpad))
        tok = adapter.tokenize(seqs)
        off = tok.prefix_tokens + lpad
        maxp = max(len(x.pairs) for x in ex)
        pos = torch.zeros((len(ex), maxp, 2), dtype=torch.long)
        lens = torch.zeros((len(ex), maxp), dtype=torch.float32)
        mask = torch.zeros((len(ex), maxp), dtype=torch.bool)
        for b, x in enumerate(ex):
            for p, pr in enumerate(x.pairs):
                pos[b, p, 0] = pr.acceptor_pos + off
                pos[b, p, 1] = pr.donor_pos + off
                lens[b, p] = pr.exon_length
                mask[b, p] = True
        pos_d, lens_d = pos.to(adapter.device), lens.to(adapter.device)
        with torch.no_grad():
            out = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
            hidden = out.hidden_states[rep]
            bidx = torch.arange(hidden.shape[0], device=hidden.device)[:, None]
            h_a = hidden[bidx, pos_d[..., 0]]
            h_d = hidden[bidx, pos_d[..., 1]]
            per_seed = {}
            for s in SEEDS:
                r = readouts[s]
                A = r.acceptor(h_a).squeeze(-1).float().cpu()
                D = r.donor(h_d).squeeze(-1).float().cpu()
                L = r.length(r._length_features(lens_d)).squeeze(-1).float().cpu()
                per_seed[s] = (A, D, L)
        for k, x in enumerate(ex):
            m = mask[k]
            rows.append(dict(
                t=x.true_pair_index,
                acc=torch.tensor([p.acceptor_pos for p in x.pairs]),
                don=torch.tensor([p.donor_pos for p in x.pairs]),
                terms={s: tuple(t[k][m].clone() for t in per_seed[s]) for s in SEEDS},
            ))
    return rows


def metrics(rows, lpad=0):
    out = {}
    for s in SEEDS:
        pmr = acc_top = don_top = 0
        near200 = 0  # argmax_A acceptor is the candidate whose SHIFTED index is closest to 200
        picks = []   # model-visible (shifted) nucleotide index of the argmax acceptor
        f_true, f_dec, nd = 0.0, 0.0, 0
        for r in rows:
            A, D, L = r["terms"][s]
            t = r["t"]
            sc = A + D + L
            d = sc.clone(); d[t] = NEG
            pmr += int(sc[t].item() > d.max().item())
            ua, ud = {}, {}
            for k in range(len(A)):
                ua[int(r["acc"][k])] = float(A[k])
                ud[int(r["don"][k])] = float(D[k])
            a_star = max(ua, key=ua.get)
            d_star = max(ud, key=ud.get)
            ta, td = int(r["acc"][t]), int(r["don"][t])
            acc_top += int(a_star == ta)
            don_top += int(d_star == td)
            # candidate whose MODEL-VISIBLE index (raw + lpad) is closest to 200
            closest = min(ua, key=lambda p: (abs(p + lpad - 200), p))
            near200 += int(a_star == closest)
            picks.append(a_star + lpad)
            f_true += ua[ta]
            f_dec += sum(v for p, v in ua.items() if p != ta) / max(1, len(ua) - 1)
            nd += 1
        n = len(rows)
        picks_sorted = sorted(picks)
        out[s] = dict(pmr=pmr / n, acceptor_argmax_correct=acc_top / n,
                      donor_argmax_correct=don_top / n,
                      argmaxA_is_candidate_nearest_visible_index_200=near200 / n,
                      median_visible_index_of_argmaxA=picks_sorted[n // 2],
                      frac_argmaxA_visible_index_within_10_of_200=sum(
                          1 for p in picks if abs(p - 200) <= 10) / n,
                      true_acceptor_visible_index=200 + lpad,
                      mean_f_true=f_true / nd, mean_f_decoy=f_dec / nd)
    return out


results = {}
for cond in CONDITIONS:
    rows = run(cond)
    results[cond] = metrics(rows, CONDITIONS[cond][0])
    m = results[cond]
    print(f"\n=== {cond} (true acceptor now at model-visible nt index {200+CONDITIONS[cond][0]}) ===")
    for s in SEEDS:
        v = m[s]
        print(f"  seed{s}: acc-argmax-correct={v['acceptor_argmax_correct']:.3f} "
              f"| don-argmax-correct={v['donor_argmax_correct']:.3f} "
              f"| argmaxA is candidate nearest visible-index 200: "
              f"{v['argmaxA_is_candidate_nearest_visible_index_200']:.3f} "
              f"| median visible index of argmaxA = {v['median_visible_index_of_argmaxA']} "
              f"| within10of200 = {v['frac_argmaxA_visible_index_within_10_of_200']:.3f}")
    sys.stdout.flush()

(REPO / "scratch/altexp_position_shift_results2.json").write_text(
    json.dumps(dict(n=len(examples), results=results), indent=2))
print("\nwrote scratch/altexp_position_shift_results2.json")

import sys, itertools, random
from pathlib import Path
import numpy as np, torch
REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO/"src"))
from gfmcd.splicing.circuit import *
from gfmcd.splicing.circuit import CIRCUIT, READER, ADDRESSER, DEFAULT_GTF, DEFAULT_FASTA, DEFAULT_MODEL

dev = pick_device(None)
ad = load_adapter(DEFAULT_MODEL, dev)
task = CouplingTask(ad, batch=6)
X, eff = load_examples(DEFAULT_GTF, DEFAULT_FASTA, "val", 24, task=task, tag="faith-val", min_effect=0.3)
genes=[x.gene_id for x in X]
print("n=",len(X), "mean base coupling", eff.mean())

def denoise_full(heads):
    num,dnm,dev_max=[],[],0.0
    with torch.no_grad():
        for i in range(0,len(X),task.batch):
            cl,co,dn = task.pair(X[i:i+task.batch])
            cc = capture_head_outputs(ad, lambda: ad.model(**cl))
            mc = task.margin(ad.model(**cl).logits.float(), dn)
            mk = task.margin(ad.model(**co).logits.float(), dn)
            with patch_heads(ad, cc, heads):
                mp = task.margin(ad.model(**co).logits.float(), dn)
            dev_max = max(dev_max, float((mp-mc).abs().max()))
            num += (mp-mk).tolist(); dnm += (mc-mk).tolist()
    return np.asarray(num), np.asarray(dnm), dev_max

ALL = [(l,h) for l in range(ad.num_layers) for h in range(ad.num_heads)]
CIRC=list(CIRCUIT); COMP=complement(ad,CIRC)
rows=[]
for name,heads in [("circuit C {L3H1,L2H15}",CIRC),
                   ("L3H1 alone",[READER]),
                   ("L2H15 alone",[ADDRESSER]),
                   ("complement (94)",COMP),
                   ("ALL 96 (ceiling)",ALL)]:
    num,dnm,dmax = denoise_full(heads)
    r = ratio_of_means(num,dnm); lo,hi=gboot_ratio(num,dnm,genes)
    rows.append((name,len(heads),r,lo,hi,dmax))
    print(f"{name:26s} k={len(heads):3d} recovery {r:7.4f} [{lo:+.3f},{hi:+.3f}]  max|mp-mc|={dmax:.3e}")

# THE LOAD-BEARING TEST: is the k=2 number discriminating, or does ANY 2-head set score high?
print("\n--- matched-random 2-head null (the control that decides whether 0.837 means anything) ---")
rng=random.Random(0)
nulls=[]
for t in range(12):
    hs = tuple(sorted(rng.sample(ALL,2)))
    num,dnm,_ = denoise_full(list(hs))
    r=ratio_of_means(num,dnm); nulls.append(r)
    print(f"   random {str(hs):24s} recovery {r:+7.4f}")
nulls=np.array(nulls)
print(f"\nrandom-2 null: mean {nulls.mean():+.4f}  max {nulls.max():+.4f}  (circuit C = {rows[0][2]:.4f})")

"""ALT-EXPLANATION TEST for the tracing-metric finding.

The finding says: the additive margin "provably cannot carry partner-specific
information", so mediation is untestable.

The strongest ALTERNATIVE: the readout is additive in h, but h_d is a CONTEXTUAL
representation of the whole window. So g(h_d) could be partner-aware ("I am a
donor whose acceptor is that AG at 200"). Under that alternative the margin DOES
carry partner info and the mediation experiment is valid -> finding would be wrong.

DECISIVE TEST: mask the TRUE ACCEPTOR's +/-12nt (the partner-specific corruption
that run_tracing.py actually applies) and ask whether the TRUE DONOR's score
g(h_d*) moves. Partner-aware donor rep  => g(h_d*) collapses.
Pure donor site-detector => g(h_d*) is ~invariant.

Also decompose the acceptor-mask and donor-mask MARGIN GAPS into their dA / dD
parts to see whether the observed asymmetry is algebraically forced.
"""
import json, sys
from pathlib import Path

import torch

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "src"))
from gfmcd.adapters.splicebert import SpliceBertAdapter
from gfmcd.splicing.config import load_config
from gfmcd.splicing.context_controls import mask_true_partner_neighborhood
from gfmcd.splicing.io import load_jsonl
from gfmcd.splicing.readout import collate_pair_indices
from gfmcd.splicing.training import load_pair_checkpoint

N = int(sys.argv[1]) if len(sys.argv) > 1 else 150
BATCH = 4

cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"])
mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device="mps",
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
ckpt = REPO / "colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt"
readout, checkpoint = load_pair_checkpoint(ckpt, adapter=adapter)
assert checkpoint.get("extra_metadata", {}).get("regime") == "additive-frozen"
assert checkpoint.get("backbone_state") is None, "backbone must be frozen/pretrained"

ex = load_jsonl(REPO / "results/splicebert_partner_selection/circuits/discovery/confirmation.jsonl")[:N]
print(f"n examples = {len(ex)}  (confirmation split = conflict examples)")


def terms(examples, seqs):
    """Return per-pair A, D, L term tensors + pair batch, for given sequences."""
    tok = adapter.tokenize(seqs)
    pb = collate_pair_indices(examples, token_offset=tok.prefix_tokens, device=adapter.device)
    with torch.no_grad():
        out = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
        h = out.hidden_states[rep]
        b = torch.arange(h.shape[0], device=h.device)[:, None]
        h_a = h[b, pb.positions[..., 0]]
        h_d = h[b, pb.positions[..., 1]]
        A = readout.acceptor(h_a).squeeze(-1)
        D = readout.donor(h_d).squeeze(-1)
        L = readout.length(readout._length_features(pb.lengths)).squeeze(-1)
    return A, D, L, pb


def margin_parts(A, D, L, pb):
    """true-minus-best-decoy, and the dA/dD/dL decomposition at the argmax decoy."""
    logits = (A + D + L).masked_fill(~pb.mask, torch.finfo(A.dtype).min)
    b = torch.arange(logits.shape[0], device=logits.device)
    lab = pb.labels
    dec = logits.clone()
    dec[b, lab] = torch.finfo(logits.dtype).min
    j = dec.argmax(-1)
    marg = logits[b, lab] - logits[b, j]
    return marg, A[b, lab] - A[b, j], D[b, lab] - D[b, j], L[b, lab] - L[b, j], j


acc = {k: [] for k in
       ("m_clean", "m_amask", "m_dmask",
        "Dtrue_clean", "Dtrue_amask", "Dtrue_dmask",
        "Atrue_clean", "Atrue_amask", "Atrue_dmask",
        "dA_clean", "dD_clean", "share_acc")}

for i in range(0, len(ex), BATCH):
    chunk = ex[i:i + BATCH]
    clean = [x.sequence for x in chunk]
    amask = [mask_true_partner_neighborhood(x, kind="acceptor", flank=12) for x in chunk]
    dmask = [mask_true_partner_neighborhood(x, kind="donor", flank=12) for x in chunk]

    Ac, Dc, Lc, pb = terms(chunk, clean)
    Aa, Da, La, _ = terms(chunk, amask)
    Ad, Dd, Ld, _ = terms(chunk, dmask)

    b = torch.arange(len(chunk), device=Ac.device)
    lab = pb.labels

    mc_, dA, dD, dL, jc = margin_parts(Ac, Dc, Lc, pb)
    ma_, *_ = margin_parts(Aa, Da, La, pb)
    md_, *_ = margin_parts(Ad, Dd, Ld, pb)

    acc["m_clean"] += mc_.tolist()
    acc["m_amask"] += ma_.tolist()
    acc["m_dmask"] += md_.tolist()
    acc["Dtrue_clean"] += Dc[b, lab].tolist()
    acc["Dtrue_amask"] += Da[b, lab].tolist()
    acc["Dtrue_dmask"] += Dd[b, lab].tolist()
    acc["Atrue_clean"] += Ac[b, lab].tolist()
    acc["Atrue_amask"] += Aa[b, lab].tolist()
    acc["Atrue_dmask"] += Ad[b, lab].tolist()
    acc["dA_clean"] += dA.tolist()
    acc["dD_clean"] += dD.tolist()
    # does the top decoy share the TRUE acceptor position?
    same = (pb.positions[b, jc, 0] == pb.positions[b, lab, 0])
    acc["share_acc"] += same.float().tolist()

import statistics as st
mean = lambda k: st.mean(acc[k])
n = len(acc["m_clean"])

res = {
    "n": n,
    "clean": {
        "mean_margin": mean("m_clean"),
        "mean_dA": mean("dA_clean"),
        "mean_dD": mean("dD_clean"),
        "top_decoy_shares_true_acceptor": mean("share_acc"),
    },
    "acceptor_mask (the PARTNER-SPECIFIC corruption)": {
        "margin_gap_clean_minus_corrupt": mean("m_clean") - mean("m_amask"),
        "TRUE_DONOR_score_clean": mean("Dtrue_clean"),
        "TRUE_DONOR_score_after_masking_acceptor": mean("Dtrue_amask"),
        "delta_g_h_dstar": mean("Dtrue_clean") - mean("Dtrue_amask"),
        "TRUE_ACCEPTOR_score_clean": mean("Atrue_clean"),
        "TRUE_ACCEPTOR_score_after_masking_acceptor": mean("Atrue_amask"),
        "delta_f_h_astar": mean("Atrue_clean") - mean("Atrue_amask"),
    },
    "donor_mask": {
        "margin_gap_clean_minus_corrupt": mean("m_clean") - mean("m_dmask"),
        "TRUE_DONOR_score_clean": mean("Dtrue_clean"),
        "TRUE_DONOR_score_after_masking_donor": mean("Dtrue_dmask"),
        "delta_g_h_dstar": mean("Dtrue_clean") - mean("Dtrue_dmask"),
        "delta_f_h_astar": mean("Atrue_clean") - mean("Atrue_dmask"),
    },
}
print(json.dumps(res, indent=2))
(Path(__file__).parent / "alt_partner_aware_rep_results.json").write_text(json.dumps(res, indent=2))

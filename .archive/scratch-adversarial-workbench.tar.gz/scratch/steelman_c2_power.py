#!/usr/bin/env python
"""STEELMAN of C2: does the interaction-vs-additive contrast actually have power?

The finding under review asserts the comparison has "demonstrably zero statistical
power" and that the 96% additive-R^2 of the learned interaction term proves the
bilinear head cannot fit interactions.  Both are testable:

  A. CALIBRATION of the R^2 statistic.  A bilinear form x_a . y_d is EXACTLY
     (mean terms = additive) + (delta_x . delta_y).  So a high two-way additive R^2
     may be a property of BERT hidden-state geometry, not of learning.  Measure the
     same statistic on (i) the trained interaction head, (ii) randomly-INITIALISED
     bilinear heads, (iii) an OLS noise floor.  If a random head also scores ~0.95,
     the statistic is uninformative about training.

  B. POSITIVE CONTROL / POWER CURVE.  Plant a known, purely non-additive
     interaction of controlled strength alpha on the REAL frozen representations,
     relabel the true pair as the teacher's argmax, and retrain BOTH readouts with
     the study's exact hyper-parameters.  If BilinearPairReadout recovers the
     planted interaction (and AdditivePairReadout cannot), the estimator has power
     and the C2 null is informative.

Nothing in the repo is modified.  Writes scratch/steelman_c2_power_results.json.
"""
from __future__ import annotations

import json
from pathlib import Path
import sys
import time

import numpy as np
import torch
from torch import nn

REPO = Path(
    "/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation"
)
sys.path.insert(0, str(REPO / "src"))

from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.readout import (  # noqa: E402
    AdditivePairReadout,
    BilinearPairReadout,
    PairIndexBatch,
)
from gfmcd.splicing.schema import SplicePairExample  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint, set_seed  # noqa: E402

N_TOTAL = int(sys.argv[1]) if len(sys.argv) > 1 else 2000
N_TRAIN = int(N_TOTAL * 0.8)
BATCH = 8
device = "mps" if torch.backends.mps.is_available() else "cpu"

cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
REP = int(cfg["readout"]["representation_layer"])
HID = 512
RANK = int(cfg["readout"]["interaction_rank"])
SITE_HIDDEN = int(cfg["readout"]["site_hidden"])
LEN_HIDDEN = int(cfg["readout"]["length_hidden"])
TC = cfg["training"]

mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"],
    tokenizer_mode=mc.get("tokenizer_mode", "auto"),
    device=device,
    trust_remote_code=False,
    local_files_only=True,
    model_class=mc.get("model_class", "masked_lm"),
)

# ---------------------------------------------------------------- load examples
val_path = REPO / "data/processed/splicebert_partner_selection/v1/val.jsonl"
examples: list[SplicePairExample] = []
with val_path.open() as fh:
    for line in fh:
        if line.strip():
            examples.append(SplicePairExample.from_json(line))
        if len(examples) >= N_TOTAL:
            break
print(f"loaded {len(examples)} val examples; mean pairs {np.mean([len(x.pairs) for x in examples]):.1f}")


# ------------------------------------------------- cache frozen site reps (once)
class Cached:
    __slots__ = ("h", "pos", "lengths", "acc_idx", "don_idx", "true")


def cache_examples(exs):
    out = []
    t0 = time.time()
    for i in range(0, len(exs), BATCH):
        chunk = exs[i : i + BATCH]
        tok = adapter.tokenize([x.sequence for x in chunk])
        with torch.no_grad():
            res = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
            hidden = res.hidden_states[REP].float().cpu()
        off = tok.prefix_tokens
        for k, x in enumerate(chunk):
            accs = sorted({p.acceptor_pos for p in x.pairs})
            dons = sorted({p.donor_pos for p in x.pairs})
            sites = accs + dons  # acceptors first, then donors (disjoint index blocks)
            imap = {("a", p): j for j, p in enumerate(accs)}
            imap.update({("d", p): len(accs) + j for j, p in enumerate(dons)})
            c = Cached()
            c.h = hidden[k, [p + off for p in sites]].clone().half()  # [n_sites, 512]
            c.pos = torch.tensor(
                [[imap[("a", p.acceptor_pos)], imap[("d", p.donor_pos)]] for p in x.pairs],
                dtype=torch.long,
            )
            c.lengths = torch.tensor([float(p.exon_length) for p in x.pairs])
            c.acc_idx = c.pos[:, 0].numpy()
            c.don_idx = c.pos[:, 1].numpy()
            c.true = int(x.true_pair_index)
            out.append(c)
        if i % 400 == 0:
            print(f"  cached {i}/{len(exs)}  ({time.time()-t0:.0f}s)", flush=True)
    return out


cache = cache_examples(examples)
print(f"cached {len(cache)} examples")


def make_batch(items, device=None):
    """Compact hidden [B,S,D] + PairIndexBatch with labels supplied separately."""
    B = len(items)
    S = max(c.h.shape[0] for c in items)
    P = max(c.pos.shape[0] for c in items)
    hidden = torch.zeros(B, S, HID)
    positions = torch.zeros(B, P, 2, dtype=torch.long)
    lengths = torch.zeros(B, P)
    mask = torch.zeros(B, P, dtype=torch.bool)
    for b, c in enumerate(items):
        n = c.h.shape[0]
        p = c.pos.shape[0]
        hidden[b, :n] = c.h.float()
        positions[b, :p] = c.pos
        lengths[b, :p] = c.lengths
        mask[b, :p] = True
    if device is not None:
        hidden = hidden.to(device)
        positions = positions.to(device)
        lengths = lengths.to(device)
        mask = mask.to(device)
    return hidden, positions, lengths, mask


def score_all(readout, items, labels, device, want=("logits",)):
    """Run readout over items, return per-example numpy logit vectors (masked)."""
    outs = []
    readout.eval()
    with torch.no_grad():
        for i in range(0, len(items), BATCH):
            chunk = items[i : i + BATCH]
            hidden, positions, lengths, mask = make_batch(chunk, device)
            pb = PairIndexBatch(
                positions,
                lengths,
                mask,
                torch.zeros(len(chunk), dtype=torch.long, device=device),
            )
            lg = readout(hidden, pb).float().cpu()
            for k, c in enumerate(chunk):
                outs.append(lg[k, : c.pos.shape[0]].numpy())
    return outs


# ---------------------------------------------------- A. calibrate the additive R^2
def additive_fit(y, acc, don):
    """OLS: y ~ 1 + acceptor dummies + donor dummies.  Returns fit, R2, adj R2."""
    ua, ia = np.unique(acc, return_inverse=True)
    ud, idd = np.unique(don, return_inverse=True)
    n = len(y)
    cols = [np.ones((n, 1))]
    if len(ua) > 1:
        Xa = np.zeros((n, len(ua) - 1))
        Xa[np.arange(n), ia - 1] = (ia > 0).astype(float)
        Xa[ia == 0] = 0.0
        cols.append(Xa)
    if len(ud) > 1:
        Xd = np.zeros((n, len(ud) - 1))
        Xd[np.arange(n), idd - 1] = (idd > 0).astype(float)
        Xd[idd == 0] = 0.0
        cols.append(Xd)
    X = np.concatenate(cols, axis=1)
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    fit = X @ beta
    ss_res = float(((y - fit) ** 2).sum())
    ss_tot = float(((y - y.mean()) ** 2).sum())
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else np.nan
    p = X.shape[1]
    adj = 1 - (1 - r2) * (n - 1) / max(n - p, 1)
    return fit, r2, adj, p, n


def interaction_values(head: BilinearPairReadout, items, device):
    vals = []
    head.eval()
    with torch.no_grad():
        for i in range(0, len(items), BATCH):
            chunk = items[i : i + BATCH]
            hidden, positions, lengths, mask = make_batch(chunk, device)
            pb = PairIndexBatch(
                positions, lengths, mask, torch.zeros(len(chunk), dtype=torch.long, device=device)
            )
            it = head.interaction(hidden, pb).float().cpu()
            for k, c in enumerate(chunk):
                vals.append(it[k, : c.pos.shape[0]].numpy().astype(np.float64))
    return vals


CAL_N = 200
cal_items = cache[:CAL_N]
calib = {}

# (i) trained interaction heads
for seed in (0, 1, 2):
    ro, ck = load_pair_checkpoint(
        REPO / f"colab_results/splicebert_run/runs/interaction-frozen_seed{seed}/checkpoint.pt",
        adapter=adapter,
    )
    assert isinstance(ro, BilinearPairReadout)
    ro.to(device)
    vals = interaction_values(ro, cal_items, device)
    r2s = [additive_fit(v, c.acc_idx, c.don_idx)[1] for v, c in zip(vals, cal_items)]
    adjs = [additive_fit(v, c.acc_idx, c.don_idx)[2] for v, c in zip(vals, cal_items)]
    calib[f"trained_seed{seed}"] = dict(r2=float(np.mean(r2s)), adj_r2=float(np.mean(adjs)))

# (ii) randomly-initialised (UNTRAINED) bilinear heads
for s in range(3):
    set_seed(100 + s)
    ro = BilinearPairReadout(HID, RANK, SITE_HIDDEN, LEN_HIDDEN).to(device)
    vals = interaction_values(ro, cal_items, device)
    r2s = [additive_fit(v, c.acc_idx, c.don_idx)[1] for v, c in zip(vals, cal_items)]
    adjs = [additive_fit(v, c.acc_idx, c.don_idx)[2] for v, c in zip(vals, cal_items)]
    calib[f"random_init_{s}"] = dict(r2=float(np.mean(r2s)), adj_r2=float(np.mean(adjs)))

# (iii) OLS noise floor
rng = np.random.default_rng(0)
r2s, adjs = [], []
for c in cal_items:
    y = rng.standard_normal(len(c.acc_idx))
    _, r2, adj, _, _ = additive_fit(y, c.acc_idx, c.don_idx)
    r2s.append(r2)
    adjs.append(adj)
calib["ols_noise_floor"] = dict(r2=float(np.mean(r2s)), adj_r2=float(np.mean(adjs)))
print("\n[A] two-way additive R^2 calibration")
for k, v in calib.items():
    print(f"   {k:>18}: R2={v['r2']:.4f}  adjR2={v['adj_r2']:.4f}")

# ---------------------------------------------- B. planted-interaction power curve
# Teacher additive component: the REAL trained additive-frozen seed0 logits
add_ro, _ = load_pair_checkpoint(
    REPO / "colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt", adapter=adapter
)
add_ro.to(device)
add_logits = score_all(add_ro, cache, None, device)

# Teacher interaction component: random rank-8 bilinear on the SAME frozen reps,
# with all additive structure PROJECTED OUT (so it is purely joint), unit SD/example.
set_seed(1234)
Wl = torch.randn(HID, 8) / np.sqrt(HID)
Wr = torch.randn(HID, 8) / np.sqrt(HID)
teacher_int = []
for c in cache:
    x = (c.h.float() @ Wl).numpy().astype(np.float64)  # [n_sites, 8]
    y = (c.h.float() @ Wr).numpy().astype(np.float64)
    m = (x[c.acc_idx] * y[c.don_idx]).sum(-1)  # bilinear on each pair
    fit, *_ = additive_fit(m, c.acc_idx, c.don_idx)
    resid = m - fit  # purely non-additive by construction
    sd = resid.std()
    teacher_int.append(resid / (sd if sd > 1e-8 else 1.0))

add_std = []
for v in add_logits:
    v = v.astype(np.float64)
    add_std.append((v - v.mean()) / (v.std() + 1e-8))

tr = cache[:N_TRAIN]
ev = cache[N_TRAIN:]
print(f"\n[B] planted-interaction power curve  (train {len(tr)} / eval {len(ev)})")


def train_probe(kind, labels, seed):
    set_seed(seed)
    ro = (
        AdditivePairReadout(HID, SITE_HIDDEN, LEN_HIDDEN)
        if kind == "additive"
        else BilinearPairReadout(HID, RANK, SITE_HIDDEN, LEN_HIDDEN)
    ).to(device)
    opt = torch.optim.AdamW(
        ro.parameters(), lr=float(TC["learning_rate"]), weight_decay=float(TC["weight_decay"])
    )
    idx_tr = list(range(len(tr)))
    best_val = float("inf")
    best_state = None
    stale = 0
    import random as _r

    for epoch in range(1, int(TC["epochs"]) + 1):
        ro.train()
        _r.Random(seed + epoch).shuffle(idx_tr)
        for i in range(0, len(idx_tr), BATCH):
            ids = idx_tr[i : i + BATCH]
            chunk = [tr[j] for j in ids]
            hidden, positions, lengths, mask = make_batch(chunk, device)
            lab = torch.tensor([labels[j] for j in ids], dtype=torch.long, device=device)
            pb = PairIndexBatch(positions, lengths, mask, lab)
            opt.zero_grad(set_to_none=True)
            logits = ro(hidden, pb)
            loss = nn.functional.cross_entropy(logits, lab)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(ro.parameters(), float(TC["grad_clip"]))
            opt.step()
        # val loss on eval slice
        ro.eval()
        tot, n = 0.0, 0
        with torch.no_grad():
            for i in range(0, len(ev), BATCH):
                chunk = ev[i : i + BATCH]
                hidden, positions, lengths, mask = make_batch(chunk, device)
                lab = torch.tensor(
                    [labels[N_TRAIN + i + k] for k in range(len(chunk))],
                    dtype=torch.long,
                    device=device,
                )
                pb = PairIndexBatch(positions, lengths, mask, lab)
                lg = ro(hidden, pb)
                tot += float(nn.functional.cross_entropy(lg, lab, reduction="sum"))
                n += len(chunk)
        vl = tot / n
        if vl < best_val - 1e-8:
            best_val, stale = vl, 0
            best_state = {k: v.detach().cpu().clone() for k, v in ro.state_dict().items()}
        else:
            stale += 1
            if stale > int(TC["early_stopping_patience"]):
                break
    if best_state is not None:
        ro.load_state_dict(best_state)
    ro.to(device)
    # eval top-1
    logits = score_all(ro, ev, None, device)
    acc = float(
        np.mean([int(np.argmax(l) == labels[N_TRAIN + k]) for k, l in enumerate(logits)])
    )
    int_r2 = None
    if kind == "bilinear":
        vals = interaction_values(ro, ev[:100], device)
        int_r2 = float(
            np.mean([additive_fit(v, c.acc_idx, c.don_idx)[1] for v, c in zip(vals, ev[:100])])
        )
    return acc, best_val, int_r2


results = {}
for alpha in (0.0, 1.0, 2.0, 4.0):
    teacher = [add_std[i] + alpha * teacher_int[i] for i in range(len(cache))]
    labels = [int(np.argmax(t)) for t in teacher]
    # how often the additive component ALONE already picks the teacher's argmax
    add_oracle = float(np.mean([int(np.argmax(add_std[i]) == labels[i]) for i in range(len(cache))]))
    row = dict(alpha=alpha, additive_oracle_top1=add_oracle)
    for kind in ("additive", "bilinear"):
        acc, vl, ir2 = train_probe(kind, labels, 0)
        row[f"{kind}_top1"] = acc
        row[f"{kind}_val_loss"] = vl
        if ir2 is not None:
            row["learned_interaction_additive_r2"] = ir2
    row["bilinear_minus_additive"] = row["bilinear_top1"] - row["additive_top1"]
    results[str(alpha)] = row
    print(
        f"   alpha={alpha:<4} add-oracle={add_oracle:.3f}  additive={row['additive_top1']:.3f}  "
        f"bilinear={row['bilinear_top1']:.3f}  delta={row['bilinear_minus_additive']:+.3f}  "
        f"learned-int-R2={row.get('learned_interaction_additive_r2', float('nan')):.3f}",
        flush=True,
    )

out = dict(
    n_total=len(cache),
    n_train=N_TRAIN,
    calibration_additive_r2=calib,
    power_curve=results,
    note="alpha=0 is a purely additive teacher (real trained additive-frozen seed0 logits, "
    "standardised); alpha>0 adds a purely non-additive planted interaction of that many SDs.",
)
(REPO / "scratch/steelman_c2_power_results.json").write_text(json.dumps(out, indent=2))
print("\nwrote scratch/steelman_c2_power_results.json")

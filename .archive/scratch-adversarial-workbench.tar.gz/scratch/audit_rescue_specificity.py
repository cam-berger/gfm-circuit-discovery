"""AUDIT: is 'restore L3H1's head output @all-pos' a rescue test that CAN FAIL?

run_l2_accounting.py claims: with L2H15 ablated, restoring L3H1's head output at all
positions to its L2H15-INTACT value rescues 0.997 of L2H15's effect  =>  "L2H15's entire
contribution routes through L3H1".

The same patch, applied after ablating a head that has NOTHING to do with the claimed
circuit, must NOT rescue ~1.0 -- otherwise the number measures "L3H1 is the bottleneck for
the whole coupling", which is true of every upstream head, and says nothing about L2H15.
"""
import sys
from contextlib import ExitStack
from pathlib import Path

import numpy as np
import torch

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "src"))

from gfmcd.splicing.circuit import (  # noqa: E402
    ADDRESSER, DEFAULT_FASTA, DEFAULT_GTF, DEFAULT_MODEL, READER, CouplingTask, ablate,
    capture_head_outputs, load_adapter, load_examples, patch_heads, pick_device,
    ratio_of_means,
)

N = int(sys.argv[1]) if len(sys.argv) > 1 else 30
BATCH = 6

dev = pick_device(None)
ad = load_adapter(DEFAULT_MODEL, dev)
task = CouplingTask(ad, batch=BATCH)

X, _ = load_examples(DEFAULT_GTF, DEFAULT_FASTA, "val", N, task=task, tag="l2acct-val",
                     min_effect=0.3)
print(f"{len(X)} val exons  device={dev}")

# the head we ablate: L2H15 (the claim) + non-circuit heads with a real coupling effect
ABLATED = [ADDRESSER, (1, 12), (2, 4), (1, 13), (0, 5), (2, 8)]

num = {z: [] for z in ABLATED}
dnm = {z: [] for z in ABLATED}
base_l, abl_l = {z: [] for z in ABLATED}, {z: [] for z in ABLATED}

with torch.no_grad():
    for i in range(0, len(X), BATCH):
        ch = X[i:i + BATCH]
        cl, co, dn = task.pair(ch)

        # sources: captured with the target head INTACT (exactly as run_l2_accounting does)
        h_cl = capture_head_outputs(ad, lambda: ad.model(**cl))
        h_co = capture_head_outputs(ad, lambda: ad.model(**co))

        m_cl = task.margin(ad.model(**cl).logits.float(), dn)
        m_co = task.margin(ad.model(**co).logits.float(), dn)
        cbase = m_cl - m_co

        for z in ABLATED:
            ABL = ablate(ad, [z])
            with ABL():
                a_cl = task.margin(ad.model(**cl).logits.float(), dn)
                a_co = task.margin(ad.model(**co).logits.float(), dn)
            cabl = a_cl - a_co

            with ExitStack() as st:
                st.enter_context(ABL())
                st.enter_context(patch_heads(ad, h_cl, [READER]))
                r_cl = task.margin(ad.model(**cl).logits.float(), dn)
            with ExitStack() as st:
                st.enter_context(ABL())
                st.enter_context(patch_heads(ad, h_co, [READER]))
                r_co = task.margin(ad.model(**co).logits.float(), dn)

            base_l[z] += cbase.tolist()
            abl_l[z] += cabl.tolist()
            dnm[z] += (cbase - cabl).tolist()
            num[z] += ((r_cl - r_co) - cabl).tolist()
        print(f"  {min(i+BATCH, len(X))}/{len(X)}", end="\r", flush=True)
print()

print("\n" + "=" * 86)
print("RESCUE of 'restore L3H1 head output @all-pos' AFTER ABLATING head Z")
print(f"{'ablated Z':12s} {'baseline':>9s} {'Z-ablated':>10s} {'Z supplies':>11s} "
      f"{'RESCUE by L3H1 out':>19s}")
for z in ABLATED:
    b = np.mean(base_l[z]); a = np.mean(abl_l[z]); d = np.asarray(dnm[z])
    r = ratio_of_means(num[z], d)
    tag = "  <- THE CLAIM (L2H15)" if z == ADDRESSER else "  <- non-circuit control"
    print(f"L{z[0]}H{z[1]:<9d} {b:9.3f} {a:10.3f} {d.mean():11.3f} {r:19.3f}{tag}")
print("=" * 86)

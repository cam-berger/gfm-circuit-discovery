"""Adversarial check of the 'control position lands on real AG -> spurious recovery' claim."""
import sys, numpy as np, torch
sys.path.insert(0, "src")
from gfmcd.splicing.circuit import (
    ACC_WINDOW_OFFSETS, CORRUPT_ALT, DEFAULT_FASTA, DEFAULT_GTF, DEFAULT_MODEL,
    CouplingTask, _dataset, eligible, load_adapter, patch_proj, pick_device,
)
from gfmcd.splicing.coupling import substitute

X = eligible(_dataset(DEFAULT_GTF, DEFAULT_FASTA), "val")
print("val eligible n =", len(X))

# ---- descriptive: where does the control anchor land? ----
n_exon = n_intr = n_ag = n_ownacc = n_clamp = 0
ag_examples = []
own_examples = []
for x in X:
    gap = x.next_acceptor_pos - x.donor_pos
    raw = x.donor_pos - gap
    c = max(4, raw)
    if raw != c:
        n_clamp += 1
    if c >= x.acceptor_pos:          # acceptor_pos = first exon base, donor_pos = first intron base
        n_exon += 1
    else:
        n_intr += 1
    if x.sequence[c - 2:c] == "AG":
        n_ag += 1
        ag_examples.append(x)
    if abs(c - x.acceptor_pos) <= 2:
        n_ownacc += 1
        own_examples.append(x)
N = len(X)
print(f"  control lands in EXON            : {n_exon} ({100*n_exon/N:.1f}%)")
print(f"  control lands in UPSTREAM INTRON : {n_intr} ({100*n_intr/N:.1f}%)")
print(f"  real AG at control anchor        : {n_ag} ({100*n_ag/N:.1f}%)")
print(f"  within +-2 of own acceptor       : {n_ownacc} ({100*n_ownacc/N:.1f}%)")
print(f"  clamped by max(4,.)              : {n_clamp}")

# ---- the decisive test: does AG-ness of the control produce recovery? ----
dev = pick_device()
ad = load_adapter(DEFAULT_MODEL, dev)
task = CouplingTask(ad, batch=6)
OFF = ad.prefix_tokens
L3, H3 = 3, 1


def run(exs, label):
    num_k, num_kv, dnm = [], [], []
    with torch.no_grad():
        for i in range(0, len(exs), 6):
            ch = exs[i:i + 6]
            dn = [x.donor_pos for x in ch]
            cl = task.encode([x.sequence for x in ch], dn)
            co = task.encode(
                [substitute(x.sequence, x.next_acceptor_pos - 2, CORRUPT_ALT) for x in ch], dn)
            # cache clean key/value projections
            store = {}
            hs = []
            for w in ("key", "value"):
                m = getattr(ad.attention_self_modules[L3], w)
                hs.append(m.register_forward_hook(
                    lambda _m, _i, o, w=w: store.__setitem__(w, o.detach().clone())))
            m_c = task.margin(ad.model(**cl).logits.float(), dn)
            for h in hs:
                h.remove()
            m_k = task.margin(ad.model(**co).logits.float(), dn)
            dnm += (m_c - m_k).tolist()

            ctl = torch.tensor(
                [[max(4, (x.donor_pos + OFF) - (x.next_acceptor_pos - x.donor_pos)) + k
                  for k in ACC_WINDOW_OFFSETS] for x in ch], device=dev)
            acc = torch.tensor(
                [[x.next_acceptor_pos + OFF + k for k in ACC_WINDOW_OFFSETS] for x in ch],
                device=dev)

            with patch_proj(ad, L3, H3, "key", store["key"], ctl):
                mk1 = task.margin(ad.model(**co).logits.float(), dn)
            num_k += (mk1 - m_k).tolist()
            from contextlib import ExitStack
            with ExitStack() as st:
                st.enter_context(patch_proj(ad, L3, H3, "key", store["key"], ctl))
                st.enter_context(patch_proj(ad, L3, H3, "value", store["value"], ctl))
                mk2 = task.margin(ad.model(**co).logits.float(), dn)
            num_kv += (mk2 - m_k).tolist()
            # sanity: the REAL acceptor window, same machinery
            with ExitStack() as st:
                st.enter_context(patch_proj(ad, L3, H3, "key", store["key"], acc))
                st.enter_context(patch_proj(ad, L3, H3, "value", store["value"], acc))
                mk3 = task.margin(ad.model(**co).logits.float(), dn)
            if i == 0:
                real = (mk3 - m_k).sum().item() / max((m_c - m_k).sum().item(), 1e-9)
    D = sum(dnm)
    print(f"{label:38s} n={len(exs):3d}  denom(mean coupling)={np.mean(dnm):+.3f}")
    print(f"   key@control-pos   recovery = {sum(num_k)/D:+.6f}")
    print(f"   key+value@control recovery = {sum(num_kv)/D:+.6f}")
    print(f"   [acceptor window, first batch, ref] = {real:+.4f}")


ag_ex = [x for x in ag_examples][:60]
own_ex = [x for x in own_examples][:40]
non_ag = [x for x in X if x.sequence[max(4, x.donor_pos - (x.next_acceptor_pos - x.donor_pos)) - 2:
                                    max(4, x.donor_pos - (x.next_acceptor_pos - x.donor_pos))] != "AG"][:60]

run(ag_ex, "CONTROL LANDS ON A REAL AG")
run(own_ex, "CONTROL ON THE EXON'S OWN ACCEPTOR AG")
run(non_ag, "CONTROL NOT ON AN AG (the other 93%)")

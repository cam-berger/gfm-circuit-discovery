"""AUDIT (decisive): the 'L3H1 head output @all-pos' rescue CANNOT FAIL.

If restoring L3H1's head output at all positions rescues ~1.0 of the effect of ANY upstream
ablation -- including mean-ablating ALL 48 heads of layers 0-2 at once -- then the 0.966/0.997
number is a property of L3H1's output being the carrier of the coupling, not evidence that
L2H15's contribution routes through L3H1.
"""
import sys
from contextlib import ExitStack
from pathlib import Path

import numpy as np
import torch

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "src"))

from gfmcd.splicing.circuit import (  # noqa: E402
    ADDRESSER, DEFAULT_FASTA, DEFAULT_GTF, DEFAULT_MODEL, READER, CouplingTask, ablate,
    capture_head_outputs, load_adapter, load_examples, patch_heads, pick_device,
    ratio_of_means,
)

N, BATCH = 30, 6
dev = pick_device(None)
ad = load_adapter(DEFAULT_MODEL, dev)
task = CouplingTask(ad, batch=BATCH)
X, _ = load_examples(DEFAULT_GTF, DEFAULT_FASTA, "val", N, task=task, tag="l2acct-val",
                     min_effect=0.3)

ALL_L012 = [(l, h) for l in range(3) for h in range(ad.num_heads)]   # 48 heads
SETS = [("L2H15 (the published claim)", [ADDRESSER]),
        ("ALL 48 heads of layers 0-2", ALL_L012)]

num = {k: [] for k, _ in SETS}
dnm = {k: [] for k, _ in SETS}
bl = {k: [] for k, _ in SETS}
al = {k: [] for k, _ in SETS}

with torch.no_grad():
    for i in range(0, len(X), BATCH):
        cl, co, dn = task.pair(X[i:i + BATCH])
        h_cl = capture_head_outputs(ad, lambda: ad.model(**cl))
        h_co = capture_head_outputs(ad, lambda: ad.model(**co))
        cbase = (task.margin(ad.model(**cl).logits.float(), dn)
                 - task.margin(ad.model(**co).logits.float(), dn))
        for name, Z in SETS:
            ABL = ablate(ad, Z)
            with ABL():
                cabl = (task.margin(ad.model(**cl).logits.float(), dn)
                        - task.margin(ad.model(**co).logits.float(), dn))
            with ExitStack() as st:
                st.enter_context(ABL())
                st.enter_context(patch_heads(ad, h_cl, [READER]))
                r_cl = task.margin(ad.model(**cl).logits.float(), dn)
            with ExitStack() as st:
                st.enter_context(ABL())
                st.enter_context(patch_heads(ad, h_co, [READER]))
                r_co = task.margin(ad.model(**co).logits.float(), dn)
            bl[name] += cbase.tolist()
            al[name] += cabl.tolist()
            dnm[name] += (cbase - cabl).tolist()
            num[name] += ((r_cl - r_co) - cabl).tolist()
        print(f"  {min(i+BATCH, len(X))}/{len(X)}", end="\r", flush=True)
print()

print("=" * 84)
print(f"{'ablated Z':30s} {'baseline':>9s} {'Z-ablated':>10s} {'Z supplies':>11s} "
      f"{'rescue by L3H1-out':>19s}")
for name, Z in SETS:
    print(f"{name:30s} {np.mean(bl[name]):9.3f} {np.mean(al[name]):10.3f} "
          f"{np.mean(dnm[name]):11.3f} {ratio_of_means(num[name], dnm[name]):19.3f}")
print("=" * 84)

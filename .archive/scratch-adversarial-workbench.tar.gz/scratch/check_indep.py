import json, math, itertools
import numpy as np

def load_first_n(path, n):
    out=[]
    with open(path) as f:
        for i,line in enumerate(f):
            if i>=n: break
            out.append(json.loads(line))
    return out

def analyze(name, src, res):
    src_rows = load_first_n(src, 4000)
    res_rows = [json.loads(l) for l in open(res)]
    assert len(src_rows)==len(res_rows)==4000
    mism = sum(1 for a,b in zip(src_rows,res_rows) if a['example_id']!=b['example_id'])
    A=[];D=[];P=[]
    for s,r in zip(src_rows,res_rows):
        assert s['true_pair_index']==r['true_pair_index']
        pairs=s['pairs']
        pt=pairs[r['true_pair_index']]; pp=pairs[r['predicted_pair_index']]
        a = pp['acceptor_pos']==pt['acceptor_pos']
        d = pp['donor_pos']==pt['donor_pos']
        A.append(a); D.append(d); P.append(r['true_margin']>0)
    A=np.array(A);D=np.array(D);P=np.array(P)
    pair = (A&D)
    pa,pd,pj = A.mean(), D.mean(), pair.mean()
    # phi coefficient / MI
    n=len(A)
    n11=(A&D).sum(); n10=(A&~D).sum(); n01=(~A&D).sum(); n00=(~A&~D).sum()
    phi=(n11*n00-n10*n01)/math.sqrt(max(1,(n11+n10)*(n01+n00)*(n11+n01)*(n10+n00)))
    mi=0.0
    for (x,cnt) in [((1,1),n11),((1,0),n10),((0,1),n01),((0,0),n00)]:
        if cnt==0: continue
        pxy=cnt/n
        px = pa if x[0]==1 else 1-pa
        py = pd if x[1]==1 else 1-pd
        mi += pxy*math.log2(pxy/(px*py))
    # chi2 p-value
    from scipy.stats import fisher_exact, chi2_contingency
    orr, pval = fisher_exact([[n11,n10],[n01,n00]])
    print(f"--- {name}  (id mismatches={mism})")
    print(f"  n={n}  pair(A&D)={pj:.4f}  PMR(margin>0)={P.mean():.4f}  identical={np.array_equal(pair,P)}")
    print(f"  acceptor-marginal={pa:.4f}  donor-marginal={pd:.4f}  product={pa*pd:.5f}")
    print(f"  excess (joint - product) = {pj-pa*pd:+.5f}")
    print(f"  table n11={n11} n10={n10} n01={n01} n00={n00}")
    print(f"  phi={phi:+.4f}  MI={mi:.5f} bits  Fisher OR={orr:.3f} p={pval:.3g}")
    print(f"  P(D correct | A correct)={ (n11/(n11+n10)) if n11+n10 else float('nan'):.4f}  vs marginal P(D)={pd:.4f}")
    print(f"  P(D correct | A wrong)  ={ (n01/(n01+n00)) if n01+n00 else float('nan'):.4f}")
    return dict(pa=float(pa),pd=float(pd),pj=float(pj))

analyze("VAL seed0 additive-frozen",
 "data/processed/splicebert_partner_selection/v1/val.jsonl",
 "results/splicebert_partner_selection/behavior/seed0_additive-frozen/val/per_example_clean.jsonl")
analyze("CONFLICT seed0 additive-frozen",
 "results/splicebert_partner_selection/baselines/val_local_conflicts.jsonl",
 "results/splicebert_partner_selection/behavior/seed0_additive-frozen/val/val_local_conflicts/per_example_clean.jsonl")
analyze("VAL seed0 additive-RANDOM-frozen",
 "data/processed/splicebert_partner_selection/v1/val.jsonl",
 "results/splicebert_partner_selection/behavior/seed0_additive-random-frozen/val/per_example_clean.jsonl")
analyze("CONFLICT seed0 additive-RANDOM-frozen",
 "results/splicebert_partner_selection/baselines/val_local_conflicts.jsonl",
 "results/splicebert_partner_selection/behavior/seed0_additive-random-frozen/val/val_local_conflicts/per_example_clean.jsonl")

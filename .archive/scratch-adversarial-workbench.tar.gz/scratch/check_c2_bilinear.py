#!/usr/bin/env python
"""Referee check of the C2 finding: is the trained bilinear interaction term
effectively additive, and does the bilinear underperform its own nested additive?"""
from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np
import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))

from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.schema import SplicePairExample  # noqa: E402
from gfmcd.splicing.readout import collate_pair_indices  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint  # noqa: E402

N = int(sys.argv[1]) if len(sys.argv) > 1 else 400
BATCH = 8
NEG = float("-inf")

device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"])
mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))

readouts = {}
for seed in (0, 1, 2):
    r, ck = load_pair_checkpoint(
        REPO / f"colab_results/splicebert_run/runs/interaction-frozen_seed{seed}/checkpoint.pt", adapter=adapter)
    assert type(r).__name__ == "BilinearPairReadout", type(r)
    assert ck.get("backbone_state") is None
    readouts[f"bil{seed}"] = r
for seed in (0, 1, 2):
    r, ck = load_pair_checkpoint(
        REPO / f"colab_results/splicebert_run/runs/additive-frozen_seed{seed}/checkpoint.pt", adapter=adapter)
    assert type(r).__name__ == "AdditivePairReadout", type(r)
    assert ck.get("backbone_state") is None
    readouts[f"add{seed}"] = r
print("loaded readouts:", list(readouts))

conf = REPO / "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl"
examples: list[SplicePairExample] = []
with conf.open() as f:
    for line in f:
        if line.strip():
            examples.append(SplicePairExample.from_json(line))
        if len(examples) >= N:
            break
print(f"n={len(examples)} conflict examples, mean pairs {np.mean([len(x.pairs) for x in examples]):.1f}")

store: dict[str, list] = {k: [] for k in readouts}
meta = []  # per example: (t_index, acc positions, don positions)

for i in range(0, len(examples), BATCH):
    ex = examples[i:i + BATCH]
    tok = adapter.tokenize([x.sequence for x in ex])
    pb = collate_pair_indices(ex, token_offset=tok.prefix_tokens, device=adapter.device)
    with torch.no_grad():
        out = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
        hidden = out.hidden_states[rep]
        per = {}
        for name, ro in readouts.items():
            if name.startswith("bil"):
                add = ro.additive(hidden, pb).float().cpu()
                inter = ro.interaction(hidden, pb).float().cpu()
                per[name] = (add, inter)
            else:
                per[name] = (ro(hidden, pb).float().cpu(), None)
    mask = pb.mask.cpu()
    pacc = pb.positions[..., 0].cpu()
    pdon = pb.positions[..., 1].cpu()
    for k, x in enumerate(ex):
        m = mask[k].numpy().astype(bool)
        meta.append(dict(t=x.true_pair_index, acc=pacc[k].numpy()[m], don=pdon[k].numpy()[m]))
        for name, (a, it) in per.items():
            store[name].append((a[k].numpy()[m], None if it is None else it[k].numpy()[m]))

n = len(meta)


def pmr(scores: list[np.ndarray]) -> float:
    hits = 0
    for s, mt in zip(scores, meta):
        t = mt["t"]
        d = s.copy()
        d[t] = -np.inf
        hits += int(s[t] > d.max())
    return hits / n


def additive_fit(y, acc, don, with_len=False):
    """OLS fit of y ~ intercept + acceptor dummies + donor dummies (+ length basis)."""
    ua, ia = np.unique(acc, return_inverse=True)
    ud, id_ = np.unique(don, return_inverse=True)
    cols = [np.ones((len(y), 1))]
    if len(ua) > 1:
        Xa = np.zeros((len(y), len(ua) - 1)); Xa[np.arange(len(y)), ia - 1] = (ia > 0)
        # correct one-hot dropping first level
        Xa = np.zeros((len(y), len(ua) - 1))
        for j in range(1, len(ua)):
            Xa[:, j - 1] = (ia == j)
        cols.append(Xa)
    if len(ud) > 1:
        Xd = np.zeros((len(y), len(ud) - 1))
        for j in range(1, len(ud)):
            Xd[:, j - 1] = (id_ == j)
        cols.append(Xd)
    if with_len:
        L = np.clip(don - acc, 1, None).astype(float)
        cols.append(np.stack([np.log(L), np.sqrt(L), L], axis=1))
    X = np.concatenate(cols, axis=1)
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    fit = X @ beta
    ss_res = float(((y - fit) ** 2).sum())
    ss_tot = float(((y - y.mean()) ** 2).sum())
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else np.nan
    p = X.shape[1]
    adj = 1 - (1 - r2) * (len(y) - 1) / max(len(y) - p, 1)
    return fit, r2, adj, p, len(y)


report = {}
for seed in (0, 1, 2):
    bil = store[f"bil{seed}"]
    add_only = [a for a, _ in bil]
    inter = [it for _, it in bil]
    full = [a + it for a, it in bil]
    r2s, adjs, ps, ns = [], [], [], []
    r2_full, resid_scores, projected_scores = [], [], []
    sd_inter, sd_resid, sd_add = [], [], []
    for k in range(n):
        y = inter[k].astype(np.float64)
        fit, r2, adj, p, nn_ = additive_fit(y, meta[k]["acc"], meta[k]["don"])
        r2s.append(r2); adjs.append(adj); ps.append(p); ns.append(nn_)
        resid = y - fit
        resid_scores.append(resid)
        projected_scores.append(add_only[k].astype(np.float64) + fit)
        sd_inter.append(y.std()); sd_resid.append(resid.std()); sd_add.append(add_only[k].std())
        yf = full[k].astype(np.float64)
        _, r2f, _, _, _ = additive_fit(yf, meta[k]["acc"], meta[k]["don"])
        r2_full.append(r2f)
    # noise floor: additive fit to random gaussian noise of same design
    rng = np.random.default_rng(0)
    noise_r2 = []
    for k in range(min(n, 100)):
        y = rng.standard_normal(len(meta[k]["acc"]))
        _, r2, adj, _, _ = additive_fit(y, meta[k]["acc"], meta[k]["don"])
        noise_r2.append((r2, adj))
    rep_ = dict(
        seed=seed,
        pmr_full_bilinear=pmr(full),
        pmr_additive_submodule=pmr(add_only),
        pmr_interaction_only=pmr(inter),
        pmr_residual_only=pmr(resid_scores),
        pmr_additive_sub_plus_projected_interaction=pmr(projected_scores),
        pmr_additive_frozen_same_seed=pmr([a for a, _ in store[f"add{seed}"]]),
        interaction_r2_mean=float(np.mean(r2s)), interaction_r2_median=float(np.median(r2s)),
        interaction_r2_p5=float(np.percentile(r2s, 5)),
        interaction_r2_adj_mean=float(np.mean(adjs)),
        full_logits_r2_mean=float(np.mean(r2_full)),
        noise_floor_r2_mean=float(np.mean([x[0] for x in noise_r2])),
        noise_floor_adj_r2_mean=float(np.mean([x[1] for x in noise_r2])),
        mean_params=float(np.mean(ps)), mean_obs=float(np.mean(ns)),
        sd_interaction=float(np.mean(sd_inter)), sd_nonadditive_residual=float(np.mean(sd_resid)),
        sd_additive_submodule=float(np.mean(sd_add)),
    )
    report[f"seed{seed}"] = rep_
    print(json.dumps(rep_, indent=2))

(REPO / "scratch/check_c2_bilinear_results.json").write_text(json.dumps(report, indent=2))
print("wrote scratch/check_c2_bilinear_results.json")

#!/usr/bin/env python
"""Is 'the length term is worth 25 top1 points' identifiable from the saved logits?

exon_length = donor_pos - acceptor_pos EXACTLY (schema.PairCandidate.exon_length).
Hence for any c,   f(a)+c*a ,  g(d)-c*d ,  L(l)+c*l   is an EXACTLY equivalent
additive decomposition of the same logits.  So "drop the length term" recovered by
least squares is defined only up to the gauge c.  Sweep c and see how far top1 moves.
"""
from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
N = 1200

# --- load candidate geometry from the conflict file (same order as per_example_clean) ---
geom = {}
order = []
with (REPO / "results/splicebert_partner_selection/baselines/val_local_conflicts.jsonl").open() as f:
    for line in f:
        d = json.loads(line)
        pairs = d["pairs"]
        geom[d["example_id"]] = (
            np.array([p["acceptor_pos"] for p in pairs]),
            np.array([p["donor_pos"] for p in pairs]),
            np.array([p["donor_pos"] - p["acceptor_pos"] for p in pairs]),
            int(d["true_pair_index"]),
        )
        order.append(d["example_id"])
        if len(order) >= N:
            break

rows = []
with (REPO / "results/splicebert_partner_selection/behavior/seed0_additive-frozen/val/val_local_conflicts/per_example_clean.jsonl").open() as f:
    for line in f:
        d = json.loads(line)
        if d["example_id"] not in geom:
            continue
        ap, dp, el, t = geom[d["example_id"]]
        s = np.asarray(d["logits"], dtype=np.float64)[: len(ap)]
        assert d["true_pair_index"] == t
        rows.append(dict(eid=d["example_id"], s=s, ap=ap, dp=dp, el=el, t=t))
        if len(rows) >= N:
            break
print(f"n={len(rows)} examples, saved logits from per_example_clean.jsonl")


def top1(scores):
    ok = don = acc = 0
    for r, s in zip(rows, scores):
        j = int(np.argmax(s))
        ok += j == r["t"]
        don += r["dp"][j] == r["dp"][r["t"]]
        acc += r["ap"][j] == r["ap"][r["t"]]
    n = len(rows)
    return ok / n, acc / n, don / n


print("\nfull saved logits:            pair top1 %.4f  acc-marg %.4f  don-marg %.4f" % top1([r["s"] for r in rows]))

# ---- LS recovery, per-example (unknowns: f per acceptor, g per donor, L per distinct length) ----
resid = []
L_ls_per_ex = []
for r in rows:
    ua, ai = np.unique(r["ap"], return_inverse=True)
    ud, di = np.unique(r["dp"], return_inverse=True)
    ul, li = np.unique(r["el"], return_inverse=True)
    n = len(r["s"])
    X = np.zeros((n, len(ua) + len(ud) + len(ul)))
    X[np.arange(n), ai] = 1
    X[np.arange(n), len(ua) + di] = 1
    X[np.arange(n), len(ua) + len(ud) + li] = 1
    beta, *_ = np.linalg.lstsq(X, r["s"], rcond=None)
    resid.append(float(np.sqrt(np.mean((X @ beta - r["s"]) ** 2))))
    L_ls_per_ex.append(beta[len(ua) + len(ud):][li])
print("per-example LS residual RMSE: median %.6f  (additivity confirmed)" % np.median(resid))

# ---- LS recovery, GLOBAL integer-length function shared across examples ----
# f,g per (example,site) absorbed by centering: solve iteratively (backfitting) since the
# design is huge.  Backfitting on an additive model converges to the LS solution.
Lg = np.zeros(1024)  # index by exon length
for it in range(200):
    # given Lg, f and g are the LS solution of a two-way additive model per example
    num = np.zeros(1024)
    den = np.zeros(1024)
    for r in rows:
        y = r["s"] - Lg[r["el"]]
        ua, ai = np.unique(r["ap"], return_inverse=True)
        ud, di = np.unique(r["dp"], return_inverse=True)
        f = np.zeros(len(ua))
        g = np.zeros(len(ud))
        for _ in range(30):  # inner backfit for the two-way part
            f = np.bincount(ai, weights=y - g[di], minlength=len(ua)) / np.bincount(ai, minlength=len(ua))
            g = np.bincount(di, weights=y - f[ai], minlength=len(ud)) / np.bincount(di, minlength=len(ud))
            g -= g.mean()
        r["_fg"] = f[ai] + g[di]
        res = r["s"] - r["_fg"]
        np.add.at(num, r["el"], res)
        np.add.at(den, r["el"], 1.0)
    newL = np.where(den > 0, num / np.maximum(den, 1e-9), 0.0)
    if np.max(np.abs(newL - Lg)) < 1e-6:
        Lg = newL
        break
    Lg = newL
rmse_g = np.sqrt(np.mean(np.concatenate([(r["s"] - r["_fg"] - Lg[r["el"]]) ** 2 for r in rows])))
print("global-L backfit residual RMSE: %.6f  (iters %d)" % (rmse_g, it + 1))
print("global L range: %.3f .. %.3f" % (Lg[20:501].min(), Lg[20:501].max()))

print("\n=== DROP THE LENGTH TERM, under each recovered decomposition ===")
print("  per-example LS L:  pair top1 %.4f  acc %.4f  don %.4f"
      % top1([r["s"] - L for r, L in zip(rows, L_ls_per_ex)]))
print("  global      LS L:  pair top1 %.4f  acc %.4f  don %.4f"
      % top1([r["s"] - Lg[r["el"]] for r in rows]))

print("\n=== GAUGE SWEEP: score - L_global(l) - c*l  (all are EXACT decompositions of the same logits) ===")
print("     c        pair top1   donor-marginal")
for c in [-0.010, -0.008, -0.006, -0.004, -0.002, 0.0, 0.002, 0.004, 0.006, 0.008, 0.010]:
    t1, am, dm = top1([r["s"] - Lg[r["el"]] - c * r["el"] for r in rows])
    print(f"  {c:+.3f}     {t1:.4f}       {dm:.4f}")

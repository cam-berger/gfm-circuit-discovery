#!/usr/bin/env python
"""Data-check of the 'acceptor-blind readout matches/exceeds full model' finding.

One backbone forward pass (frozen, identical across seeds); apply all 5
additive-frozen readouts to the same hidden states.
"""
from __future__ import annotations

import json
from pathlib import Path
import sys

import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))

from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.schema import SplicePairExample  # noqa: E402
from gfmcd.splicing.readout import collate_pair_indices  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint  # noqa: E402

N = int(sys.argv[1]) if len(sys.argv) > 1 else 1500
BATCH = 8
NEG = float("-inf")
SEEDS = [0, 1, 2, 3, 4]

device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"])
mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))

readouts = {}
for s in SEEDS:
    p = REPO / f"colab_results/splicebert_run/runs/additive-frozen_seed{s}/checkpoint.pt"
    r, ck = load_pair_checkpoint(p, adapter=adapter)
    assert ck.get("backbone_state") is None, f"seed{s} has a backbone_state!"
    readouts[s] = r
    print(f"seed{s}: {type(r).__name__}, regime={ck.get('extra_metadata', {}).get('regime')}, backbone_state=None")

conf = REPO / "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl"
RANDOM = len(sys.argv) > 2 and sys.argv[2] == "random"
examples: list[SplicePairExample] = []
if RANDOM:
    import random
    total = 10034
    random.seed(20260711)
    keep = set(random.sample(range(total), N))
    with conf.open() as f:
        for idx, line in enumerate(f):
            if idx in keep and line.strip():
                examples.append(SplicePairExample.from_json(line))
    print(f"RANDOM sample of {len(examples)} of {total}")
else:
    with conf.open() as f:
        for line in f:
            if line.strip():
                examples.append(SplicePairExample.from_json(line))
            if len(examples) >= N:
                break
print(f"loaded {len(examples)} examples, mean pairs {sum(len(x.pairs) for x in examples)/len(examples):.1f}")

# sanity: true acceptor at raw position 200?
bad = sum(1 for x in examples if x.pairs[x.true_pair_index].acceptor_pos != 200)
print(f"examples whose TRUE acceptor is NOT at raw position 200: {bad}/{len(examples)}")

rows = []
for i in range(0, len(examples), BATCH):
    ex = examples[i:i + BATCH]
    tok = adapter.tokenize([x.sequence for x in ex])
    pb = collate_pair_indices(ex, token_offset=tok.prefix_tokens, device=adapter.device)
    with torch.no_grad():
        out = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
        hidden = out.hidden_states[rep]
        b = torch.arange(hidden.shape[0], device=hidden.device)[:, None]
        h_a = hidden[b, pb.positions[..., 0]]
        h_d = hidden[b, pb.positions[..., 1]]
        per_seed = {}
        for s in SEEDS:
            r = readouts[s]
            A = r.acceptor(h_a).squeeze(-1).float().cpu()
            D = r.donor(h_d).squeeze(-1).float().cpu()
            L = r.length(r._length_features(pb.lengths)).squeeze(-1).float().cpu()
            per_seed[s] = (A, D, L)
    mask = pb.mask.cpu()
    # raw (non-token-offset) positions
    acc = (pb.positions[..., 0] - tok.prefix_tokens).cpu()
    don = (pb.positions[..., 1] - tok.prefix_tokens).cpu()
    for k, x in enumerate(ex):
        m = mask[k]
        t = x.true_pair_index
        rows.append(dict(
            t=t, acc=acc[k][m].clone(), don=don[k][m].clone(),
            terms={s: (per_seed[s][0][k][m].clone(), per_seed[s][1][k][m].clone(), per_seed[s][2][k][m].clone())
                   for s in SEEDS},
        ))
    if (i // BATCH) % 25 == 0:
        print(f"  batch {i//BATCH} / {len(examples)//BATCH}", flush=True)

n = len(rows)


def pmr(score_of):
    hits = 0
    for r in rows:
        s = score_of(r)
        t = r["t"]
        d = s.clone()
        d[t] = NEG
        hits += int(s[t].item() > d.max().item())
    return hits / n


res = {}
for s in SEEDS:
    def T(r, s=s):
        return r["terms"][s]

    IND = 1e3  # indicator weight for f := 1e3 * 1[pos(a)==200]

    def ind(r):
        return IND * (r["acc"] == 200).float()

    v = {}
    v["full A+D+L"] = pmr(lambda r, s=s: T(r)[0] + T(r)[1] + T(r)[2])
    v["ind(a==200)+D+L"] = pmr(lambda r, s=s: ind(r) + T(r)[1] + T(r)[2])
    v["ind(a==200)+D"] = pmr(lambda r, s=s: ind(r) + T(r)[1])
    v["A+D (no length)"] = pmr(lambda r, s=s: T(r)[0] + T(r)[1])
    # TRULY acceptor-blind (no representation AND no position use at all): f == 0
    v["D+L  (f=0, truly acc-blind)"] = pmr(lambda r, s=s: T(r)[1] + T(r)[2])
    v["D only (f=0, no length)"] = pmr(lambda r, s=s: T(r)[1])
    v["L only"] = pmr(lambda r, s=s: T(r)[2])
    # control: keep trained f, but blind the DONOR by a position indicator?
    # true donor raw pos = len(seq)-200 -> equivalently pair with max donor pos? use exon-length identity
    res[s] = v
    print(f"\nseed{s}: " + " | ".join(f"{k}={x:.3f}" for k, x in v.items()))

# binding-decoy composition for the FULL model, per seed
print("\n=== binding (argmax) decoy composition, full model ===")
comp = {}
for s in SEEDS:
    sa = sd = nn_ = 0
    for r in rows:
        A, D, L = r["terms"][s]
        sc = A + D + L
        t = r["t"]
        d = sc.clone(); d[t] = NEG
        j = int(d.argmax())
        a_same = int(r["acc"][j]) == int(r["acc"][t])
        d_same = int(r["don"][j]) == int(r["don"][t])
        if a_same and not d_same:
            sa += 1
        elif d_same and not a_same:
            sd += 1
        elif not a_same and not d_same:
            nn_ += 1
    comp[s] = dict(shares_acc=sa / n, shares_don=sd / n, neither=nn_ / n)
    print(f"  seed{s}: shares true acceptor {sa/n:.3f} | shares true donor {sd/n:.3f} | neither {nn_/n:.3f}")

out = REPO / ("scratch/check_acceptor_blind_results_%s.json" % ("rand" if RANDOM else "first"))
out.write_text(json.dumps(dict(n=n, pmr=res, decoy_composition=comp), indent=2))
print("\nwrote", out)

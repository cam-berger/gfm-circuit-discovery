"""STEELMAN TEST: PMR is decided by the MODEL'S TOP DECOY. Is that decoy a real
annotated splice site (=> a genuine 'which real site is my partner' discrimination),
or a spurious motif (=> mere site detection)?  Also: does the true pair beat the
REAL-SITE decoys specifically, and is that discrimination explained by position alone?"""
from __future__ import annotations
import gzip, json, sys
from collections import defaultdict
from pathlib import Path
import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))
from gfmcd.adapters.splicebert import SpliceBertAdapter
from gfmcd.splicing.config import load_config
from gfmcd.splicing.schema import SplicePairExample
from gfmcd.splicing.readout import collate_pair_indices
from gfmcd.splicing.training import load_pair_checkpoint

STRIDE, NMAX, BATCH = 7, 1200, 8

# --- annotation anchors (chr17/18, all transcripts in the study's own GTF) ---
tx_exons = defaultdict(list); tx_meta = {}
with gzip.open(REPO/"data/external/gencode/v50/gencode.v50.basic.annotation.gtf.gz","rt") as f:
    for line in f:
        if line.startswith("#"): continue
        c = line.rstrip("\n").split("\t")
        if c[2] != "exon" or c[0] not in {"chr17","chr18"}: continue
        tid = c[8].split('transcript_id "',1)[1].split('"',1)[0]
        tx_exons[tid].append((int(c[3])-1,int(c[4]))); tx_meta[tid]=(c[0],c[6])
accA={"+":set(),"-":set()}; donA={"+":set(),"-":set()}
for tid,ex in tx_exons.items():
    ch,st = tx_meta[tid]; e=sorted(ex); e = e[::-1] if st=="-" else e
    for i,(s,en) in enumerate(e):
        a,d = (s,en) if st=="+" else (en-1,s-1)
        if i>0: accA[st].add(a)
        if i<len(e)-1: donA[st].add(d)

device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO/"configs/splicebert_partner_selection/base.json"); rep=int(cfg["readout"]["representation_layer"]); mc=cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(REPO/mc["path"], tokenizer_mode=mc.get("tokenizer_mode","auto"),
    device=device, trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class","masked_lm"))
readout, ck = load_pair_checkpoint(REPO/"colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt", adapter=adapter)
print("regime", ck.get("extra_metadata",{}).get("regime"), "| backbone_state None:", ck.get("backbone_state") is None, "| readout", type(readout).__name__)

examples=[]
with (REPO/"colab_results/splicebert_run/baselines/val_local_conflicts.jsonl").open() as f:
    for i,line in enumerate(f):
        if i % STRIDE: continue
        examples.append(SplicePairExample.from_json(line))
        if len(examples) >= NMAX: break
print(f"loaded {len(examples)} (strided every {STRIDE})")

S=defaultdict(int); marg_all=[]; marg_rr=[]
for i in range(0,len(examples),BATCH):
    ex = examples[i:i+BATCH]
    tok = adapter.tokenize([x.sequence for x in ex])
    pb = collate_pair_indices(ex, token_offset=tok.prefix_tokens, device=adapter.device)
    with torch.no_grad():
        h = adapter.forward(tok, output_hidden_states=True).hidden_states[rep]
        logits = readout(h, pb).float().cpu()
    for k,x in enumerate(ex):
        n=len(x.pairs); lg=logits[k,:n].clone()
        t=x.true_pair_index; tp=x.pairs[t]; ta,td=tp.acceptor_pos,tp.donor_pos
        W=x.metadata["genomic_window_start"]; E=x.metadata["genomic_window_end"]; st=x.strand
        g=(lambda p:W+p) if st=="+" else (lambda p:E-1-p)
        accR={s.position:(g(s.position) in accA[st]) for s in x.acceptors}
        donR={s.position:(g(s.position) in donA[st]) for s in x.donors}
        rr=[j for j,p in enumerate(x.pairs) if j!=t and accR[p.acceptor_pos] and donR[p.donor_pos]]
        dec=lg.clone(); dec[t]=float("-inf")
        j=int(dec.argmax()); m=float(lg[t]-dec[j]); marg_all.append(m)
        S["n"]+=1; S["pmr"]+= m>0
        p=x.pairs[j]
        sa,sd = p.acceptor_pos==ta, p.donor_pos==td
        S["top_shares_acc"]+=sa; S["top_shares_don"]+=sd; S["top_shares_neither"]+= (not sa and not sd)
        S["top_rr"]+= (accR[p.acceptor_pos] and donR[p.donor_pos])
        # is the top decoy's DIFFERING endpoint a real annotated site?
        if sa: S["top_altdonor_real"]+= donR[p.donor_pos]; S["top_sharesacc_n"]+=1
        if sd: S["top_altacc_real"]+= accR[p.acceptor_pos]; S["top_sharesdon_n"]+=1
        if rr:
            S["has_rr"]+=1
            mrr=float(lg[t]-lg[rr].max()); marg_rr.append(mrr)
            S["pmr_vs_rr"]+= mrr>0
            # position-only scorer on the SAME real-site decoys
            L=len(x.sequence)
            pos=lambda pp: -(abs(pp.acceptor_pos-200)+abs(pp.donor_pos-(L-200)))
            S["posrule_beats_rr"]+= all(pos(tp) > pos(x.pairs[j2]) for j2 in rr)

n=S["n"]
print(f"\nN={n}  PMR={S['pmr']/n:.4f}   (published conflict PMR 0.807)")
print(f"\nMODEL'S TOP DECOY composition:")
print(f"  shares TRUE acceptor: {S['top_shares_acc']/n:.4f}   shares TRUE donor: {S['top_shares_don']/n:.4f}   neither: {S['top_shares_neither']/n:.4f}")
print(f"  top decoy has BOTH endpoints annotated (real-real): {S['top_rr']}/{n} = {S['top_rr']/n:.4f}")
if S['top_sharesacc_n']: print(f"  | of top decoys sharing true acceptor, the ALTERNATIVE DONOR is a real annotated donor: {S['top_altdonor_real']}/{S['top_sharesacc_n']} = {S['top_altdonor_real']/S['top_sharesacc_n']:.4f}")
if S['top_sharesdon_n']: print(f"  | of top decoys sharing true donor, the ALTERNATIVE ACCEPTOR is a real annotated acceptor: {S['top_altacc_real']}/{S['top_sharesdon_n']} = {S['top_altacc_real']/S['top_sharesdon_n']:.4f}")
print(f"\nSUBSET WITH A REAL-SITE DECOY (the only pairs where 'partner binding' is even well-posed):")
print(f"  examples with >=1 real-real decoy: {S['has_rr']}/{n} = {S['has_rr']/n:.4f}")
if S['has_rr']:
    import statistics as stt
    print(f"  model beats ALL real-real decoys: {S['pmr_vs_rr']}/{S['has_rr']} = {S['pmr_vs_rr']/S['has_rr']:.4f}  (mean margin {stt.mean(marg_rr):+.3f})")
    print(f"  POSITION-ONLY rule -(|a-200|+|d-(L-200)|) beats ALL real-real decoys: {S['posrule_beats_rr']}/{S['has_rr']} = {S['posrule_beats_rr']/S['has_rr']:.4f}")

"""Steelman check: is the decoy that PMR actually adjudicates against a real-site pair?

Also decomposes the both-endpoints-real DECOY pairs into the genuinely
partner-relevant subclass (shares the TRUE acceptor or TRUE donor with a
different REAL partner) vs. unrelated real-site pairs.
"""
from __future__ import annotations

import gzip
import json
import pickle
import sys
from collections import defaultdict

sys.path.insert(0, "src")
import numpy as np
from gfmcd.splicing.schema import SplicePairExample

GTF = "data/external/gencode/v50/gencode.v50.basic.annotation.gtf.gz"
CONFLICTS = "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl"
PKL = "colab_results/splicebert_run/baselines/local_pair_baseline.pkl"
CHROMS = {"chr17", "chr18"}

tx_exons = defaultdict(list)
tx_meta = {}
with gzip.open(GTF, "rt") as f:
    for line in f:
        if line.startswith("#"):
            continue
        c = line.rstrip("\n").split("\t")
        if c[2] != "exon" or c[0] not in CHROMS:
            continue
        tid = c[8].split('transcript_id "', 1)[1].split('"', 1)[0]
        tx_exons[tid].append((int(c[3]) - 1, int(c[4])))
        tx_meta[tid] = (c[0], c[6])

acc_anchor = {"+": set(), "-": set()}
don_anchor = {"+": set(), "-": set()}
for tid, exons in tx_exons.items():
    _, strand = tx_meta[tid]
    ex = sorted(exons)
    if strand == "-":
        ex = ex[::-1]
    n = len(ex)
    if n < 2:
        continue
    for i, (s, e) in enumerate(ex):
        a, d = (s, e) if strand == "+" else (e - 1, s - 1)
        if i > 0:
            acc_anchor[strand].add(a)
        if i < n - 1:
            don_anchor[strand].add(d)

with open(PKL, "rb") as f:
    baseline = pickle.load(f)
print("baseline:", type(baseline).__name__)

cnt = defaultdict(int)
n = 0
bd_class = defaultdict(int)
both_real_decoy_class = defaultdict(int)

for line in open(CONFLICTS):
    d = json.loads(line)
    ex = SplicePairExample.from_dict(d)
    n += 1
    strand = ex.strand
    W = ex.metadata["genomic_window_start"]
    E = ex.metadata["genomic_window_end"]

    def g(p):
        return W + p if strand == "+" else E - 1 - p

    A, D = acc_anchor[strand], don_anchor[strand]
    tp = ex.true_pair
    ta, td = tp.acceptor_pos, tp.donor_pos

    accR = {s.position: (g(s.position) in A) for s in ex.acceptors}
    donR = {s.position: (g(s.position) in D) for s in ex.donors}

    scores = baseline.score_example(ex)
    ti = ex.true_pair_index
    order = np.argsort(-scores)
    best = next(int(i) for i in order if int(i) != ti)
    bp = ex.pairs[best]
    ar, dr = accR[bp.acceptor_pos], donR[bp.donor_pos]

    # classify the best (top-scoring) decoy
    if ar and dr:
        cnt["best_decoy_both_real"] += 1
        if bp.acceptor_pos == ta:
            bd_class["both_real__true_acc_other_real_donor"] += 1
        elif bp.donor_pos == td:
            bd_class["both_real__true_don_other_real_acceptor"] += 1
        else:
            bd_class["both_real__two_other_real_sites"] += 1
    else:
        cnt["best_decoy_has_nonsite"] += 1
    cnt["best_decoy_acc_real"] += ar
    cnt["best_decoy_don_real"] += dr
    if bp.acceptor_pos == ta:
        cnt["best_decoy_shares_true_acc"] += 1
    if bp.donor_pos == td:
        cnt["best_decoy_shares_true_don"] += 1

    # structure of ALL both-real decoy pairs
    for pr in ex.pairs:
        a, dd = pr.acceptor_pos, pr.donor_pos
        if (a, dd) == (ta, td):
            continue
        if accR[a] and donR[dd]:
            if a == ta:
                both_real_decoy_class["true_acc + other real donor"] += 1
            elif dd == td:
                both_real_decoy_class["true_don + other real acceptor"] += 1
            else:
                both_real_decoy_class["two other real sites"] += 1

print(f"\nn = {n}")
print("--- PWM-baseline BEST DECOY (the pair PMR is adjudicated against) ---")
for k in ["best_decoy_both_real", "best_decoy_has_nonsite", "best_decoy_acc_real",
          "best_decoy_don_real", "best_decoy_shares_true_acc", "best_decoy_shares_true_don"]:
    print(f"  {k:32s} {cnt[k]:6d}  {cnt[k]/n:.4%}")
print("  breakdown of the both-real best decoys:")
for k, v in sorted(bd_class.items(), key=lambda x: -x[1]):
    print(f"    {k:42s} {v:5d}  {v/n:.4%}")

print("\n--- ALL both-endpoints-real DECOY pairs, by partner-relevance ---")
tot = sum(both_real_decoy_class.values())
for k, v in sorted(both_real_decoy_class.items(), key=lambda x: -x[1]):
    print(f"  {k:32s} {v:6d}  ({v/tot:.2%} of both-real decoys)")
print(f"  total both-real decoy pairs: {tot}")

#!/usr/bin/env python
"""STEELMAN CHECK for the 'circular conflict set' finding.

Charge: the conflict set is enriched at the baseline's decision boundary, so
'beating the baseline' there is noise-decorrelation, not information.
Prediction of the charge: the model's PMR should be carried by NEAR-TIE conflicts
(baseline lost by ~0 log units) and should collapse where the baseline is
CONFIDENTLY wrong (large conflict strength).

Test: stride-sample the frozen conflict set, compute (a) baseline conflict
strength = max_decoy_score - true_score (>0 by construction on this set) with the
SHIPPED pickled baseline, and (b) additive-frozen seed0 PMR. Stratify PMR by
conflict-strength bin.
"""
from __future__ import annotations

import json
import pickle
from pathlib import Path
import sys

import numpy as np
import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))

from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.schema import SplicePairExample  # noqa: E402
from gfmcd.splicing.readout import collate_pair_indices, true_pair_margin  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint  # noqa: E402

STRIDE = 16          # every 16th conflict example -> ~627 examples, spread over whole file
BATCH = 8

device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"])
mc = cfg["model"]

with open(REPO / "colab_results/splicebert_run/baselines/local_pair_baseline.pkl", "rb") as fh:
    baseline = pickle.load(fh)

conf_path = REPO / "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl"
examples: list[SplicePairExample] = []
with conf_path.open() as f:
    for i, line in enumerate(f):
        if not line.strip():
            continue
        if i % STRIDE == 0:
            examples.append(SplicePairExample.from_json(line))
print(f"loaded {len(examples)} conflict examples (stride {STRIDE})", flush=True)

# --- baseline conflict strength (log-score units), and sanity: must be > 0 for all
strength = []
for x in examples:
    s = baseline.score_example(x)
    t = s[x.true_pair_index]
    d = np.delete(s, x.true_pair_index)
    strength.append(float(np.max(d) - t))
strength = np.asarray(strength)
print(f"conflict strength: min {strength.min():.4f} median {np.median(strength):.3f} "
      f"max {strength.max():.3f} | frac<=0 {(strength <= 0).mean():.4f} (must be 0)", flush=True)

adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
    trust_remote_code=False, local_files_only=True,
    model_class=mc.get("model_class", "masked_lm"))
readout, ckpt = load_pair_checkpoint(
    REPO / "colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt", adapter=adapter)
print("backbone_state is None:", ckpt.get("backbone_state") is None,
      "| readout:", type(readout).__name__, flush=True)

margins = []
for i in range(0, len(examples), BATCH):
    ex = examples[i:i + BATCH]
    tok = adapter.tokenize([x.sequence for x in ex])
    pb = collate_pair_indices(ex, token_offset=tok.prefix_tokens, device=adapter.device)
    with torch.no_grad():
        out = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
        logits = readout(out.hidden_states[rep], pb)
        masked = logits.masked_fill(~pb.mask, torch.finfo(logits.dtype).min)
        m = true_pair_margin(masked, pb)
    margins.extend(m.float().cpu().tolist())
    if i % 160 == 0:
        print(f"  {i}/{len(examples)}", flush=True)

margins = np.asarray(margins)
win = margins > 0
n_pairs = np.mean([len(x.pairs) for x in examples])
chance = 1.0 / n_pairs

print("\n=== OVERALL ===")
print(f"n={len(examples)}  mean pairs/example={n_pairs:.1f}  chance PMR~{chance:.4f}")
print(f"conflict PMR = {win.mean():.4f}   (published 5-seed mean 0.807)")

bins = [(0.0, 0.25), (0.25, 0.5), (0.5, 1.0), (1.0, 2.0), (2.0, 4.0), (4.0, 1e9)]
print("\n=== PMR BY BASELINE CONFLICT STRENGTH (how confidently the baseline was wrong) ===")
print(f"{'bin (log-score)':>18} {'n':>5} {'frac':>6} {'model PMR':>10} {'mean margin':>12}")
rows = {}
for lo, hi in bins:
    sel = (strength >= lo) & (strength < hi)
    if sel.sum() == 0:
        continue
    lab = f"[{lo:g},{hi:g})" if hi < 1e9 else f"[{lo:g},inf)"
    rows[lab] = dict(n=int(sel.sum()), frac=float(sel.mean()),
                     pmr=float(win[sel].mean()), mean_margin=float(margins[sel].mean()))
    print(f"{lab:>18} {sel.sum():>5} {sel.mean():>6.3f} {win[sel].mean():>10.4f} "
          f"{margins[sel].mean():>12.3f}")

# Correlation: does model success ride on baseline near-ties?
from scipy.stats import pointbiserialr, spearmanr  # noqa: E402
r_pb = pointbiserialr(win.astype(float), strength)
r_sp = spearmanr(margins, strength)
print(f"\npoint-biserial r(model_correct, conflict_strength) = {r_pb.statistic:+.4f} (p={r_pb.pvalue:.3g})")
print(f"spearman r(model_margin, conflict_strength)        = {r_sp.statistic:+.4f} (p={r_sp.pvalue:.3g})")

# Drop the near-ties entirely and recompute the headline
for thr in (0.25, 0.5, 1.0, 2.0):
    sel = strength >= thr
    print(f"PMR restricted to conflict strength >= {thr:>4}: {win[sel].mean():.4f}  (n={sel.sum()})")

out = dict(n=len(examples), stride=STRIDE, mean_pairs=float(n_pairs), chance=float(chance),
           overall_pmr=float(win.mean()), bins=rows,
           r_pointbiserial=float(r_pb.statistic), p_pointbiserial=float(r_pb.pvalue),
           spearman_margin_strength=float(r_sp.statistic),
           pmr_by_threshold={str(t): float(win[strength >= t].mean()) for t in (0.25, 0.5, 1.0, 2.0)})
(REPO / "scratch/steelman_conflict_strength_pmr.json").write_text(json.dumps(out, indent=2))
print("\nwrote scratch/steelman_conflict_strength_pmr.json")

"""Would a CONTEXT-MATCHED control change the reported number?

The claim says the control-pos window is bad because it is exonic/upstream/not-AG-matched.
Test it: run controls that ARE context-matched -- the intronic windows 8nt either side of
the real AG (same intron, same distance regime, same local sequence statistics), and an
exonic window inside the exon body -- and compare their recovery to control-pos.
"""
import sys
from contextlib import ExitStack
import numpy as np, torch
sys.path.insert(0, "src")
from gfmcd.splicing.circuit import (
    ACC_WINDOW_OFFSETS, CORRUPT_ALT, DEFAULT_FASTA, DEFAULT_GTF, DEFAULT_MODEL,
    CouplingTask, _dataset, eligible, load_adapter, patch_proj, pick_device,
)
from gfmcd.splicing.coupling import stable_rng, substitute

X = eligible(_dataset(DEFAULT_GTF, DEFAULT_FASTA), "val")
stable_rng("qkv", 0).shuffle(X)
dev = pick_device()
ad = load_adapter(DEFAULT_MODEL, dev)
task = CouplingTask(ad, batch=6)
OFF, L3, H3 = ad.prefix_tokens, 3, 1

# conditional set, as the published runs do (min_effect >= 0.3), n = 150
keep = []
with torch.no_grad():
    for i in range(0, 900, 6):
        ch = X[i:i + 6]
        cl, co, dn = task.pair(ch)
        e = (task.margin(ad.model(**cl).logits.float(), dn)
             - task.margin(ad.model(**co).logits.float(), dn))
        for j, x in enumerate(ch):
            if float(e[j]) >= 0.3:
                keep.append(x)
        if len(keep) >= 150:
            break
keep = keep[:150]
print("n =", len(keep))

WINDOWS = {
    "acceptor (the real patch)": lambda x: [x.next_acceptor_pos + OFF + k for k in ACC_WINDOW_OFFSETS],
    "control-pos (published)":   lambda x: [max(4, (x.donor_pos + OFF) - (x.next_acceptor_pos - x.donor_pos)) + k for k in ACC_WINDOW_OFFSETS],
    "adjacent -8 (INTRONIC, ctx-matched)": lambda x: [x.next_acceptor_pos + OFF - 8 + k for k in ACC_WINDOW_OFFSETS],
    "adjacent +8 (EXONIC, ctx-matched)":   lambda x: [x.next_acceptor_pos + OFF + 8 + k for k in ACC_WINDOW_OFFSETS],
    "mid-intron (halfway donor->acceptor)": lambda x: [(x.donor_pos + x.next_acceptor_pos) // 2 + OFF + k for k in ACC_WINDOW_OFFSETS],
}
num = {c: [] for c in WINDOWS}
dnm = []
with torch.no_grad():
    for i in range(0, len(keep), 6):
        ch = keep[i:i + 6]
        dn = [x.donor_pos for x in ch]
        cl = task.encode([x.sequence for x in ch], dn)
        co = task.encode([substitute(x.sequence, x.next_acceptor_pos - 2, CORRUPT_ALT) for x in ch], dn)
        store, hs = {}, []
        for w in ("key", "value"):
            m = getattr(ad.attention_self_modules[L3], w)
            hs.append(m.register_forward_hook(
                lambda _m, _i, o, w=w: store.__setitem__(w, o.detach().clone())))
        m_c = task.margin(ad.model(**cl).logits.float(), dn)
        for h in hs:
            h.remove()
        m_k = task.margin(ad.model(**co).logits.float(), dn)
        dnm += (m_c - m_k).tolist()
        for name, fn in WINDOWS.items():
            pos = torch.tensor([fn(x) for x in ch], device=dev)
            with ExitStack() as st:
                st.enter_context(patch_proj(ad, L3, H3, "key", store["key"], pos))
                st.enter_context(patch_proj(ad, L3, H3, "value", store["value"], pos))
                m = task.margin(ad.model(**co).logits.float(), dn)
            num[name] += (m - m_k).tolist()

D = sum(dnm)
print(f"\nbaseline coupling (denominator) = {np.mean(dnm):.4f}\n")
print("key+value patch, recovery = sum(delta)/sum(coupling):")
for name in WINDOWS:
    print(f"  {name:38s} {sum(num[name])/D:+.6f}")

import sys, time, json
from pathlib import Path
REPO = Path('/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation')
sys.path.insert(0, str(REPO/'src'))
import torch
from gfmcd.adapters.splicebert import SpliceBertAdapter
from gfmcd.splicing.config import load_config
from gfmcd.splicing.io import load_jsonl
from gfmcd.splicing.readout import collate_pair_indices, true_pair_margin
from gfmcd.splicing.training import load_pair_checkpoint

cfg = load_config(REPO/'configs/splicebert_partner_selection/base.json')
mc = cfg['model']; rep = int(cfg['readout']['representation_layer'])
print('rep layer', rep, 'set_size', cfg['circuit'].get('default_component_set_size'))
ad = SpliceBertAdapter.from_pretrained(REPO/mc['path'], tokenizer_mode=mc.get('tokenizer_mode','auto'),
    device='mps', trust_remote_code=False, local_files_only=True, model_class=mc.get('model_class','masked_lm'))
print('device', ad.device, 'layers', ad.num_layers, 'heads', ad.num_heads)
ro, ck = load_pair_checkpoint(REPO/'colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt', adapter=ad)
print('regime', ck.get('extra_metadata',{}).get('regime'), 'backbone_state', ck.get('backbone_state') is not None)
Vc = load_jsonl(REPO/'results/splicebert_partner_selection/circuits/discovery/confirmation.jsonl')
print('nVc', len(Vc))
ex = Vc[:16]
tok = ad.tokenize([x.sequence for x in ex])
pb = collate_pair_indices(ex, token_offset=tok.prefix_tokens, device=ad.device)
t0=time.time()
with torch.no_grad():
    out = ad.forward(tok, output_hidden_states=True, output_attentions=False, grad=False)
    m = true_pair_margin(ro(out.hidden_states[rep], pb), pb).sum()
print('first fwd(16)', round(time.time()-t0,2),'s margin', float(m)/16)
t0=time.time()
for _ in range(3):
    with torch.no_grad():
        out = ad.forward(tok, output_hidden_states=True, output_attentions=False, grad=False)
        m = true_pair_margin(ro(out.hidden_states[rep], pb), pb).sum()
print('steady fwd(16) x3', round((time.time()-t0)/3,3),'s each')

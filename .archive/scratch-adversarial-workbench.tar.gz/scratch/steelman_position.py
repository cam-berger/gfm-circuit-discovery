#!/usr/bin/env python
"""STEELMAN TEST: does the trained additive-frozen readout actually USE the
positional shortcut (acceptor==200, donor==len-200), or does it use sequence CONTENT?

Conditions (candidate positions, pair list, true_pair_index, seq LENGTH all held
fixed -- only the NUCLEOTIDES change):
  REAL     : the real window                      (sanity: should reproduce ~0.80 PMR)
  SHUF     : dinucleotide-preserving shuffle      (kills content, keeps position+length+composition)
  SHUF+M   : dinuc shuffle, then RE-PLANT the exact motif (AG / GT / GC) at every
             candidate site position               (kills context, keeps position + motif)

If the readout is a position detector, PMR survives SHUF and SHUF+M.
If the readout is a sequence/context detector, PMR collapses.
"""
from __future__ import annotations

import json
from pathlib import Path
import random
import sys

import numpy as np
import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))

from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.schema import SplicePairExample  # noqa: E402
from gfmcd.splicing.readout import collate_pair_indices  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint  # noqa: E402

N = 300
BATCH = 6
SEED = 0


def dinuc_shuffle(seq: str, rng: random.Random) -> str:
    """Altschul-Erikson dinucleotide-preserving shuffle (Eulerian path method)."""
    if len(seq) < 3:
        return seq
    # build edge lists
    edges: dict[str, list[str]] = {}
    for a, b in zip(seq[:-1], seq[1:]):
        edges.setdefault(a, []).append(b)
    last = seq[-1]
    first = seq[0]
    for _ in range(200):
        # random last-edge choice per vertex, check connectivity to `last`
        last_edge = {}
        for v, outs in edges.items():
            if v == last:
                continue
            last_edge[v] = rng.choice(outs)
        # connectivity: following last_edge from every v must reach `last`
        ok = True
        for v in last_edge:
            seen = set()
            cur = v
            while cur != last:
                if cur in seen or cur not in last_edge:
                    ok = False
                    break
                seen.add(cur)
                cur = last_edge[cur]
            if not ok:
                break
        if not ok:
            continue
        # shuffle remaining edges, append the designated last edge
        new_edges: dict[str, list[str]] = {}
        for v, outs in edges.items():
            rest = list(outs)
            if v in last_edge:
                rest.remove(last_edge[v])
                rng.shuffle(rest)
                rest.append(last_edge[v])
            else:
                rng.shuffle(rest)
            new_edges[v] = rest
        # walk
        out = [first]
        cur = first
        ptr = {v: 0 for v in new_edges}
        for _ in range(len(seq) - 1):
            nxt = new_edges[cur][ptr[cur]]
            ptr[cur] += 1
            out.append(nxt)
            cur = nxt
        res = "".join(out)
        if len(res) == len(seq):
            return res
    # fallback: mononucleotide shuffle
    chars = list(seq)
    rng.shuffle(chars)
    return "".join(chars)


def plant_motifs(seq: str, example: SplicePairExample) -> str:
    s = list(seq)
    for site in example.acceptors:  # acceptor motif occupies [pos-2, pos)
        p = site.position
        if p - 2 >= 0:
            s[p - 2], s[p - 1] = site.motif[0], site.motif[1]
    for site in example.donors:  # donor motif occupies [pos, pos+2)
        p = site.position
        if p + 1 < len(s):
            s[p], s[p + 1] = site.motif[0], site.motif[1]
    return "".join(s)


def pmr_and_stats(adapter, readout, rep, examples, seqs):
    """Return PMR (true strictly beats best decoy), top1 acc, and per-term arrays."""
    wins = 0
    top1 = 0
    A_true, D_true = [], []
    total = 0
    for i in range(0, len(examples), BATCH):
        ex = examples[i:i + BATCH]
        sq = seqs[i:i + BATCH]
        tok = adapter.tokenize(sq)
        pb = collate_pair_indices(ex, token_offset=tok.prefix_tokens, device=adapter.device)
        with torch.no_grad():
            out = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
            hidden = out.hidden_states[rep]
            logits = readout(hidden, pb).float().cpu()
        mask = pb.mask.cpu()
        for k, x in enumerate(ex):
            m = mask[k]
            lg = logits[k][m]
            t = x.true_pair_index
            tv = lg[t].item()
            dec = torch.cat([lg[:t], lg[t + 1:]])
            best = dec.max().item()
            wins += int(tv > best)
            top1 += int(int(lg.argmax()) == t)
            total += 1
    return wins / total, top1 / total, total


def main():
    device = "mps" if torch.backends.mps.is_available() else "cpu"
    cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
    rep = int(cfg["readout"]["representation_layer"])
    mc = cfg["model"]
    adapter = SpliceBertAdapter.from_pretrained(
        REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
        trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
    ckpt = REPO / "colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt"
    readout, checkpoint = load_pair_checkpoint(ckpt, adapter=adapter)
    print("regime:", checkpoint.get("extra_metadata", {}).get("regime"),
          "| backbone_state None:", checkpoint.get("backbone_state") is None,
          "| readout:", type(readout).__name__, "| device:", device, flush=True)

    conf = REPO / "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl"
    examples: list[SplicePairExample] = []
    with conf.open() as f:
        for line in f:
            if line.strip():
                examples.append(SplicePairExample.from_json(line))
                if len(examples) >= N:
                    break

    # verify the positional degeneracy on this sample
    bad_a = sum(1 for x in examples if x.true_pair.acceptor_pos != 200)
    bad_d = sum(1 for x in examples if x.true_pair.donor_pos != len(x.sequence) - 200)
    print(f"degeneracy check: acceptor!=200 -> {bad_a}/{len(examples)}; donor!=len-200 -> {bad_d}/{len(examples)}", flush=True)

    rng = random.Random(SEED)
    real = [x.sequence for x in examples]
    shuf = [dinuc_shuffle(x.sequence, rng) for x in examples]
    shufm = [plant_motifs(s, x) for s, x in zip(shuf, examples)]

    # sanity: shuffles preserve length + base composition
    from collections import Counter
    lok = all(len(a) == len(b) == len(c) for a, b, c in zip(real, shuf, shufm))
    cok = all(Counter(a) == Counter(b) for a, b in zip(real, shuf))
    print(f"shuffle sanity: lengths preserved={lok}, mono-composition preserved={cok}", flush=True)
    # how many true acceptors still have AG after shuffle (no planting)?
    keep_ag = sum(1 for s, x in zip(shuf, examples) if s[198:200] == "AG")
    print(f"SHUF: true acceptor still 'AG' in {keep_ag}/{len(examples)}", flush=True)

    res = {}
    for name, seqs in (("REAL", real), ("SHUF", shuf), ("SHUF+MOTIF", shufm)):
        pmr, t1, n = pmr_and_stats(adapter, readout, rep, examples, seqs)
        res[name] = {"pmr": pmr, "top1": t1, "n": n}
        print(f"{name:11s}  PMR={pmr:.4f}  top1={t1:.4f}  n={n}", flush=True)

    # chance level
    mean_pairs = float(np.mean([len(x.pairs) for x in examples]))
    print(f"chance PMR (1/mean_pairs) = {1/mean_pairs:.4f}   mean pairs={mean_pairs:.1f}")
    res["chance"] = 1 / mean_pairs
    (REPO / "scratch/steelman_position_results.json").write_text(json.dumps(res, indent=2))


if __name__ == "__main__":
    main()

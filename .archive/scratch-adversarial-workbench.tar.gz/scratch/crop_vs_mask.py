#!/usr/bin/env python
"""Disentangle POSITION from CONTENT for the acceptor term f(h_a).

Both manipulations destroy the outer 50nt of the LEFT flank (150-200nt upstream
of the acceptor, i.e. outside the polypyrimidine tract / branchpoint region).
They differ ONLY in whether absolute indices are preserved:

  left-mask-50 : seq[0:50] <- random ACGT.  Absolute positions PRESERVED (acc=200).
  left-crop-50 : seq[0:50] deleted.         Absolute positions SHIFTED  (acc=150).
  left-pad-50  : 50 random nt PREPENDED.    Absolute positions SHIFTED  (acc=250).

Candidate sets are equalised: in all variants we drop any candidate whose motif
window touches the perturbed 50nt block, so the three variants score the SAME
biological candidates.

If the acceptor term is biological  -> all three similar to original.
If it is an absolute-position prior -> mask survives, crop and pad collapse.
"""
from __future__ import annotations
import random, sys
from pathlib import Path
import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))
from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.schema import SplicePairExample, SiteCandidate, PairCandidate  # noqa: E402
from gfmcd.splicing.readout import collate_pair_indices  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint  # noqa: E402

N, BATCH = 200, 8
random.seed(0)
device = "mps" if torch.backends.mps.is_available() else "cpu"
cfg = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfg["readout"]["representation_layer"]); mc = cfg["model"]
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
readout, _ = load_pair_checkpoint(
    REPO / "colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt", adapter=adapter)

examples = []
with (REPO / "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl").open() as f:
    for line in f:
        if line.strip():
            examples.append(SplicePairExample.from_json(line))
        if len(examples) >= N:
            break

K = 50
rnd = lambda k: "".join(random.choice("ACGT") for _ in range(k))


def variant(x, mode):
    """mode in {original, left-mask-50, left-crop-50, left-pad-50}.
    Candidate set is identical across modes: only sites with position >= 52 survive."""
    if mode == "original":
        seq, shift = x.sequence, 0
    elif mode == "left-mask-50":
        seq, shift = rnd(K) + x.sequence[K:], 0
    elif mode == "left-crop-50":
        seq, shift = x.sequence[K:], -K
    elif mode == "left-pad-50":
        seq, shift = rnd(K) + x.sequence, +K
    n = len(seq)
    amap, dmap, accs, dons = {}, {}, [], []
    for i, s in enumerate(x.acceptors):
        if s.position < K + 2:          # equalise candidate sets across modes
            continue
        p = s.position + shift
        amap[i] = len(accs); accs.append(SiteCandidate(p, "acceptor", s.motif))
    for i, s in enumerate(x.donors):
        if s.position < K + 2:
            continue
        p = s.position + shift
        dmap[i] = len(dons); dons.append(SiteCandidate(p, "donor", s.motif))
    pairs, t = [], None
    for j, pr in enumerate(x.pairs):
        if pr.acceptor_index not in amap or pr.donor_index not in dmap:
            if j == x.true_pair_index: return None
            continue
        if j == x.true_pair_index: t = len(pairs)
        pairs.append(PairCandidate(pr.acceptor_pos + shift, pr.donor_pos + shift,
                                   amap[pr.acceptor_index], dmap[pr.donor_index]))
    if t is None or len(pairs) < 2: return None
    return SplicePairExample(x.example_id, seq, tuple(accs), tuple(dons), tuple(pairs), t,
                             x.split, x.chrom, x.strand, x.gene_id, x.transcript_id,
                             x.exon_number, x.genomic_exon_start, x.genomic_exon_end, x.metadata)


keep = [x for x in examples if all(variant(x, m) is not None for m in
        ("original", "left-mask-50", "left-crop-50", "left-pad-50"))]
print(f"n={len(keep)} examples usable in all 4 variants (identical candidate sets)\n")
print(f"{'variant':16s} {'true-acc idx':>12s} {'acceptor-term':>14s} {'donor-term':>11s} {'PMR':>7s}")

for mode in ("original", "left-mask-50", "left-crop-50", "left-pad-50"):
    exs = [variant(x, mode) for x in keep]
    na = nd = np_ = 0
    for i in range(0, len(exs), BATCH):
        eb = exs[i:i+BATCH]
        tok = adapter.tokenize([e.sequence for e in eb])
        pb = collate_pair_indices(eb, token_offset=tok.prefix_tokens, device=adapter.device)
        with torch.no_grad():
            h = adapter.forward(tok, output_hidden_states=True).hidden_states[rep]
            b = torch.arange(h.shape[0], device=h.device)[:, None]
            A = readout.acceptor(h[b, pb.positions[..., 0]]).squeeze(-1).float().cpu()
            D = readout.donor(h[b, pb.positions[..., 1]]).squeeze(-1).float().cpu()
            Lt = readout.length(readout._length_features(pb.lengths)).squeeze(-1).float().cpu()
        m = pb.mask.cpu(); pos = pb.positions.cpu(); off = tok.prefix_tokens
        full = A + D + Lt
        for k, e in enumerate(eb):
            sa, sd = {}, {}
            for p in range(m.shape[1]):
                if m[k, p]:
                    sa[int(pos[k, p, 0]) - off] = float(A[k, p])
                    sd[int(pos[k, p, 1]) - off] = float(D[k, p])
            tp = e.pairs[e.true_pair_index]
            na += int(max(sa, key=sa.get) == tp.acceptor_pos)
            nd += int(max(sd, key=sd.get) == tp.donor_pos)
            s = full[k].clone(); s[~m[k]] = -1e30
            tv = float(s[e.true_pair_index]); s[e.true_pair_index] = -1e30
            np_ += int(tv > float(s.max()))
    n = len(exs)
    ti = exs[0].pairs[exs[0].true_pair_index].acceptor_pos
    print(f"{mode:16s} {ti:12d} {na/n:14.3f} {nd/n:11.3f} {np_/n:7.3f}")

import sys, json
sys.path.insert(0,'src')
from gfmcd.splicing.io import load_jsonl
from gfmcd.splicing.context_controls import retain_site_windows, retain_pair_endpoints_only
import numpy as np

ex = load_jsonl('colab_results/splicebert_run/baselines/val_local_conflicts.jsonl')
print('n examples', len(ex))
sub = ex[:4000]
fr=[]; lens=[]; nacc=[]; ndon=[]
# coverage as a function of flank
for f in (0,6,12,20,30,50):
    tot_keep=0; tot_len=0
    for e in sub[:1000]:
        s = retain_site_windows(e, flank=f, include_all_candidates=True)
        tot_keep += sum(1 for c in s if c!='N')
        tot_len += len(s)
    print(f'flank={f:3d}  retained fraction = {tot_keep/tot_len:.4f}')
for e in sub:
    lens.append(len(e.sequence)); nacc.append(len(e.acceptors)); ndon.append(len(e.donors))
print('mean seqlen', np.mean(lens), 'mean #acceptors', np.mean(nacc), 'mean #donors', np.mean(ndon))
# gap statistics: distribution of longest masked run at flank=12
runs=[]
maskedfrac=[]
for e in sub[:1000]:
    s = retain_site_windows(e, flank=12, include_all_candidates=True)
    maskedfrac.append(sum(1 for c in s if c=='N')/len(s))
    cur=0; best=0
    for c in s:
        if c=='N': cur+=1; best=max(best,cur)
        else: cur=0
    runs.append(best)
print('flank12: mean masked frac %.4f  median masked frac %.4f' % (np.mean(maskedfrac), np.median(maskedfrac)))
print('flank12: longest contiguous masked run: mean %.1f median %.1f max %d' % (np.mean(runs), np.median(runs), max(runs)))
# how much of the TRUE acceptor upstream region (-40..-13) survives?
cov_up=[]
for e in sub[:1000]:
    s = retain_site_windows(e, flank=12, include_all_candidates=True)
    a = e.true_pair.acceptor_pos
    seg = s[max(0,a-40):a-12]
    if len(seg): cov_up.append(sum(1 for c in seg if c!='N')/len(seg))
print('fraction of branchpoint region (-40..-13 rel true acceptor) that is STILL VISIBLE under the flank=12 control: mean %.4f median %.4f' % (np.mean(cov_up), np.median(cov_up)))

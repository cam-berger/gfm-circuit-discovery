"""Is the 512-pair cap (or the 20-500 length filter) what destroys cross-pairing decoys?

Re-enumerate candidate pairs with max_pairs=None and with a relaxed length window,
and count decoy pairs whose BOTH endpoints are real annotated splice sites and whose
swapped endpoint(s) are distal (>30nt) from the true site.
"""
from __future__ import annotations

import gzip
import json
import sys
from collections import defaultdict
from dataclasses import replace

sys.path.insert(0, "src")
from gfmcd.splicing.candidates import CandidateConfig, enumerate_candidate_pairs

GTF = "data/external/gencode/v50/gencode.v50.basic.annotation.gtf.gz"
CONFLICTS = "colab_results/splicebert_run/baselines/val_local_conflicts.jsonl"
CHROMS = {"chr17", "chr18"}
DISTAL = 30

tx_exons: dict[str, list[tuple[int, int]]] = defaultdict(list)
tx_meta: dict[str, tuple[str, str]] = {}
with gzip.open(GTF, "rt") as f:
    for line in f:
        if line.startswith("#"):
            continue
        c = line.rstrip("\n").split("\t")
        if c[2] != "exon" or c[0] not in CHROMS:
            continue
        tid = c[8].split('transcript_id "', 1)[1].split('"', 1)[0]
        tx_exons[tid].append((int(c[3]) - 1, int(c[4])))
        tx_meta[tid] = (c[0], c[6])

acc_anchor = {"+": set(), "-": set()}
don_anchor = {"+": set(), "-": set()}
for tid, exons in tx_exons.items():
    _, strand = tx_meta[tid]
    ex = sorted(exons)
    if strand == "-":
        ex = ex[::-1]
    n = len(ex)
    if n < 2:
        continue
    for i, (s, e) in enumerate(ex):
        a, d = (s, e) if strand == "+" else (e - 1, s - 1)
        if i > 0:
            acc_anchor[strand].add(a)
        if i < n - 1:
            don_anchor[strand].add(d)

base = CandidateConfig()
cfgs = {
    "capped512_len20-500 (as built)": base,
    "uncapped_len20-500": replace(base, max_pairs=None),
    "uncapped_len20-900": replace(base, max_pairs=None, max_exon_length=900),
}

hits = {k: 0 for k in cfgs}
tot = {k: 0 for k in cfgs}
npairs = {k: 0 for k in cfgs}
n_ex = 0

for line in open(CONFLICTS):
    d = json.loads(line)
    n_ex += 1
    strand = d["strand"]
    W, E = d["metadata"]["genomic_window_start"], d["metadata"]["genomic_window_end"]
    seq = d["sequence"]

    def g(p: int) -> int:
        return W + p if strand == "+" else E - 1 - p

    tp = d["pairs"][d["true_pair_index"]]
    ta, td = tp["acceptor_pos"], tp["donor_pos"]
    A, D = acc_anchor[strand], don_anchor[strand]

    for name, cfg in cfgs.items():
        _, _, pairs, _ = enumerate_candidate_pairs(seq, cfg, true_acceptor=ta, true_donor=td)
        npairs[name] += len(pairs)
        n = 0
        for p in pairs:
            a, dd = p.acceptor_pos, p.donor_pos
            if a == ta and dd == td:
                continue
            if not (g(a) in A and g(dd) in D):
                continue
            ok_a = (a == ta) or abs(a - ta) > DISTAL
            ok_d = (dd == td) or abs(dd - td) > DISTAL
            if ok_a and ok_d:
                n += 1
        tot[name] += n
        hits[name] += n > 0

print(f"examples: {n_ex}\n")
for name in cfgs:
    print(
        f"{name:32s} mean pairs/ex {npairs[name]/n_ex:7.1f}   "
        f"cross decoys total {tot[name]:6d}   frac examples with >=1: {hits[name]/n_ex:.4f}"
    )

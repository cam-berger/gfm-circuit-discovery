import json, numpy as np
rng = np.random.default_rng(0)
pairs_by_id = json.load(open("scratch/_pairs.json"))
BASE="results/splicebert_partner_selection/behavior"
sets = {
 "VAL  additive-frozen": f"{BASE}/seed0_additive-frozen/val/per_example_clean.jsonl",
 "CONF additive-frozen": f"{BASE}/seed0_additive-frozen/val/val_local_conflicts/per_example_clean.jsonl",
 "VAL  random-frozen":   f"{BASE}/seed0_additive-random-frozen/val/per_example_clean.jsonl",
 "CONF random-frozen":   f"{BASE}/seed0_additive-random-frozen/val/val_local_conflicts/per_example_clean.jsonl",
}
for name, path in sets.items():
    A=[];D=[];J=[]
    for l in open(path):
        r=json.loads(l)
        pr=pairs_by_id[r["example_id"]]
        ta,td = pr[r["true_pair_index"]]
        pa,pd = pr[r["predicted_pair_index"]]
        A.append(pa==ta); D.append(pd==td); J.append((pa,pd)==(ta,td))
    A=np.array(A);D=np.array(D);J=np.array(J)
    n=len(A)
    pA,pD,pJ = A.mean(),D.mean(),J.mean()
    exc = pJ - pA*pD
    # bootstrap CI on excess
    idx = rng.integers(0,n,(4000,n))
    bs = J[idx].mean(1) - A[idx].mean(1)*D[idx].mean(1)
    lo,hi = np.quantile(bs,[0.025,0.975])
    # conditionals
    pD_givenA = D[A].mean(); pD_givenNotA = D[~A].mean() if (~A).sum() else float('nan')
    # mutual information (bits)
    mi=0.0
    for a in (0,1):
        for d in (0,1):
            p = ((A==a)&(D==d)).mean()
            pa = (A==a).mean(); pd=(D==d).mean()
            if p>0: mi += p*np.log2(p/(pa*pd))
    print(f"{name}  n={n}")
    print(f"   P(A)={pA:.4f}  P(D)={pD:.4f}  P(A&D)=pairPMR={pJ:.4f}  product={pA*pD:.4f}")
    print(f"   EXCESS = {exc:+.4f}   95% boot CI [{lo:+.4f}, {hi:+.4f}]")
    print(f"   P(D|A)={pD_givenA:.4f}  P(D|~A)={pD_givenNotA:.4f}   MI={mi:.5f} bits")
    print(f"   error split: A-only-wrong(shares acceptor)={int(((A)&(~D)).sum())}  D-only-wrong(shares donor)={int(((~A)&(D)).sum())}  both-wrong={int(((~A)&(~D)).sum())}")
    # Frechet bounds on joint given marginals
    print(f"   Frechet joint range given marginals: [{max(0,pA+pD-1):.4f}, {min(pA,pD):.4f}]")
    print()

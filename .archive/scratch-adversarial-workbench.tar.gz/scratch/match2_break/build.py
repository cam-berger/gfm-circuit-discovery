"""Build the MATCH-2 quadruple set exactly per the design spec (C1-C5)."""
import gzip, re, json, pickle, random
from collections import defaultdict
import numpy as np

GTF = "data/external/gencode/v50/gencode.v50.basic.annotation.gtf.gz"

def parse():
    # transcript -> list of exons (chrom, strand, start, end) 1-based inclusive
    tx_exons = defaultdict(list)
    tx_gene = {}
    attr_re = re.compile(r'(\S+) "([^"]*)"')
    with gzip.open(GTF, "rt") as fh:
        for line in fh:
            if line[0] == "#":
                continue
            f = line.rstrip("\n").split("\t")
            if f[2] != "exon":
                continue
            attrs = dict(attr_re.findall(f[8]))
            tid = attrs["transcript_id"]
            tx_exons[tid].append((int(f[3]), int(f[4])))
            tx_gene[tid] = (attrs["gene_id"], f[0], f[6])
    return tx_exons, tx_gene

def main():
    tx_exons, tx_gene = parse()
    print("transcripts", len(tx_exons))
    # gene -> intron (d,a) in TRANSCRIPTION coords -> set of transcripts
    gene_introns = defaultdict(lambda: defaultdict(set))
    gene_meta = {}
    for tid, exons in tx_exons.items():
        gid, chrom, strand = tx_gene[tid]
        gene_meta[gid] = (chrom, strand)
        exons.sort()
        if len(exons) < 2:
            continue
        for i in range(len(exons) - 1):
            g_don = exons[i][1] + 1        # first intronic base (genomic, + strand sense)
            g_acc = exons[i + 1][0] - 1    # last intronic base
            if g_acc < g_don:
                continue
            if strand == "+":
                d, a = g_don, g_acc
            else:
                # transcription order: reverse. donor = 5'ss = the higher genomic coord side
                d, a = -g_acc, -g_don
            gene_introns[gid][(d, a)].add(tid)
    ntx_per_gene = defaultdict(set)
    for tid, (gid, c, s) in tx_gene.items():
        ntx_per_gene[gid].add(tid)

    quads = []
    for gid, introns in gene_introns.items():
        keys = list(introns.keys())
        if len(keys) < 2:
            continue
        # per-site transcript usage counts (site-intrinsic, annotation-derived)
        don_tx = defaultdict(set); acc_tx = defaultdict(set)
        for (d, a), tset in introns.items():
            don_tx[d] |= tset
            acc_tx[a] |= tset
        attested = set(keys)
        n = len(keys)
        for i in range(n):
            for j in range(i + 1, n):
                I1, I2 = keys[i], keys[j]
                if I1[0] == I2[0] or I1[1] == I2[1]:
                    continue  # need 4 distinct sites
                if I1[0] > I2[0]:
                    I1, I2 = I2, I1
                d1, a1 = I1; d2, a2 = I2
                allc = (d1, a1, d2, a2)
                if max(allc) - min(allc) > 1000:      # C1
                    continue
                if (d1, a2) in attested or (d2, a1) in attested:  # C2
                    continue
                L11, L22, L12, L21 = a1 - d1, a2 - d2, a2 - d1, a1 - d2
                if min(L11, L22, L12, L21) < 50:      # C3
                    continue
                u = a2 - a1; v = d2 - d1
                if not ((abs(u) <= 30 and v >= 20) or (v <= 30 and abs(u) >= 20)):  # C4
                    continue
                arm = "acc_tandem" if (abs(u) <= 30 and v >= 20) else "don_tandem"
                chrom, strand = gene_meta[gid]
                quads.append(dict(
                    gene=gid, chrom=chrom, strand=strand, arm=arm,
                    d1=d1, a1=a1, d2=d2, a2=a2, u=u, v=v,
                    crossed=int(u < 0),
                    ntx_d1=len(don_tx[d1]), ntx_d2=len(don_tx[d2]),
                    ntx_a1=len(acc_tx[a1]), ntx_a2=len(acc_tx[a2]),
                    ntx_I1=len(introns[(d1, a1)]), ntx_I2=len(introns[(d2, a2)]),
                    gene_ntx=len(ntx_per_gene[gid]),
                ))
    print("quads after C1-C4:", len(quads), "genes", len({q['gene'] for q in quads}))
    from collections import Counter
    print(Counter(q['arm'] for q in quads))
    print("raw crossed rate", np.mean([q['crossed'] for q in quads]))

    # C5 topology balancing: 1:1 within strata of (|u| in 6nt bins, v in 60nt bins)
    rng = random.Random(0)
    strata = defaultdict(lambda: {0: [], 1: []})
    for q in quads:
        key = (q['arm'], abs(q['u']) // 6, q['v'] // 60)
        strata[key][q['crossed']].append(q)
    bal = []
    for key, d in strata.items():
        k = min(len(d[0]), len(d[1]))
        if k == 0:
            continue
        bal += rng.sample(d[0], k) + rng.sample(d[1], k)
    print("BALANCED:", len(bal), "genes", len({q['gene'] for q in bal}),
          "crossed", np.mean([q['crossed'] for q in bal]))
    print(Counter(q['arm'] for q in bal))
    with open("scratch/match2_break/quads.pkl", "wb") as fh:
        pickle.dump({"all": quads, "bal": bal}, fh)

main()

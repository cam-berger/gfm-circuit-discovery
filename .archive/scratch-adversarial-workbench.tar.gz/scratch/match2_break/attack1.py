"""Attack 1: multiplicative site-intrinsic 'pair-dominant-with-dominant' rival.
Uses ONLY per-site scalars (no partner information whatsoever)."""
import pickle, numpy as np, random
from collections import defaultdict

d = pickle.load(open("scratch/match2_break/quads.pkl", "rb"))
bal = d["bal"]
rng = random.Random(1)

def eval_rule(quads, phi_key_lo_hi, name, sign=+1):
    """phi_key_lo_hi(q) -> (phi_dlo, phi_dhi, psi_alo, psi_ahi)"""
    correct = 0
    ties = 0
    for q in quads:
        pd_lo, pd_hi, pa_lo, pa_hi = phi_key_lo_hi(q)
        delta = sign * (pd_lo - pd_hi) * (pa_lo - pa_hi)
        # delta>0 => predict PARALLEL (crossed=0)
        if delta > 0:
            pred = 0
        elif delta < 0:
            pred = 1
        else:
            ties += 1
            pred = rng.randint(0, 1)
        correct += (pred == q["crossed"])
    acc = correct / len(quads)
    print(f"{name:45s} acc={acc:.4f}  n={len(quads)}  tie_frac={ties/len(quads):.3f}")
    return acc

def ntx_feats(q):
    # d1 is by construction the LOW donor (d1<d2). a1 is d1's partner (label!).
    # We must express things in LABEL-BLIND terms: lo/hi by position.
    d_lo, d_hi = (q["d1"], q["d2"])                       # d1<d2 always
    nd_lo, nd_hi = q["ntx_d1"], q["ntx_d2"]
    a_lo, a_hi = (q["a1"], q["a2"]) if q["a1"] < q["a2"] else (q["a2"], q["a1"])
    na_lo, na_hi = (q["ntx_a1"], q["ntx_a2"]) if q["a1"] < q["a2"] else (q["ntx_a2"], q["ntx_a1"])
    return nd_lo, nd_hi, na_lo, na_hi

print("=== ANNOTATION-DERIVED DOMINANCE (transcript count per site) ===")
print("rule: pair the donor used in MORE transcripts with the acceptor used in MORE transcripts")
eval_rule(bal, ntx_feats, "ntx product rule (all)")
for arm in ("acc_tandem", "don_tandem"):
    sub = [q for q in bal if q["arm"] == arm]
    eval_rule(sub, ntx_feats, f"ntx product rule ({arm})")

# sanity: additive rival on the SAME scalars must be exactly 0.5
def add_rule(quads):
    # score(d,a)=phi(d)+psi(a) -> exactly tied; verify code path
    c = 0
    for q in quads:
        nd_lo, nd_hi, na_lo, na_hi = ntx_feats(q)
        s_par = (nd_lo + na_lo) + (nd_hi + na_hi)
        s_cro = (nd_lo + na_hi) + (nd_hi + na_lo)
        pred = 0 if s_par > s_cro else (1 if s_cro > s_par else rng.randint(0, 1))
        c += pred == q["crossed"]
    print(f"{'ADDITIVE ntx rival (should be 0.500)':45s} acc={c/len(quads):.4f}")
add_rule(bal)

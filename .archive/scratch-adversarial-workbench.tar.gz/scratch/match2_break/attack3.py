"""Attack 3: hardened. Gene-grouped CV, gene-grouped bootstrap CI, per arm,
plus a learned low-dim bilinear on local-crop-only site features."""
import pickle, gzip, re, random, itertools
import numpy as np
from collections import defaultdict
from pyfaidx import Fasta
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GroupKFold

gen = Fasta("data/external/gencode/v50/GRCh38.primary_assembly.genome.fa",
            sequence_always_upper=True, as_raw=True)
COMP = str.maketrans("ACGTN", "TGCAN")
def tseq(chrom, strand, t0, t1):
    if strand == "+": s = gen[chrom][t0 - 1:t1]
    else: s = gen[chrom][-t1 - 1:-t0].translate(COMP)[::-1]
    return s.upper()

D = pickle.load(open("scratch/match2_break/quads.pkl", "rb"))
bal = D["bal"]
PD, PA = pickle.load(open("scratch/match2_break/pwms.pkl", "rb"))
DON_L, DON_R, ACC_L, ACC_R = 3, 6, 20, 3
idx = {c: i for i, c in enumerate("ACGT")}
def sc(seq, P): return sum(P[i, idx[c]] for i, c in enumerate(seq) if c in idx)

def sites(q):
    a_lo, a_hi = (q["a1"], q["a2"]) if q["a1"] < q["a2"] else (q["a2"], q["a1"])
    return q["d1"], q["d2"], a_lo, a_hi

def site_feats(q):
    c, s = q["chrom"], q["strand"]
    d_lo, d_hi, a_lo, a_hi = sites(q)
    def dv(d):
        m = sc(tseq(c, s, d - DON_L, d + DON_R - 1), PD)
        w = tseq(c, s, d - 30, d + 30); gc = (w.count("G") + w.count("C")) / max(len(w), 1)
        return np.array([m, gc, 1.0])
    def av(a):
        m = sc(tseq(c, s, a - ACC_L + 1, a + ACC_R), PA)
        w = tseq(c, s, a - 50, a + 10)
        py = (w.count("C") + w.count("T")) / max(len(w), 1)
        gc = (w.count("G") + w.count("C")) / max(len(w), 1)
        return np.array([m, py, gc, 1.0])
    return dv(d_lo), dv(d_hi), av(a_lo), av(a_hi)

F = [site_feats(q) for q in bal]
y = np.array([1 - q["crossed"] for q in bal])          # 1 = parallel
g = np.array([q["gene"] for q in bal])
arm = np.array([q["arm"] for q in bal])

# ---- rival A: fixed, ZERO-TRAINING rule: sign((pwm_dlo-pwm_dhi)*(pwm_alo-pwm_ahi)) ----
delta = np.array([(f[0][0] - f[1][0]) * (f[2][0] - f[3][0]) for f in F])
rr = random.Random(11)
predA = np.array([1 if x > 0 else (0 if x < 0 else rr.randint(0, 1)) for x in delta])
okA = (predA == y).astype(float)
print(f"[A] ZERO-TRAINING PWM product rule      acc={okA.mean():.4f}  ties={np.mean(delta==0):.3f}")

# ---- rival B: learned bilinear on local-crop-only features, gene-grouped 5-fold CV ----
X = np.array([np.outer(f[0] - f[1], f[2] - f[3]).ravel() for f in F])
okB = np.zeros(len(y))
for tr, te in GroupKFold(n_splits=5).split(X, y, g):
    m = LogisticRegression(C=1.0, max_iter=5000).fit(X[tr], y[tr])
    okB[te] = (m.predict(X[te]) == y[te])
print(f"[B] LEARNED LOCAL-CROP BILINEAR (5-fold) acc={okB.mean():.4f}")

# ---- additive control on the same features (must be 0.500) ----
Xadd = np.array([np.concatenate([f[0] + f[1], f[2] + f[3]]) for f in F])  # symmetric => no info
okC = np.zeros(len(y))
for tr, te in GroupKFold(n_splits=5).split(Xadd, y, g):
    m = LogisticRegression(C=1.0, max_iter=5000).fit(Xadd[tr], y[tr])
    okC[te] = (m.predict(Xadd[te]) == y[te])
print(f"[C] ADDITIVE control (must be ~0.500)    acc={okC.mean():.4f}")

def boot(ok, groups, n=4000):
    gu = np.unique(groups); by = {u: np.where(groups == u)[0] for u in gu}
    rs = np.random.default_rng(0); out = []
    for _ in range(n):
        s = rs.choice(gu, len(gu), replace=True)
        i = np.concatenate([by[u] for u in s]); out.append(ok[i].mean())
    return np.percentile(out, [2.5, 97.5])

for nm, ok in (("A zero-train PWM", okA), ("B learned bilinear", okB)):
    lo, hi = boot(ok, g)
    print(f"    {nm:20s} gene-grouped 95% CI = [{lo:.3f}, {hi:.3f}]")
for a in ("acc_tandem", "don_tandem"):
    m = arm == a
    lo, hi = boot(okB[m], g[m])
    print(f"    [B] {a:12s} n={m.sum():4d} acc={okB[m].mean():.4f} CI=[{lo:.3f},{hi:.3f}]")

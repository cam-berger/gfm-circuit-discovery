"""Attack 2: SEQUENCE-ONLY, LOCAL-CROP-ONLY bilinear rival.
Each site's features come exclusively from a small crop around that site.
No partner is in any receptive field. This is exactly the design's
'LOCAL-CROP CONTROL', which the design asserts is provably 0.500.
"""
import pickle, gzip, re, random
import numpy as np
from collections import defaultdict
from pyfaidx import Fasta
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GroupKFold

FA = "data/external/gencode/v50/GRCh38.primary_assembly.genome.fa"
gen = Fasta(FA, sequence_always_upper=True, as_raw=True)
COMP = str.maketrans("ACGTN", "TGCAN")

def tseq(chrom, strand, t0, t1):
    """transcription-oriented sequence for transcription coords [t0,t1] inclusive"""
    if strand == "+":
        s = gen[chrom][t0 - 1:t1]
    else:
        g0, g1 = -t1, -t0
        s = gen[chrom][g0 - 1:g1].translate(COMP)[::-1]
    return s.upper()

D = pickle.load(open("scratch/match2_break/quads.pkl", "rb"))
bal, allq = D["bal"], D["all"]

# ---- PWMs fit on a large label-blind set of GENCODE 5'ss / 3'ss ----
def fit_pwms():
    import build  # not importable cheaply; re-parse minimal
donor_seqs, acc_seqs = [], []
attr_re = re.compile(r'(\S+) "([^"]*)"')
tx = defaultdict(list); meta = {}
with gzip.open("data/external/gencode/v50/gencode.v50.basic.annotation.gtf.gz", "rt") as fh:
    for line in fh:
        if line[0] == "#": continue
        f = line.split("\t")
        if f[2] != "exon": continue
        a = dict(attr_re.findall(f[8]))
        tx[a["transcript_id"]].append((int(f[3]), int(f[4])))
        meta[a["transcript_id"]] = (f[0], f[6])
rng = random.Random(7)
introns = []
for tid, ex in tx.items():
    ex.sort(); chrom, strand = meta[tid]
    for i in range(len(ex) - 1):
        gd, ga = ex[i][1] + 1, ex[i + 1][0] - 1
        if ga <= gd: continue
        d, a = (gd, ga) if strand == "+" else (-ga, -gd)
        introns.append((chrom, strand, d, a))
rng.shuffle(introns)
sample = introns[:120000]
DON_L, DON_R = 3, 6      # 9-mer 5'ss
ACC_L, ACC_R = 20, 3     # 23-mer 3'ss
def pwm_from(seqs, L):
    M = np.ones((L, 4)) * 0.5
    idx = {c: i for i, c in enumerate("ACGT")}
    for s in seqs:
        for i, c in enumerate(s):
            if c in idx: M[i, idx[c]] += 1
    M /= M.sum(1, keepdims=True)
    return np.log(M) - np.log(0.25)
ds, as_ = [], []
for chrom, strand, d, a in sample:
    s1 = tseq(chrom, strand, d - DON_L, d + DON_R - 1)
    s2 = tseq(chrom, strand, a - ACC_L + 1, a + ACC_R)
    if len(s1) == DON_L + DON_R: ds.append(s1)
    if len(s2) == ACC_L + ACC_R: as_.append(s2)
PD = pwm_from(ds, DON_L + DON_R)
PA = pwm_from(as_, ACC_L + ACC_R)
print("PWMs fit on", len(ds), len(as_), "real sites")

idx = {c: i for i, c in enumerate("ACGT")}
def score(seq, P):
    s = 0.0
    for i, c in enumerate(seq):
        if c in idx: s += P[i, idx[c]]
    return s

def sites(q):
    d_lo, d_hi = q["d1"], q["d2"]
    if q["a1"] < q["a2"]: a_lo, a_hi = q["a1"], q["a2"]
    else: a_lo, a_hi = q["a2"], q["a1"]
    return d_lo, d_hi, a_lo, a_hi

def don_seq(q, d, r=20): return tseq(q["chrom"], q["strand"], d - r, d + r)
def acc_seq(q, a, r=20): return tseq(q["chrom"], q["strand"], a - r, a + r)

# ---------- 2a: PWM-strength multiplicative rival ----------
def pwm_rule(quads, sign):
    c = 0; rr = random.Random(3)
    for q in quads:
        d_lo, d_hi, a_lo, a_hi = sites(q)
        pdl = score(tseq(q["chrom"], q["strand"], d_lo - DON_L, d_lo + DON_R - 1), PD)
        pdh = score(tseq(q["chrom"], q["strand"], d_hi - DON_L, d_hi + DON_R - 1), PD)
        pal = score(tseq(q["chrom"], q["strand"], a_lo - ACC_L + 1, a_lo + ACC_R), PA)
        pah = score(tseq(q["chrom"], q["strand"], a_hi - ACC_L + 1, a_hi + ACC_R), PA)
        delta = sign * (pdl - pdh) * (pal - pah)
        pred = 0 if delta > 0 else (1 if delta < 0 else rr.randint(0, 1))
        c += pred == q["crossed"]
    return c / len(quads)
for sgn in (+1, -1):
    print(f"PWM-strength MULTIPLICATIVE rival (sign={sgn:+d}): acc={pwm_rule(bal, sgn):.4f}")

# ---------- 2b: learned bilinear on LOCAL-CROP k-mer features ----------
KM = 3
kmers = ["".join(p) for p in __import__("itertools").product("ACGT", repeat=KM)]
kidx = {k: i for i, k in enumerate(kmers)}
def kfeat(s):
    v = np.zeros(len(kmers))
    for i in range(len(s) - KM + 1):
        j = kidx.get(s[i:i + KM])
        if j is not None: v[j] += 1
    n = v.sum()
    return v / n if n else v

def build_xy(quads, radius):
    X, y, g = [], [], []
    for q in quads:
        d_lo, d_hi, a_lo, a_hi = sites(q)
        xdl = kfeat(don_seq(q, d_lo, radius)); xdh = kfeat(don_seq(q, d_hi, radius))
        xal = kfeat(acc_seq(q, a_lo, radius)); xah = kfeat(acc_seq(q, a_hi, radius))
        dd = xdl - xdh; da = xal - xah
        X.append(np.outer(dd, da).ravel())   # pure bilinear contrast, no partner info
        y.append(1 - q["crossed"])           # 1 = parallel
        g.append(q["gene"])
    return np.array(X), np.array(y), np.array(g)

for radius in (20, 40):
    X, y, g = build_xy(bal, radius)
    gkf = GroupKFold(n_splits=5)
    accs = []
    for tr, te in gkf.split(X, y, g):
        m = LogisticRegression(C=0.05, max_iter=3000)
        m.fit(X[tr], y[tr])
        accs.append(m.score(X[te], y[te]))
    print(f"LOCAL-CROP BILINEAR (+/-{radius}nt, {KM}-mer, gene-grouped 5-fold): "
          f"acc={np.mean(accs):.4f}  folds={[round(a,3) for a in accs]}")

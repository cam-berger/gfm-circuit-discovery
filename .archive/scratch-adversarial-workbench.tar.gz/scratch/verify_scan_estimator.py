"""Reproduce run_confirm.py's section-B 96-head scan, recording num & dnm per example
so BOTH estimators can be computed from the SAME forward passes."""
from __future__ import annotations
import sys, json
from pathlib import Path
import numpy as np
import torch

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "src"))
sys.path.insert(0, str(REPO / "scripts" / "splicebert"))

from gfmcd.adapters.splicebert import SpliceBertAdapter
from gfmcd.circuits.hf_bert import capture_head_outputs, patch_heads
from transformers import AutoModelForMaskedLM, AutoTokenizer

import run_confirm as RC


class Args:
    gtf = "/Users/cberg/Research/data/genomes/gencode.v50.basic.annotation.gtf.gz"
    fasta = "/Users/cberg/Research/data/genomes/hg38.fa"


dev = "mps" if torch.backends.mps.is_available() else "cpu"
mp = str(REPO / "data/models/splicebert_official_archive/extracted/models/SpliceBERT.1024nt")
adapter = SpliceBertAdapter(AutoModelForMaskedLM.from_pretrained(mp),
                            AutoTokenizer.from_pretrained(mp), device=dev)
task = RC.Task(adapter, bs=8)
L, H = adapter.num_layers, adapter.num_heads

N_SCAN = int(sys.argv[1]) if len(sys.argv) > 1 else 120
# run_confirm: VAL = load(..., "val", n_val=400); SC = VAL[:n_scan]
VAL, veff = RC.load(Args(), "val", adapter, task, N_SCAN)
SC = VAL[:N_SCAN]
print(f"loaded {len(SC)} val exons; screening effect min={min(veff):.3f} max={max(veff):.3f}")

heads = [(l, h) for l in range(L) for h in range(H)]
NUM = np.zeros((len(heads), len(SC)))   # m - mk
DNM = np.zeros(len(SC))                 # mc - mk  (same for every head)
RAW_DNM = np.zeros(len(SC))             # unclamped
e0 = 0
for i in range(0, len(SC), 8):
    ch = SC[i:i + 8]
    cl, co, dn = task.pair(ch)
    with torch.no_grad():
        cc = capture_head_outputs(adapter, lambda: adapter.model(**cl))
        mc = task.metric(adapter.model(**cl).logits.float(), dn)
        mk = task.metric(adapter.model(**co).logits.float(), dn)
        raw = (mc - mk)
        dnm = raw.clamp_min(1e-3)                       # run_confirm.py:191
        RAW_DNM[e0:e0 + len(ch)] = raw.cpu().numpy()
        DNM[e0:e0 + len(ch)] = dnm.cpu().numpy()
        for hi_, hd in enumerate(heads):
            with patch_heads(adapter, cc, [hd]):
                m = task.metric(adapter.model(**co).logits.float(), dn)
            NUM[hi_, e0:e0 + len(ch)] = (m - mk).cpu().numpy()
    e0 += len(ch)
    print(f"  scan {e0}/{len(SC)}", end="\r", flush=True)
print()

mor = (NUM / DNM[None, :]).mean(1)            # run_confirm.py:195/199  MEAN OF RATIOS
rom = NUM.sum(1) / DNM.sum()                  # circuit.py:312          RATIO OF MEANS

print(f"\ndenominator (mc-mk): min={RAW_DNM.min():.4f} max={RAW_DNM.max():.4f}")
print(f"clamp_min(1e-3) fired on {(RAW_DNM < 1e-3).sum()} / {len(SC)} examples")
w = 1.0 / DNM
print(f"mean-of-ratios implicit weight spread max/min = {w.max()/w.min():.1f}x")

o_mor, o_rom = np.argsort(-mor), np.argsort(-rom)
i31 = heads.index((3, 1))
print(f"\nL3H1 rank: mean-of-ratios #{list(o_mor).index(i31)+1}   "
      f"ratio-of-means #{list(o_rom).index(i31)+1}   (of 96)")
print(f"L3H1 recovery: mean-of-ratios {mor[i31]:.3f}   ratio-of-means {rom[i31]:.3f}")
print(f"  published confirmation.json scan_top L3H1 = 0.8080")

print(f"\n{'rank':>4} | {'mean-of-ratios (run_confirm)':<30} | {'ratio-of-means (circuit.py)':<30}")
for r in range(8):
    a, b = o_mor[r], o_rom[r]
    print(f"{r+1:>4} | L{heads[a][0]}H{heads[a][1]:<3d} {mor[a]:7.3f}"
          f"{'':<14} | L{heads[b][0]}H{heads[b][1]:<3d} {rom[b]:7.3f}")

json.dump(dict(n=len(SC), mor=mor.tolist(), rom=rom.tolist(),
               heads=heads, dnm_min=float(RAW_DNM.min())),
          open(REPO / "scratch/scan_estimator_check.json", "w"))

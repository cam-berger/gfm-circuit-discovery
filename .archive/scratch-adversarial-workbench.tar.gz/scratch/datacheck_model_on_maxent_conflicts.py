#!/usr/bin/env python
"""Second half of the finding's predicted signature:
'the frozen-probe PMR advantage attributed to pretraining will shrink with [the conflict set]'.

Take the MaxEntScan-lite conflict set (order2|bg=cand, registered geometry) computed by
datacheck_maxent_dependency.py, and score the SAME trained additive-frozen seed0 readout on it.
Compare model conflict-PMR on: registered conflict set vs MaxEntScan-lite conflict set.
"""
from __future__ import annotations

import json
from pathlib import Path
import random
import sys

import numpy as np
import torch

REPO = Path("/Users/cberg/Research/projects/test/GFM_SpliceBERT_Circuit_Discovery_Implementation/gfm_splicebert_implementation")
sys.path.insert(0, str(REPO / "src"))

from gfmcd.adapters.splicebert import SpliceBertAdapter  # noqa: E402
from gfmcd.splicing.config import load_config  # noqa: E402
from gfmcd.splicing.schema import SplicePairExample  # noqa: E402
from gfmcd.splicing.readout import collate_pair_indices  # noqa: E402
from gfmcd.splicing.training import load_pair_checkpoint  # noqa: E402

N_SCORE = 1600

z = np.load(REPO / "scratch/datacheck_maxent_masks.npz", allow_pickle=True)
ids = list(z["example_ids"])
reg_mask = dict(zip(ids, z["order0_bgpos"]))
mel_mask = dict(zip(ids, z["order2_bgcand"]))   # MaxEntScan-lite (dependencies + decoy bg)
wmm_cand = dict(zip(ids, z["order0_bgcand"]))

print("loading val...", flush=True)
val = []
with (REPO / "data/processed/splicebert_partner_selection/v1/val.jsonl").open() as f:
    for line in f:
        if line.strip():
            val.append(SplicePairExample.from_json(line))
rng = random.Random(0)
val = rng.sample(val, N_SCORE)
print(f"scoring {len(val)} val examples", flush=True)

device = "mps" if torch.backends.mps.is_available() else "cpu"
cfgj = load_config(REPO / "configs/splicebert_partner_selection/base.json")
rep = int(cfgj["readout"]["representation_layer"])
mc = cfgj["model"]
adapter = SpliceBertAdapter.from_pretrained(
    REPO / mc["path"], tokenizer_mode=mc.get("tokenizer_mode", "auto"), device=device,
    trust_remote_code=False, local_files_only=True, model_class=mc.get("model_class", "masked_lm"))
readout, checkpoint = load_pair_checkpoint(
    REPO / "colab_results/splicebert_run/runs/additive-frozen_seed0/checkpoint.pt", adapter=adapter)
print("backbone_state is None (pretrained weights fresh):", checkpoint.get("backbone_state") is None, flush=True)

wins = np.zeros(len(val), dtype=bool)
BATCH = 8
for i in range(0, len(val), BATCH):
    ex = val[i:i + BATCH]
    tok = adapter.tokenize([x.sequence for x in ex])
    pb = collate_pair_indices(ex, token_offset=tok.prefix_tokens, device=adapter.device)
    with torch.no_grad():
        out = adapter.forward(tok, output_hidden_states=True, output_attentions=False)
        logits = readout(out.hidden_states[rep], pb).float().cpu()
    m = pb.mask.cpu()
    for k, x in enumerate(ex):
        lg = logits[k].clone()
        lg[~m[k]] = -np.inf
        t_ = lg[x.true_pair_index].item()
        lg[x.true_pair_index] = -np.inf
        wins[i + k] = t_ > lg.max().item()
    if i % 400 == 0:
        print(f"  {i}/{len(val)}", flush=True)

reg = np.array([bool(reg_mask[x.example_id]) for x in val])
mel = np.array([bool(mel_mask[x.example_id]) for x in val])
wmc = np.array([bool(wmm_cand[x.example_id]) for x in val])


def pmr(mask):
    return float(wins[mask].mean()) if mask.sum() else None


res = {
    "n_scored": len(val),
    "model_pmr_all_val": float(wins.mean()),
    "REGISTERED (order0|bg=pos)": {
        "baseline_val_top1": float(1 - reg.mean()),
        "n_conflict": int(reg.sum()),
        "MODEL_conflict_pmr": pmr(reg),
        "baseline_conflict_pmr_by_construction": 0.0,
    },
    "WMM+decoy-bg (order0|bg=cand)": {
        "baseline_val_top1": float(1 - wmc.mean()),
        "n_conflict": int(wmc.sum()),
        "MODEL_conflict_pmr": pmr(wmc),
    },
    "MAXENTSCAN-LITE (order2|bg=cand)": {
        "baseline_val_top1": float(1 - mel.mean()),
        "n_conflict": int(mel.sum()),
        "MODEL_conflict_pmr": pmr(mel),
        "baseline_conflict_pmr_by_construction": 0.0,
    },
    "surviving_conflicts_both": {
        "n": int((reg & mel).sum()),
        "MODEL_conflict_pmr": pmr(reg & mel),
    },
    "resolved_by_maxent_lite (reg conflict, maxent-lite gets right)": {
        "n": int((reg & ~mel).sum()),
        "MODEL_pmr": pmr(reg & ~mel),
    },
    "created_by_maxent_lite": {
        "n": int((~reg & mel).sum()),
        "MODEL_pmr": pmr(~reg & mel),
    },
}
print(json.dumps(res, indent=2))
(REPO / "scratch/datacheck_model_on_maxent_conflicts.json").write_text(json.dumps(res, indent=2))
